module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParentContext",
    ()=>ParentContext,
    "useParentContext",
    ()=>useParentContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
const ParentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({});
const useParentContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ParentContext);
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/axios.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createAxiosInstance",
    ()=>createAxiosInstance
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
;
function getCookie(name) {
    if (typeof document === "undefined") return null;
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop()?.split(";").shift() || null;
    return null;
}
const createAxiosInstance = ()=>{
    const token = getCookie("access_token");
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
        baseURL: "http://127.0.0.1:8000/api",
        headers: {
            Authorization: token ? `Bearer ${token}` : "",
            "Content-Type": "application/json"
        },
        withCredentials: true
    });
};
}),
"[project]/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AlertDialog",
    ()=>AlertDialog,
    "AlertDialogAction",
    ()=>AlertDialogAction,
    "AlertDialogCancel",
    ()=>AlertDialogCancel,
    "AlertDialogContent",
    ()=>AlertDialogContent,
    "AlertDialogDescription",
    ()=>AlertDialogDescription,
    "AlertDialogFooter",
    ()=>AlertDialogFooter,
    "AlertDialogHeader",
    ()=>AlertDialogHeader,
    "AlertDialogOverlay",
    ()=>AlertDialogOverlay,
    "AlertDialogPortal",
    ()=>AlertDialogPortal,
    "AlertDialogTitle",
    ()=>AlertDialogTitle,
    "AlertDialogTrigger",
    ()=>AlertDialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-alert-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function AlertDialog({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "alert-dialog",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
function AlertDialogTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "alert-dialog-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
function AlertDialogPortal({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "alert-dialog-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
function AlertDialogOverlay({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "alert-dialog-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
function AlertDialogContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogOverlay, {}, void 0, false, {
                fileName: "[project]/components/ui/alert-dialog.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "alert-dialog-content",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg", className),
                ...props
            }, void 0, false, {
                fileName: "[project]/components/ui/alert-dialog.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
function AlertDialogHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
function AlertDialogFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
function AlertDialogTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "alert-dialog-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-lg font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
function AlertDialogDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "alert-dialog-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
function AlertDialogAction({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
function AlertDialogCancel({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cancel"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant: "outline"
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/alert-dialog.tsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AcceptFinalizationMessage",
    ()=>AcceptFinalizationMessage,
    "ApproveAprMessage",
    ()=>ApproveAprMessage,
    "ApproveDatabaseMessage",
    ()=>ApproveDatabaseMessage,
    "AssessmentDeleteMessage",
    ()=>AssessmentDeleteMessage,
    "AssessmentSubmitButtonMessage",
    ()=>AssessmentSubmitButtonMessage,
    "BeneficiaryEvaluationSubmitButtonMessage",
    ()=>BeneficiaryEvaluationSubmitButtonMessage,
    "BeneficiaryPresenceTogglerButtonMessage",
    ()=>BeneficiaryPresenceTogglerButtonMessage,
    "BeneficiarySessionDeleteMessage",
    ()=>BeneficiarySessionDeleteMessage,
    "BeneficiarySessionPresenceTogglerButtonMessage",
    ()=>BeneficiarySessionPresenceTogglerButtonMessage,
    "CancelButtonMessage",
    ()=>CancelButtonMessage,
    "CdDatabaseBenefciaryEditionMessage",
    ()=>CdDatabaseBenefciaryEditionMessage,
    "CdDatabaseBeneficiaryCreationMessage",
    ()=>CdDatabaseBeneficiaryCreationMessage,
    "ChangeAprIncludedStatusButtonMessage",
    ()=>ChangeAprIncludedStatusButtonMessage,
    "ChapterCreationMessage",
    ()=>ChapterCreationMessage,
    "CommunityDialogueCreationMessage",
    ()=>CommunityDialogueCreationMessage,
    "CommunityDialogueEditionMessage",
    ()=>CommunityDialogueEditionMessage,
    "CommunityDialogueSelectorSubmitMessage",
    ()=>CommunityDialogueSelectorSubmitMessage,
    "CommunityDialogueSessionSubmitMessage",
    ()=>CommunityDialogueSessionSubmitMessage,
    "DeleteButtonMessage",
    ()=>DeleteButtonMessage,
    "DeleteIndicatorMessage",
    ()=>DeleteIndicatorMessage,
    "DeleteOutcomeMessage",
    ()=>DeleteOutcomeMessage,
    "DeleteOutputMessage",
    ()=>DeleteOutputMessage,
    "DoneButtonMessage",
    ()=>DoneButtonMessage,
    "EnactResetButtonMessage",
    ()=>EnactResetButtonMessage,
    "EnactSubmitButtonMessage",
    ()=>EnactSubmitButtonMessage,
    "GeneralMessage",
    ()=>GeneralMessage,
    "GenerateAprMessage",
    ()=>GenerateAprMessage,
    "IndicatorCreationMessage",
    ()=>IndicatorCreationMessage,
    "IndicatorEditionMessage",
    ()=>IndicatorEditionMessage,
    "Isp3CreationMessage",
    ()=>Isp3CreationMessage,
    "KitCreationMessage",
    ()=>KitCreationMessage,
    "KitDatabaseBeneficiaryCreationMessage",
    ()=>KitDatabaseBeneficiaryCreationMessage,
    "KitDatabaseBeneficiaryEditionMessage",
    ()=>KitDatabaseBeneficiaryEditionMessage,
    "KitDatabaseProgramCreationMessage",
    ()=>KitDatabaseProgramCreationMessage,
    "KitDatabaseProgramEditionMessage",
    ()=>KitDatabaseProgramEditionMessage,
    "KitEditionMessage",
    ()=>KitEditionMessage,
    "MainDatabaseBeneficiaryCreationMessage",
    ()=>MainDatabaseBeneficiaryCreationMessage,
    "MainDatabaseBeneficiaryEditionMessage",
    ()=>MainDatabaseBeneficiaryEditionMessage,
    "MainDatabaseProgramCreationMessage",
    ()=>MainDatabaseProgramCreationMessage,
    "MainDatabaseProgramEditionMessage",
    ()=>MainDatabaseProgramEditionMessage,
    "MealToolCreationMessage",
    ()=>MealToolCreationMessage,
    "MealToolDeleteButtonMessage",
    ()=>MealToolDeleteButtonMessage,
    "MealToolEditionMessage",
    ()=>MealToolEditionMessage,
    "OutcomeCreationMessage",
    ()=>OutcomeCreationMessage,
    "OutcomeEditionMessage",
    ()=>OutcomeEditionMessage,
    "OutputCreationMessage",
    ()=>OutputCreationMessage,
    "OutputEditionMessage",
    ()=>OutputEditionMessage,
    "PreAndPostTestCreationMessage",
    ()=>PreAndPostTestCreationMessage,
    "ProjectCreationMessage",
    ()=>ProjectCreationMessage,
    "PsychoeducationCreationMessage",
    ()=>PsychoeducationCreationMessage,
    "PsychoeducationEditionMessage",
    ()=>PsychoeducationEditionMessage,
    "ReferrBeneficiaryButtonMessage",
    ()=>ReferrBeneficiaryButtonMessage,
    "ReferralSubmitButtonMessage",
    ()=>ReferralSubmitButtonMessage,
    "RejectAprMessage",
    ()=>RejectAprMessage,
    "RejectDatabaseMessage",
    ()=>RejectDatabaseMessage,
    "RejectFinalizationMessage",
    ()=>RejectFinalizationMessage,
    "RejectFirstApprovedDatabaseMessage",
    ()=>RejectFirstApprovedDatabaseMessage,
    "RejectSecondApprovedDatabaseMessage",
    ()=>RejectSecondApprovedDatabaseMessage,
    "ResetButtonMessage",
    ()=>ResetButtonMessage,
    "ReviewAprMessage",
    ()=>ReviewAprMessage,
    "RoleCreationMessage",
    ()=>RoleCreationMessage,
    "RoleEditionMessage",
    ()=>RoleEditionMessage,
    "SignoutButtonMessage",
    ()=>SignoutButtonMessage,
    "SubmitNewDatabaseMessage",
    ()=>SubmitNewDatabaseMessage,
    "TrainingBeneficiaryCreationMessage",
    ()=>TrainingBeneficiaryCreationMessage,
    "TrainingCreationMessage",
    ()=>TrainingCreationMessage,
    "TrainingEditionMessage",
    ()=>TrainingEditionMessage,
    "TrainingEvaluationSubmitMessage",
    ()=>TrainingEvaluationSubmitMessage,
    "TrainingSelectorMessage",
    ()=>TrainingSelectorMessage,
    "UserCreationMessage",
    ()=>UserCreationMessage,
    "UserEditionMessage",
    ()=>UserEditionMessage
]);
const GeneralMessage = "Are you compleatly sure ?";
const OutcomeCreationMessage = "This action will create a new outcome !";
const OutcomeEditionMessage = "This action will replace the new data with previous data for selected outcome !";
const OutputCreationMessage = "This action will create a new output !";
const OutputEditionMessage = "This action will replace the new data with previous data for selected output !";
const AcceptFinalizationMessage = "This action will change the apr status of project !";
const RejectFinalizationMessage = "This action will change the apr status of project !";
const MainDatabaseBeneficiaryCreationMessage = "This action will create a new beneficiary in main database !";
const MainDatabaseBeneficiaryEditionMessage = "This action will replace the new data with previous data for selected beneficiary !";
const MainDatabaseProgramCreationMessage = "This action will create a new program related to main database !";
const MainDatabaseProgramEditionMessage = "This action will replace the new data with previous data for selected program !";
const MealToolCreationMessage = "This action will create a new mealtool for selected beneficiary !";
const MealToolEditionMessage = "This action will replace the new data with previous data for selected mealtool !";
const ReferrBeneficiaryButtonMessage = "This action will reffer beneficiairy to referral database !";
const ChangeAprIncludedStatusButtonMessage = "This action will change the apr included status of selected beneficiaries !";
const MealToolDeleteButtonMessage = "This action will delete the selected mealtool !";
const BeneficiaryEvaluationSubmitButtonMessage = "This action will replace the entered data with previous data !";
const KitDatabaseProgramCreationMessage = "This action will create a new program related to kit database !";
const KitDatabaseProgramEditionMessage = "This action will replace the new data with previous data for selected program !";
const KitDatabaseBeneficiaryCreationMessage = "This action will create a new beneficiary for Kit database !";
const KitDatabaseBeneficiaryEditionMessage = "This action will replace the new data with previous data for selected beneficiary !";
const KitCreationMessage = "This action will create a new kit !";
const KitEditionMessage = "This action will replace the new data with previous data for selected kit !";
const PreAndPostTestCreationMessage = "This action will set the pre and post tests scores for selected beneficiary !";
const TrainingBeneficiaryCreationMessage = "This action will create a new beneficiary for training database !";
const ChapterCreationMessage = "This action will create new chapter for selected training !";
const TrainingCreationMessage = "This action will create a new training !";
const TrainingEditionMessage = "This action will replace the new data with previous data for selected training !";
const TrainingEvaluationSubmitMessage = "This action will save the new data as new evaluation for current training !";
const TrainingSelectorMessage = "This action will assign the selected trainings to selected beneficiaries !";
const BeneficiaryPresenceTogglerButtonMessage = "This action will change the precense status of beneficiary for selected chapter !";
const CdDatabaseBeneficiaryCreationMessage = "This action will create a new beneficiary in community dialogue database !";
const CdDatabaseBenefciaryEditionMessage = "This action will replace the new data with previous data for selected beneficiary !";
const CommunityDialogueSelectorSubmitMessage = "This action will assign the selected groups to selected beneficiaries !";
const CommunityDialogueSessionSubmitMessage = "This action will create a new session for current community dialogue !";
const CommunityDialogueCreationMessage = "This action will create a new community dialogue !";
const CommunityDialogueEditionMessage = "This action will replace the new data with previous data for selected community dialouge !";
const PsychoeducationCreationMessage = "This action will create a new psychoeducation !";
const PsychoeducationEditionMessage = "This action will replace the new data with previous data for selected psychoeducation !";
const EnactResetButtonMessage = "This action will reset your scores form !";
const EnactSubmitButtonMessage = "This action will save scores for selected assessment !";
const AssessmentSubmitButtonMessage = "This action will create a new assessment !";
const IndicatorCreationMessage = "This action will create a new indicator which belongs to selected output !";
const IndicatorEditionMessage = "This action will replace the new data with previous data for selected indicator !";
const ReferralSubmitButtonMessage = "This action will replace the new data with previous data of referral for selected beneficiary !";
const RoleCreationMessage = "This action will create a new role with selected permissions !";
const RoleEditionMessage = "This action will replace the new data with previous data for selected role !";
const UserCreationMessage = "This action will create a new user !";
const UserEditionMessage = "This action will replace the new data with previous data as new information of selected user !";
const DeleteButtonMessage = "This action will delete the selected rows from system !";
const ResetButtonMessage = "This action will reset all inputs to 0";
const CancelButtonMessage = "This action will discard your changes !";
const DoneButtonMessage = "This action will save dessaggregations for current indicator !";
const SubmitNewDatabaseMessage = "This action will submit the selected database and send a notification to spicified manager !";
const ApproveDatabaseMessage = "This action will approve the selected database and notify the responsible users for comming steps !";
const RejectDatabaseMessage = "This action will reject the selected dtabase and notify the responsible user for checking !";
const GenerateAprMessage = "This action will generate the selected database apr in selected data range and notify responsible users !";
const ApproveAprMessage = "This action will mark the selected APR as approved and notify the users who reviewed it.";
const RejectAprMessage = "This action will mark the selected APR as rejected and notify the user who reviewed it.";
const DeleteOutcomeMessage = "This action will delete the selected outcome !";
const DeleteOutputMessage = "This action will delete the selected output !";
const DeleteIndicatorMessage = "This action will delete the selected indicator !";
const SignoutButtonMessage = "This action will sign you out from system !";
const RejectSecondApprovedDatabaseMessage = "This action will mark the selected APR as rejected and notify the user who approved it at the first stage.";
const RejectFirstApprovedDatabaseMessage = "This action will mark the selected apr as rejected !";
const ReviewAprMessage = "This action will change the selected apr status as Reviewed !";
const BeneficiarySessionDeleteMessage = "This action will remove the session from beneficiary !";
const ProjectCreationMessage = "This action will create a new project !";
const Isp3CreationMessage = "This action will assign the selected indicators to isp3s";
const BeneficiarySessionPresenceTogglerButtonMessage = "This action will change the presence status of beneficiary for selected session !";
const AssessmentDeleteMessage = "This action will delete the current assessment !";
}),
"[project]/components/global/ConfirmationDialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
;
;
;
const ConfirmationAlertDialogue = ({ open, onOpenChange, details, onContinue })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialog"], {
        open: open,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GeneralMessage"]
                        }, void 0, false, {
                            fileName: "[project]/components/global/ConfirmationDialog.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                            children: details
                        }, void 0, false, {
                            fileName: "[project]/components/global/ConfirmationDialog.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/ConfirmationDialog.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                            onClick: ()=>onOpenChange(false),
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/components/global/ConfirmationDialog.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                            type: "button",
                            onClick: ()=>{
                                if (onContinue) onContinue();
                            },
                            children: "Continue"
                        }, void 0, false, {
                            fileName: "[project]/components/global/ConfirmationDialog.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/ConfirmationDialog.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/global/ConfirmationDialog.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/global/ConfirmationDialog.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ConfirmationAlertDialogue;
}),
"[project]/components/layout/Parent.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// BASE COMPONENT FOR SEEDING COMMON INFORMATIONS TROUGH ALL SYSTEM.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$axios$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/axios.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ConfirmationDialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/ConfirmationDialog.tsx [app-ssr] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../global/UserFormTest'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$folder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Folder$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/folder.js [app-ssr] (ecmascript) <export default as Folder>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-ssr] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-ssr] (ecmascript) <export default as XCircle>");
"use client";
;
;
;
;
;
;
;
;
const Parent = ({ children })=>{
    const axiosInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$axios$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createAxiosInstance"])();
    const reqForToastAndSetMessage = (message, subMessage, action, type)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"])(message, {
            description: subMessage,
            action: action,
            style: {
                backgroundColor: type ? type == "error" ? "red" : type == "success" ? "green" : "yellow" : undefined
            },
            duration: 5000
        });
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [reqForProfile, setReqForProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [globalLoading, setGloabalLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reloadFlag, setReloadFlag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const handleReload = ()=>{
        setReloadFlag((prev)=>prev + 1);
    };
    const [myProfileDetails, setMyProfileDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get("/user_mng/user/me").then((response)=>{
            setMyProfileDetails(response.data.data);
        }).catch((error)=>{
            reqForToastAndSetMessage(error.response?.data?.message || "Error fetching profile details");
        });
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!myProfileDetails) return;
        axiosInstance.get(`/notification/my_notifications/${myProfileDetails.id}`).then((response)=>setNotifications(response.data.data)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    }, [
        myProfileDetails
    ]);
    const [aprsState, setAprsState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        submitted: 0,
        firstApproved: 0,
        secondApproved: 0,
        firstRejected: 0,
        reviewed: 0,
        secondRejected: 0
    });
    const aprStats = [
        {
            title: "Submitted",
            value: aprsState.submitted,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"],
            color: "text-yellow-500"
        },
        {
            title: "First Approved",
            value: aprsState.firstApproved,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"],
            color: "text-green-500"
        },
        {
            title: "First Rejected",
            value: aprsState.firstRejected,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"],
            color: "text-red-500"
        },
        {
            title: "Second Approved",
            value: aprsState.secondApproved,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"],
            color: "text-emerald-500"
        },
        {
            title: "Second Rejected",
            value: aprsState.secondRejected,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"],
            color: "text-rose-500"
        },
        {
            title: "Reviewed",
            value: aprsState.reviewed,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$folder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Folder$3e$__["Folder"],
            color: "text-indigo-500"
        }
    ];
    const [reqForConfirmationModel, setReqForConfirmationModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dialogConfig, setDialogConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        details: "",
        onContinue: ()=>{}
    });
    const reqForConfirmationModelFunc = (details, onContinue)=>{
        setDialogConfig({
            details,
            onContinue
        });
        setReqForConfirmationModel(true);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get("/apr_management/get_system_aprs_status").then((response)=>{
            setAprsState({
                submitted: response.data.data.submitted ?? 0,
                firstApproved: response.data.data.firstApproved ?? 0,
                secondApproved: response.data.data.secondApproved ?? 0,
                firstRejected: response.data.data.firstRejected ?? 0,
                reviewed: response.data.data.reviewed ?? 0,
                secondRejected: response.data.data.secondRejected ?? 0
            });
        }).catch((error)=>{
            reqForToastAndSetMessage(error.response.data.message);
        });
    }, []);
    const changeBeneficairyAprIncludedStatus = (id)=>{
        axiosInstance.post(`/global/beneficiary/change_apr_included/${id}`).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParentContext"].Provider, {
        value: {
            reqForToastAndSetMessage,
            axiosInstance,
            reloadFlag,
            handleReload,
            myProfileDetails,
            setReqForProfile,
            aprStats,
            changeBeneficairyAprIncludedStatus,
            reqForConfirmationModelFunc,
            notifications,
            setNotifications,
            setGloabalLoading
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-full",
                children: children
            }, void 0, false, {
                fileName: "[project]/components/layout/Parent.tsx",
                lineNumber: 198,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            reqForProfile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfileModal, {
                open: reqForProfile,
                onOpenChange: setReqForProfile,
                userId: myProfileDetails?.id,
                mode: "show"
            }, void 0, false, {
                fileName: "[project]/components/layout/Parent.tsx",
                lineNumber: 201,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ConfirmationDialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: reqForConfirmationModel,
                onOpenChange: setReqForConfirmationModel,
                details: dialogConfig.details,
                onContinue: ()=>{
                    dialogConfig.onContinue();
                    setReqForConfirmationModel(false);
                }
            }, void 0, false, {
                fileName: "[project]/components/layout/Parent.tsx",
                lineNumber: 211,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/layout/Parent.tsx",
        lineNumber: 182,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Parent;
}),
"[project]/bfs/Bfs.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
class Bfs {
    childsList = [];
    getChildsValues(graph) {
        this.bfs(graph);
        const temp = this.childsList;
        this.childsList = [];
        return temp;
    }
    bfs(graph) {
        for (const child of graph.childNodes){
            this.childsList.push(child.value);
        }
        for (const child of graph.childNodes){
            this.bfs(child);
        }
    }
}
const __TURBOPACK__default__export__ = Bfs;
}),
"[project]/classes/Hash.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$bfs$2f$Bfs$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/bfs/Bfs.ts [app-ssr] (ecmascript)");
;
class Hash {
    bfsInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$bfs$2f$Bfs$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    graphHash = "";
    getNodeHash(node) {
        const childsValues = this.bfsInstance.getChildsValues(node);
        for (const value of childsValues){
            this.graphHash += value.charCodeAt(0).toString();
        }
        const temp = this.graphHash;
        this.graphHash = "";
        return temp;
    }
}
const __TURBOPACK__default__export__ = Hash;
}),
"[project]/dfs/Dfs.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
class Dfs {
    /**
   * Saves the shortcut that has been found so far.
   */ currentFoundShourtcut = [];
    /**
   * The expected shortcut that dfs should search for.
   *
   * We set this property make the expectation available in entir class.
   */ expectedShourtcut = "";
    /**
   * Switch for checking if the expected shortcut is found or not.
   */ found = false;
    /**
   *
   * The base method to search for expected shortcut.
   *
   * When the user clicks on one or more keys it will searchs the for corresponding shourtcut throw the graph list.
   *
   * @param graphsList
   * @param expectedShourtcut
   * @returns initNode | false
   */ findShourtcut(graphsList, expectedShourtcut) {
        // Setting the expected shortcut to expectedShortcut property to be available globaly on entire class.
        this.expectedShourtcut = expectedShourtcut;
        // The first node will be initNode which is just a helper node for graph and will be not effective on shortcut searching.
        for (const initNode of graphsList){
            this.dfs(initNode);
            /**
       * If found property is true it means that the current graph is the one which we are searching for so we will return it.
       *
       * In this case we will also empty the currentFoundShortcut property and set the found property to false
       * which if we use a single instance of this class it should be empty in first iterations.
       *
       */ if (this.found) {
                this.currentFoundShourtcut = [];
                this.found = false;
                return initNode;
            }
        }
        /**
     * If the code reaches to this point it means that the expected shortcut was not found so we will set the
     * currentFoundShourtcut to a empty array and return false.
     */ this.currentFoundShourtcut = [];
        return false;
    }
    dfs(node) {
        if (this.found) {
            return;
        }
        for (const child of node.childNodes){
            this.currentFoundShourtcut.push(child.value);
            if (child.childNodes.length == 0) {
                if (this.currentFoundShourtcut.join("->") == this.expectedShourtcut) {
                    this.found = true;
                    this.currentFoundShourtcut = [];
                    return;
                } else {
                    this.currentFoundShourtcut = this.currentFoundShourtcut.slice(0, this.currentFoundShourtcut.length - 1);
                    continue;
                }
            }
            this.dfs(child);
        }
        this.currentFoundShourtcut = this.currentFoundShourtcut.slice(0, this.currentFoundShourtcut.length - 1);
    }
}
const __TURBOPACK__default__export__ = Dfs;
}),
"[project]/lexer/lexer.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
class Lexer {
    /**
   * This propery will be used to check if the current character should be include to final array or not.
   *
   * the value of this property will increase according to lenght of characters that should be passed.
   *
   * For example if the character is (a) there is posibilities that its the a key or alt key so
   * it will check for it and if the two comming characters is (l) and t it will increase the value
   * of this property to 2 and returns the alt.
   * by this tric the main function that performs the toknization which is getStringPrimeryCharsList will
   * know that the two comming characters belongs to (alt) key and insteat of them the function will returns
   * null.
   */ shouldBePass = 0;
    getStringPrimeryCharsList(str) {
        const strArray = Array.from(str);
        const manipulatedArray = strArray.map((char, index)=>{
            /**
         * If the shouldBePass property is greather then or equal to 1 return null.
         */ if (this.shouldBePass >= 1) {
                this.shouldBePass--;
                return null;
            }
            /**
         * If the character is (-) and the next character is (>) return (->) and pass next character.
         */ if (char == "-") {
                if (!(strArray[index + 1] == ">")) {
                    throw new Error(`Shortcutify Syntax Error 001: Expected -> but got -${strArray[index]}`);
                }
                this.shouldBePass++;
                return "->";
            } else if (char == "e") {
                /**
           * If the current character is (e) and the next 4 characters are (n,t,e,r) return (enter) and
           * pass next 4 characters.
           */ if (strArray.slice(index, index + 5).join("") == "enter") {
                    this.shouldBePass += 4;
                    return "enter";
                }
            } else if (char == "a") {
                /**
           * If the current character is (a) and the next two characters are (l,t) return alt
           * and pass the next two characters.
           */ if (strArray.slice(index, index + 3).join("") == "alt") {
                    this.shouldBePass += 2;
                    return "alt";
                }
            } else if (char == "s") {
                /**
           * If the current character is (s) and the next 4 characters are (h,i,f,t) return (shift)
           * and pass next 4 characters.
           */ if (strArray.slice(index, index + 5).join("") == "shift") {
                    this.shouldBePass += 4;
                    return "shift";
                }
            } else if (char == "c") {
                /**
           * If the current character is (c) and the next 6 characters are (o,n,t,r,o,l) return (control)
           * and pass next 6 characters.
           */ if (strArray.slice(index, index + 7).join("") == "control") {
                    this.shouldBePass += 6;
                    return "control";
                }
            } else if (char == "d") {
                /**
           * If the current character is (d) and the next 5 characters are (e,l,e,t,e) return (delete)
           * and pass next 5 characters.
           */ if (strArray.slice(index, index + 6).join("") == "delete") {
                    this.shouldBePass += 5;
                    return "delete";
                }
            } else if (char == "t") {
                /**
           * If the current character is (t) and the next 2 characters are (a,b) return (tab)
           * and pass next 2 characters.
           */ if (strArray.slice(index, index + 3).join("") == "tab") {
                    this.shouldBePass += 2;
                    return "tab";
                }
            }
            return char;
        });
        /**
     * Remove all null values from array and return it.
     */ return manipulatedArray.filter((item)=>item != null);
    }
    /**
   * Tokanized array getter.
   *
   * @param str
   * @returns
   */ getFullyString = (str)=>this.getStringPrimeryCharsList(str);
}
const __TURBOPACK__default__export__ = Lexer;
}),
"[project]/classes/ShourtcutNode.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
class ShourtcutNode {
    type;
    value;
    childNodes;
    constructor(type, value, childNodes){
        this.type = type;
        this.value = value;
        this.childNodes = childNodes ?? [];
    }
    addChild(child) {
        this.childNodes.push(child);
    }
    addChilds(childList) {
        this.childNodes = [
            ...this.childNodes,
            ...childList
        ];
    }
    removeLatestChild() {
        this.childNodes.pop();
    }
    hasAnyChild() {
        return this.childNodes.length >= 1;
    }
}
const __TURBOPACK__default__export__ = ShourtcutNode;
}),
"[project]/constants/ShourtcutifyConstants.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
class ShourtcutifyConstants {
    /**
   *
   * Checks if the terminal that passed to it is a key or not according to shourtcut grammer which is defined in Grammer.ts.
   *
   * @param terminal
   * @returns boolean
   */ isKeyAccToGrammer(terminal) {
        if (terminal.length == 1) return terminal.charCodeAt(0) >= 97 && terminal.charCodeAt(0) <= 122;
        if (terminal == "enter" || terminal == "alt" || terminal == "control" || terminal == "shift" || terminal == "delete" || terminal == "tab") return true;
        return false;
    }
    /**
   *
   * Checks if the terminal that has been passed to it is a Or (|) or not according to shourtcut grammer which is defined in Grammer.ts.
   *
   * @param terminal
   * @returns boolean
   */ isOrTerminalAccToGrammer(terminal) {
        return terminal.charCodeAt(0) == 124;
    }
    /**
   *
   * Checks if the terminal that has been passed to it is a arrow or not according to shourcut grammer which is defined in Grammer.ts.
   *
   * @param terminal
   * @returns boolean
   */ isArrowAccToGrammer(terminal) {
        return terminal == "->";
    }
    /**
   *
   * Checks if the terminal that has been passed to it is an open ( ( ) or not according to shourtcut grammer which is defined in Grammer.ts.
   *
   * @param terminal
   * @returns boolean
   */ isOpenAccToGrammer(terminal) {
        return terminal.charCodeAt(0) == 40;
    }
    /**
   *
   * Checks if the terminal that has been passed to it is an close ( ) ) or not according to shourtcut grammer which is defined in Grammer.ts.
   *
   * @param terminal
   * @returns boolean
   */ isCloseAccToGrammer(terminal) {
        return terminal.charCodeAt(0) == 41;
    }
}
const __TURBOPACK__default__export__ = ShourtcutifyConstants;
}),
"[project]/parser/parser.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/classes/ShourtcutNode.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ShourtcutifyConstants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ShourtcutifyConstants.ts [app-ssr] (ecmascript)");
;
;
class Parser {
    /**
   * The initial Node for each graph.
   */ initNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("initialNode", "init");
    /**
   * All the nodes that were already been as leafs of the created graph so far but is replaced by new nodes.
   */ beforeLatest = [];
    /**
   * Current leafs of created graph so far.
   */ currentLatest = [
        this.initNode
    ];
    /**
   * Shortcutify constants instance for detecting each terminal.
   */ constants = new __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ShourtcutifyConstants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    /**
   * Input tokanized array.
   * We will set it to be globaly available on entire class.
   */ tokanizedArray = [];
    /**
   * Generates the graph AST.
   * 
   * @param tokanizedArray 
   * @returns void
   */ parse(tokanizedArray) {
        this.tokanizedArray = tokanizedArray;
        let counter = 0;
        let loopSwitch = true;
        while(loopSwitch){
            if (this.constants.isOpenAccToGrammer(tokanizedArray[counter])) {
                const corresponingClosingTagIndex = this.findClosingTagIndix(this.tokanizedArray, counter);
                if (corresponingClosingTagIndex) {
                    const result = this.handleGroup(this.tokanizedArray.slice(counter, corresponingClosingTagIndex + 1));
                    if (counter == 0 || this.constants.isArrowAccToGrammer(this.tokanizedArray[counter - 1])) {
                        for (const node of this.currentLatest){
                            node.addChilds(result.hgNodes);
                        }
                        this.beforeLatest = this.currentLatest;
                        this.currentLatest = result.hgLeafs;
                    } else if (this.constants.isOrTerminalAccToGrammer(this.tokanizedArray[counter - 1])) {
                        for (const node of this.beforeLatest){
                            node.addChilds(result.hgNodes);
                        }
                        this.currentLatest = [
                            ...this.currentLatest,
                            ...result.hgLeafs
                        ];
                    }
                    counter = corresponingClosingTagIndex + 1;
                    if (counter >= this.tokanizedArray.length) {
                        loopSwitch = false;
                    }
                }
            } else if (this.constants.isKeyAccToGrammer(this.tokanizedArray[counter])) {
                if (counter === 0 || this.constants.isArrowAccToGrammer(this.tokanizedArray[counter - 1])) {
                    const newNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("key", this.tokanizedArray[counter]);
                    for (const node of this.currentLatest){
                        node.addChild(newNode);
                    }
                    this.beforeLatest = this.currentLatest;
                    this.currentLatest = [
                        newNode
                    ];
                } else if (this.constants.isOrTerminalAccToGrammer(this.tokanizedArray[counter - 1])) {
                    const newNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("key", this.tokanizedArray[counter]);
                    if (this.beforeLatest.length != 0) {
                        for (const node of this.beforeLatest){
                            node.addChild(newNode);
                        }
                        this.currentLatest = [
                            ...this.currentLatest,
                            newNode
                        ];
                    }
                }
                counter++;
                if (counter >= this.tokanizedArray.length) {
                    loopSwitch = false;
                }
            } else if (this.constants.isArrowAccToGrammer(this.tokanizedArray[counter]) || this.constants.isOrTerminalAccToGrammer(this.tokanizedArray[counter])) {
                counter++;
                if (counter >= this.tokanizedArray.length) {
                    loopSwitch = false;
                }
            }
        }
        const init = this.initNode;
        this.initNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("initialNode", "init");
        this.beforeLatest = [];
        this.currentLatest = [];
        return init;
    }
    /**
   * Generates a group AST and returns the generated nodes and leafs.
   * 
   * @param group
   * @returns hgNodes: Brunches of created sub graph.
   * @returns hgLeafs: Leafs of created sub graph.
   */ handleGroup(group) {
        let localNodes = [];
        let localBeforeLatest = [];
        let localCurrentLatest = [];
        let loopSwitch = true;
        // Remove the start and the end of the input array which are open and closing tags.
        const final = group.slice(1, group.length - 1);
        // Index counter.
        let counter = 0;
        while(loopSwitch){
            if (this.constants.isOpenAccToGrammer(final[counter])) {
                const corresponingClosingTagIndex = this.findClosingTagIndix(final, counter);
                if (corresponingClosingTagIndex) {
                    const result = this.handleGroup(final.slice(counter, corresponingClosingTagIndex + 1));
                    if (counter === 0) {
                        localNodes = [
                            ...localNodes,
                            ...result.hgNodes
                        ];
                        localCurrentLatest = [
                            ...localCurrentLatest,
                            ...result.hgLeafs
                        ];
                    } else if (this.constants.isArrowAccToGrammer(final[counter - 1])) {
                        for (const node of localCurrentLatest){
                            node.addChilds(result.hgNodes);
                        }
                        localBeforeLatest = localCurrentLatest;
                        localCurrentLatest = result.hgLeafs;
                    } else if (this.constants.isOrTerminalAccToGrammer(final[counter - 1])) {
                        if (localBeforeLatest.length != 0) {
                            for (const node of localBeforeLatest){
                                node.addChilds(result.hgNodes);
                            }
                        } else {
                            localNodes = [
                                ...localNodes,
                                ...result.hgNodes
                            ];
                        }
                        localCurrentLatest = [
                            ...localCurrentLatest,
                            ...result.hgLeafs
                        ];
                    }
                    counter = corresponingClosingTagIndex + 1;
                    if (counter >= final.length) {
                        loopSwitch = false;
                    }
                }
            } else if (this.constants.isKeyAccToGrammer(final[counter])) {
                if (counter === 0) {
                    const newNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("key", final[counter]);
                    localNodes = [
                        newNode
                    ];
                    localCurrentLatest = [
                        newNode
                    ];
                } else if (this.constants.isArrowAccToGrammer(final[counter - 1])) {
                    const newNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("key", final[counter]);
                    for (const node of localCurrentLatest){
                        node.addChild(newNode);
                    }
                    localBeforeLatest = localCurrentLatest;
                    localCurrentLatest = [
                        newNode
                    ];
                } else if (this.constants.isOrTerminalAccToGrammer(final[counter - 1])) {
                    const newNode = new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$ShourtcutNode$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]("key", final[counter]);
                    if (localBeforeLatest.length != 0) {
                        for (const node of localBeforeLatest){
                            node.addChild(newNode);
                        }
                        localCurrentLatest = [
                            ...localCurrentLatest,
                            newNode
                        ];
                    } else {
                        localNodes = [
                            ...localNodes,
                            newNode
                        ];
                        localCurrentLatest = [
                            ...localCurrentLatest,
                            newNode
                        ];
                    }
                }
                counter++;
                if (counter >= final.length) {
                    loopSwitch = false;
                }
            } else if (this.constants.isArrowAccToGrammer(final[counter]) || this.constants.isOrTerminalAccToGrammer(final[counter])) {
                counter++;
                if (counter >= final.length) {
                    loopSwitch = false;
                }
            }
        }
        return {
            hgNodes: localNodes,
            hgLeafs: localCurrentLatest
        };
    }
    /**
   *
   * Returns the closing tag of a spicific open tag.
   *
   * @param tokens
   * @param indexOfOpenTag
   * @returns number : index of corresponing closing tag | null
   */ findClosingTagIndix(tokens, indexOfOpenTag) {
        // Number of open tags that the algorithm finds on its way when searching for closing tag.
        let numOfOpenTags = 0;
        for(let i = indexOfOpenTag + 1; i < tokens.length; i++){
            // If the current token is a open tag increase the value of numOfOpenTags variable and continue.
            if (this.constants.isOpenAccToGrammer(tokens[i])) {
                numOfOpenTags++;
                continue;
            } else if (this.constants.isCloseAccToGrammer(tokens[i])) {
                /**
         * If the current token is a closing tag but the value of numOfOpenTags variable is no equal to zero
         * decrese the value of it and continue.
         *
         * otherwise return the i which will be the index of founded closing tag in toknized array.
         */ if (numOfOpenTags != 0) {
                    numOfOpenTags--;
                    continue;
                } else if (numOfOpenTags == 0) {
                    return i;
                }
            }
        }
        // If the corresponding closing tag was not found return null.
        return null;
    }
}
const __TURBOPACK__default__export__ = Parser;
}),
"[project]/types/ShourtcutifyTypes.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
 // KEYBOARD
}),
"[project]/core/KeyboardManager.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$Hash$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/classes/Hash.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dfs$2f$Dfs$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dfs/Dfs.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lexer$2f$lexer$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lexer/lexer.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$parser$2f$parser$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/parser/parser.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$types$2f$ShourtcutifyTypes$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/types/ShourtcutifyTypes.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
class KeyboardManager {
    /**
   * All registred shortcut graphs for keydown event.
   */ registeredKeysGraphToKeydownEvent = [];
    /**
   * All registred shortcut graphs for keyup event.
   */ registeredKeysGraphToKeyupEvent = [];
    /**
   * Lexer class instance for toknizing the shortcut.
   */ lexerInstance = new __TURBOPACK__imported__module__$5b$project$5d2f$lexer$2f$lexer$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    /**
   * Dfs class instance to perform depth first search algorithm on shortcut graph.
   */ dfs = new __TURBOPACK__imported__module__$5b$project$5d2f$dfs$2f$Dfs$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    /**
   * Dictionary for saving all keydown callbacks and connecting them to spicific hash.
   */ keyDownMap = {};
    /**
   * Dictionary for saving all keyup callbacks and connecting them to spicific hash.
   */ keyUpMap = {};
    /**
   * Shortcuts that should be prevent.
   */ shouldPreventKeys = [];
    /**
   * All keys which are pressed at the same time will be placed into this array.
   */ pressedKeys = [];
    /**
   * All keys which are released will be placed into this array.
   */ releasedKeys = [];
    /**
   * Amount of time that indicats when the garbage collector method should clear the releasedKeys array.
   */ garbageCollectorTimeout = 0;
    /**
   * Keyboard instance to make it available globaly in entire class.
   */ globalEvent = null;
    /**
   * Binding the main handler and add keydown and keyup event on window.
   */ constructor(){
        this.handleKeyboardEvent = this.handleKeyboardEvent.bind(this);
        window.addEventListener("keydown", this.handleKeyboardEvent);
        window.addEventListener("keyup", this.handleKeyboardEvent);
    }
    /**
   * Register's shortcuts according to (type) parameter.
   *
   * @param key
   * @param callback
   * @param type
   */ registerKey(key, callback, type = "keydown") {
        const keyGraph = this.getKeyGraph(key);
        const keyHash = this.getGraphHash(keyGraph);
        if (type == "keydown" && !this.keyDownMap[keyHash]) {
            this.registeredKeysGraphToKeydownEvent.push(keyGraph);
            this.keyDownMap[keyHash] = callback;
        } else if (type == "keyup" && !this.keyUpMap[keyHash]) {
            this.registeredKeysGraphToKeyupEvent.push(keyGraph);
            this.keyUpMap[keyHash] = callback;
        } else {
            throw new Error(`Invalid Event Type Error: Expected (keydown or keyup) but got ${type}`);
        }
    }
    /**
   * Register's the keys that should prevent its default action.
   *
   * @param key
   */ registerShouldPrevents(key) {
        if (Array.isArray(key)) {
            for (const k of key){
                const keyHash = this.getKeyHash(k);
                this.shouldPreventKeys.push(keyHash);
            }
        } else {
            const keyHash = this.getKeyHash(key);
            this.shouldPreventKeys.push(keyHash);
        }
    }
    /**
   * Main event handler.
   *
   * It will decides that which one of the events (keydown | keyup) should be take care of.
   *
   * @param e
   */ handleKeyboardEvent(e) {
        this.globalEvent = e;
        const key = e.key.toLowerCase();
        if (e.type == "keydown" && this.pressedKeys.at(-1) != key) {
            this.takeCareOfKeyDownEvent(key);
        } else if (e.type == "keyup") {
            this.takeCareOfKeyUpEvent(key);
        }
    }
    /**
   * Handles the keydown events.
   *
   * @param key
   */ takeCareOfKeyDownEvent(key) {
        this.pressedKeys.push(key);
        const shourtcut = this.pressedKeys.join("->");
        const callback = this.getKeyDownEventCallback(shourtcut);
        if (callback) {
            this.globalEvent?.preventDefault();
            callback();
        }
    }
    /**
   * Handls the keyup events.
   *
   * @param key
   */ takeCareOfKeyUpEvent(key) {
        this.pressedKeys = this.pressedKeys.slice(0, this.pressedKeys.length - 1);
        this.releasedKeys.push(key);
        this.garbageCollectorTimeout = 3000;
        const shourtcut = this.releasedKeys.join("->");
        const callback = this.getKeyUpEventCallback(shourtcut);
        if (callback) {
            this.globalEvent?.preventDefault();
            callback();
            this.garbageCollector();
        } else {
            setTimeout(()=>this.garbageCollector(), this.garbageCollectorTimeout);
        }
    }
    /**
   * Searchs for spicific key, callback in registeredKeysGraphToKeydownEvent array.
   *
   * @param key
   * @returns VoidFunction | null
   */ getKeyDownEventCallback(key) {
        const correspondingGraph = this.dfs.findShourtcut(this.registeredKeysGraphToKeydownEvent, key);
        if (correspondingGraph) {
            const graphHash = this.getGraphHash(correspondingGraph);
            if (this.keyDownMap[graphHash]) {
                return this.keyDownMap[graphHash];
            }
        }
        return null;
    }
    /**
   * Searchs for spicific key, callback in registeredKeysGraphToKeyupEvent array.
   *
   * @param key
   * @returns VoidFunction | null
   */ getKeyUpEventCallback(key) {
        const correspondingGraph = this.dfs.findShourtcut(this.registeredKeysGraphToKeyupEvent, key);
        if (correspondingGraph) {
            const graphHash = this.getGraphHash(correspondingGraph);
            if (this.keyUpMap[graphHash]) {
                return this.keyUpMap[graphHash];
            }
        }
        return null;
    }
    /**
   * Will clear the releasedKeys and pressedKeys arrays.
   *
   * @returns void
   */ garbageCollector() {
        this.releasedKeys = [];
        this.pressedKeys = [];
    }
    /**
   * Returns the hash of key graph as its own hash.
   *
   * @param key
   * @returns string
   */ getKeyHash(key) {
        return this.getGraphHash(this.getKeyGraph(key));
    }
    /**
   * Returns graph's hash
   *
   * @param graph
   * @returns string
   */ getGraphHash(graph) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$classes$2f$Hash$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]().getNodeHash(graph);
    }
    /**
   * Returns key graph.
   *
   * @param key
   * @returns ShortcutNode
   */ getKeyGraph(key) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$parser$2f$parser$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]().parse(this.getTokanizedKey(key));
    }
    /**
   * Returns tokanized version of key.
   *
   * @param key
   * @returns array
   */ getTokanizedKey(key) {
        return this.lexerInstance.getFullyString(key);
    }
    /**
   * Removes all events from window.
   */ destroy() {
        window.removeEventListener("keydown", this.handleKeyboardEvent);
        window.removeEventListener("keyup", this.handleKeyboardEvent);
    }
}
const __TURBOPACK__default__export__ = KeyboardManager;
}),
"[project]/enums/Enums.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShourtcutifyEventKeys",
    ()=>ShourtcutifyEventKeys,
    "ShourtcutifyEvents",
    ()=>ShourtcutifyEvents,
    "ShourtcutifyIdentifiers",
    ()=>ShourtcutifyIdentifiers,
    "ShourtcutifyModifierKeys",
    ()=>ShourtcutifyModifierKeys,
    "ShourtcutifySupportedEvents",
    ()=>ShourtcutifySupportedEvents
]);
(function(ShourtcutifyEvents) {
    (function(ShourtcutifyKeyboardEvents) {
        (function(KeyDownEvent) {
            KeyDownEvent["KeyDownEnter"] = "keydown-enter";
            KeyDownEvent["KeyDownDelete"] = "keydown-delete";
            KeyDownEvent["KeyDownCtrl"] = "keydown-ctrl";
            KeyDownEvent["KeyDownCtrlA"] = "keydown-ctrl+a";
            KeyDownEvent["KeyDownCtrlB"] = "keydown-ctrl+b";
            KeyDownEvent["KeyDownCtrlS"] = "keydown-ctrl+s";
            KeyDownEvent["KeyDownCtrlC"] = "keydown-ctrl+c";
            KeyDownEvent["KeyDownCtrlV"] = "keydown-ctrl+v";
            KeyDownEvent["KeyDownCtrlX"] = "keydown-ctrl+x";
            KeyDownEvent["KeyDownShift"] = "keydown-shift";
            KeyDownEvent["KeyDownShiftA"] = "keydown-shift+a";
            KeyDownEvent["KeyDownShiftB"] = "keydown-shift+b";
            KeyDownEvent["KeyDownShiftC"] = "keydown-shift+c";
            KeyDownEvent["KeyDownShiftV"] = "keydown-shift+v";
            KeyDownEvent["KeyDownShiftX"] = "keydown-shift+x";
            KeyDownEvent["KeyDownShiftS"] = "keydown-shift+s";
            KeyDownEvent["KeyDownArrowRight"] = "keydown-arrowright";
            KeyDownEvent["KeyDownArrowLeft"] = "keydown-arrowleft";
        })(ShourtcutifyKeyboardEvents.KeyDownEvent || (ShourtcutifyKeyboardEvents.KeyDownEvent = {}));
        (function(KeyUpEvent) {
            KeyUpEvent["KeyUpEnter"] = "keyup-enter";
            KeyUpEvent["KeyUpDelete"] = "keyup-delete";
            KeyUpEvent["KeyUpCtrl"] = "keyup-ctrl";
            KeyUpEvent["KeyUpCtrlA"] = "keyup-ctrl+a";
            KeyUpEvent["KeyUpCtrlB"] = "keyup-ctrl+b";
            KeyUpEvent["KeyUpCtrlS"] = "keyup-ctrl+s";
            KeyUpEvent["KeyUpCtrlC"] = "keyup-ctrl+c";
            KeyUpEvent["KeyUpCtrlV"] = "keyup-ctrl+v";
            KeyUpEvent["KeyUpCtrlX"] = "keyup-ctrl+x";
            KeyUpEvent["KeyUpShift"] = "keyup-shift";
            KeyUpEvent["KeyUpShiftA"] = "keyup-shift+a";
            KeyUpEvent["KeyUpShiftB"] = "keyup-shift+b";
            KeyUpEvent["KeyUpShiftC"] = "keyup-shift+c";
            KeyUpEvent["KeyUpShiftV"] = "keyup-shift+v";
            KeyUpEvent["KeyUpShiftX"] = "keyup-shift+x";
            KeyUpEvent["KeyUpShiftS"] = "keyup-shift+s";
            KeyUpEvent["KeyUpArrowRight"] = "keyup-arrowright";
            KeyUpEvent["KeyUpArrowLeft"] = "keyup-arrowleft";
        })(ShourtcutifyKeyboardEvents.KeyUpEvent || (ShourtcutifyKeyboardEvents.KeyUpEvent = {}));
    })(ShourtcutifyEvents.ShourtcutifyKeyboardEvents || (ShourtcutifyEvents.ShourtcutifyKeyboardEvents = {}));
})(ShourtcutifyEvents || (ShourtcutifyEvents = {}));
var ShourtcutifySupportedEvents = /*#__PURE__*/ function(ShourtcutifySupportedEvents) {
    ShourtcutifySupportedEvents["KeyDown"] = "KeyDown";
    ShourtcutifySupportedEvents["KeyUp"] = "KeyUp";
    return ShourtcutifySupportedEvents;
}({});
var ShourtcutifyIdentifiers = /*#__PURE__*/ function(ShourtcutifyIdentifiers) {
    ShourtcutifyIdentifiers["KeyDown"] = "keydown";
    ShourtcutifyIdentifiers["KeyUp"] = "keyup";
    return ShourtcutifyIdentifiers;
}({});
var ShourtcutifyEventKeys = /*#__PURE__*/ function(ShourtcutifyEventKeys) {
    ShourtcutifyEventKeys["Enter"] = "enter";
    ShourtcutifyEventKeys["Delete"] = "delete";
    ShourtcutifyEventKeys["CtrlA"] = "ctrl+a";
    ShourtcutifyEventKeys["CtrlB"] = "ctrl+b";
    ShourtcutifyEventKeys["CtrlS"] = "ctrl+s";
    ShourtcutifyEventKeys["CtrlC"] = "ctrl+c";
    ShourtcutifyEventKeys["CtrlV"] = "ctrl+v";
    ShourtcutifyEventKeys["CtrlX"] = "ctrl+x";
    return ShourtcutifyEventKeys;
}({});
var ShourtcutifyModifierKeys = /*#__PURE__*/ function(ShourtcutifyModifierKeys) {
    ShourtcutifyModifierKeys["Ctrl"] = "control";
    ShourtcutifyModifierKeys["Alt"] = "alt";
    ShourtcutifyModifierKeys["Shift"] = "shift";
    ShourtcutifyModifierKeys["Meta"] = "meta";
    return ShourtcutifyModifierKeys;
}({});
var ShourtcutifyEvents;
}),
"[project]/contexts/EventContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventProvider",
    ()=>EventProvider,
    "useEventProvider",
    ()=>useEventProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$KeyboardManager$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/KeyboardManager.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$enums$2f$Enums$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/enums/Enums.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const defaultValue = {
    KeyboardManager: new __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$KeyboardManager$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](),
    Events: __TURBOPACK__imported__module__$5b$project$5d2f$enums$2f$Enums$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ShourtcutifyEvents"]
};
const EventContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(defaultValue);
const EventProvider = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EventContext.Provider, {
        value: {
            ...defaultValue
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/EventContext.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const useEventProvider = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(EventContext);
}),
"[project]/app/(main)/projects/utils/OptionLists.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "aprFinalizationSteps",
    ()=>aprFinalizationSteps,
    "enactDessaggregationOptions",
    ()=>enactDessaggregationOptions,
    "indevidualDessaggregationOptions",
    ()=>indevidualDessaggregationOptions,
    "isp3s",
    ()=>isp3s,
    "projectAprStatusList",
    ()=>projectAprStatusList,
    "sessionDessaggregationOptions",
    ()=>sessionDessaggregationOptions
]);
const sessionDessaggregationOptions = [
    "# 0f indevidual MHPSS consultations",
    "# 0f group MHPSS consultations"
];
const indevidualDessaggregationOptions = [
    "Of Male (above 18)",
    "Of Female (above 18)",
    "of Male adolescents (12 to 17 years old)",
    "of Female adolescents (12 to 17 years old)",
    "of Male children (6 to 11 years old)",
    "of Female children (6 to 11 years old)",
    "of Male CU5 (boys)",
    "of Female CU5 (girls)"
];
const enactDessaggregationOptions = [
    "# of supervised psychosocial counsellors",
    "# Accumulated score EQUIP (ENACT) Tool"
];
const isp3s = [
    "Improved Mental health and psychosocial well-being",
    "Total transfers for the MHPSS & Protection sector",
    "Reach of Care Practices",
    "Reach of Mental health and Psychosocial Support and Protection",
    "Reach of MHPSS, Care Practices and Protection capacity building activities",
    "Reach of MHPSS, Care Practices and Protection kits deliveries"
];
const projectAprStatusList = [
    "notCreatedYet",
    "created",
    "hodDhodApproved",
    "hodDhodRejected",
    "grantFinalized",
    "grantRejected",
    "hqFinalized",
    "hqRejected"
];
const aprFinalizationSteps = [
    {
        id: "create",
        buttonLabel: "Create",
        label: "Create",
        stepValue: 1,
        description: "This action will change the status of project to CREATED and send notification to manager for submitting.",
        acceptStatusValue: "created",
        permission: "Project.create"
    },
    {
        id: "submit",
        buttonLabel: "Submit",
        label: "Manager Submit",
        stepValue: 2,
        description: "This action will mark the project as submitted by manager.",
        acceptStatusValue: "hodDhodApproved",
        rejectStatusValue: "hodDhodRejected",
        permission: "Project.submit"
    },
    {
        id: "grantFinalize",
        buttonLebel: "Finalize",
        label: "Grant Finalization",
        stepValue: 3,
        description: "This action will finalize the grant and update project status.",
        acceptStatusValue: "grantFinalized",
        rejectStatusValue: "grantRejected",
        permission: "Project.grantFinalize"
    },
    {
        id: "hqFinalize",
        buttonLebel: "Finalize",
        label: "HQ Finalization",
        stepValue: 4,
        description: "This action will finalize the project at HQ level.",
        acceptStatusValue: "hqFinalized",
        rejectStatusValue: "hqRejected",
        permission: "Project.HQFinalize"
    }
];
}),
"[project]/helpers/GlobalHelpers.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemoveIdFielsFromObj",
    ()=>RemoveIdFielsFromObj
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
;
const RemoveIdFielsFromObj = (obj)=>{
    const objKeys = Object.keys(obj);
    for (const key of objKeys){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNonePrimitiveTypeAndNotNullOrUndefined"])(obj[key])) RemoveIdFielsFromObj(obj[key]);
        else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsIdFeild"])(key)) delete obj[key];
    }
    return obj;
}; // export const ChangeMultiLevelObjToOneLevelObj = (obj: {
 //   [key: string]: any;
 // }) => {
 //   const objKeys: string[] = Object.keys(obj);
 //   let newObj: { [key: string]: any } = {};
 //   for (const key of objKeys) {
 //     if (IsNonPrimitiveType(obj[key])) newObj = { ...newObj, ...obj[key] };
 //     else newObj = { ...newObj, [key]: obj[key] };
 //   }
 // };
}),
"[project]/constants/Constants.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AreArraysDeepEqual",
    ()=>AreArraysDeepEqual,
    "AreArraysShallowEqual",
    ()=>AreArraysShallowEqual,
    "AreDessaggregationsEdited",
    ()=>AreDessaggregationsEdited,
    "AreDessaggregationsTheSame",
    ()=>AreDessaggregationsTheSame,
    "AreObjectsStructureBaseDeepEqual",
    ()=>AreObjectsStructureBaseDeepEqual,
    "AreObjectsStructureBaseShallowEqual",
    ()=>AreObjectsStructureBaseShallowEqual,
    "AreObjectsValueBaseDeepEqual",
    ()=>AreObjectsValueBaseDeepEqual,
    "AtLeastOneProvinceSelectedForIndicator",
    ()=>AtLeastOneProvinceSelectedForIndicator,
    "HasDessaggregationTheseFeature",
    ()=>HasDessaggregationTheseFeature,
    "HasSubIndicator",
    ()=>HasSubIndicator,
    "IsANullOrUndefinedValue",
    ()=>IsANullOrUndefinedValue,
    "IsANullValue",
    ()=>IsANullValue,
    "IsAUndefinedValue",
    ()=>IsAUndefinedValue,
    "IsAltKeyPressed",
    ()=>IsAltKeyPressed,
    "IsCreateMode",
    ()=>IsCreateMode,
    "IsCreateOrEditMode",
    ()=>IsCreateOrEditMode,
    "IsCreateOrShowMode",
    ()=>IsCreateOrShowMode,
    "IsCreatePage",
    ()=>IsCreatePage,
    "IsCtrlKeyPressed",
    ()=>IsCtrlKeyPressed,
    "IsCurrentTypeOptionAvailable",
    ()=>IsCurrentTypeOptionAvailable,
    "IsCurrentTypeOptionHasBeenTakenByOtherIndicators",
    ()=>IsCurrentTypeOptionHasBeenTakenByOtherIndicators,
    "IsCurrentTypeOptionIsTheCurrentIndicatorOption",
    ()=>IsCurrentTypeOptionIsTheCurrentIndicatorOption,
    "IsDefined",
    ()=>IsDefined,
    "IsDeleteKey",
    ()=>IsDeleteKey,
    "IsDessaggregationSaved",
    ()=>IsDessaggregationSaved,
    "IsEditMode",
    ()=>IsEditMode,
    "IsEditOrShowMode",
    ()=>IsEditOrShowMode,
    "IsEditPage",
    ()=>IsEditPage,
    "IsEnterKey",
    ()=>IsEnterKey,
    "IsEnteredStatusCallingToBeApproveAtLevelAboveTheAllowedLevel",
    ()=>IsEnteredStatusCallingToBeApproveAtLevelAboveTheAllowedLevel,
    "IsEnteredStatusCallsToRejectAtTheLevelAboveTheCurrentLimit",
    ()=>IsEnteredStatusCallsToRejectAtTheLevelAboveTheCurrentLimit,
    "IsEnteredStatusLocaltedAtTheLowerLevelThenTheCurrentStatus",
    ()=>IsEnteredStatusLocaltedAtTheLowerLevelThenTheCurrentStatus,
    "IsEqual",
    ()=>IsEqual,
    "IsIdFeild",
    ()=>IsIdFeild,
    "IsIndicatorDatabaseEnactDatabase",
    ()=>IsIndicatorDatabaseEnactDatabase,
    "IsIndicatorDatabaseMainDatabase",
    ()=>IsIndicatorDatabaseMainDatabase,
    "IsIndicatorEdited",
    ()=>IsIndicatorEdited,
    "IsIndicatorRelatedToThisOutput",
    ()=>IsIndicatorRelatedToThisOutput,
    "IsIndicatorSaved",
    ()=>IsIndicatorSaved,
    "IsMainDatabase",
    ()=>IsMainDatabase,
    "IsMainDatabaseNotAvailableForSelection",
    ()=>IsMainDatabaseNotAvailableForSelection,
    "IsMetaKeyPressed",
    ()=>IsMetaKeyPressed,
    "IsNonPrimitiveType",
    ()=>IsNonPrimitiveType,
    "IsNonePrimitiveTypeAndNotNullOrUndefined",
    ()=>IsNonePrimitiveTypeAndNotNullOrUndefined,
    "IsNotANullOrUndefinedValue",
    ()=>IsNotANullOrUndefinedValue,
    "IsNotANullValue",
    ()=>IsNotANullValue,
    "IsNotCreateMode",
    ()=>IsNotCreateMode,
    "IsNotEditMode",
    ()=>IsNotEditMode,
    "IsNotIndicatorDatabaseEnactDatabase",
    ()=>IsNotIndicatorDatabaseEnactDatabase,
    "IsNotMainDatabase",
    ()=>IsNotMainDatabase,
    "IsNotShowMode",
    ()=>IsNotShowMode,
    "IsNotSubIndicator",
    ()=>IsNotSubIndicator,
    "IsOutcomeEdited",
    ()=>IsOutcomeEdited,
    "IsOutcomeSaved",
    ()=>IsOutcomeSaved,
    "IsOutputEdited",
    ()=>IsOutputEdited,
    "IsOutputRelatedToThisOutcome",
    ()=>IsOutputRelatedToThisOutcome,
    "IsOutputSaved",
    ()=>IsOutputSaved,
    "IsPrimitiveType",
    ()=>IsPrimitiveType,
    "IsPrimitiveTypeAndNotNullOrUndefined",
    ()=>IsPrimitiveTypeAndNotNullOrUndefined,
    "IsShiftKeyPressed",
    ()=>IsShiftKeyPressed,
    "IsShowMode",
    ()=>IsShowMode,
    "IsShowPage",
    ()=>IsShowPage,
    "IsTheDessaggregationOfThisIndicatorAndProvince",
    ()=>IsTheDessaggregationOfThisIndicatorAndProvince,
    "IsThereAndIndicatorWithEnteredReferanceAndDefferentId",
    ()=>IsThereAndIndicatorWithEnteredReferanceAndDefferentId,
    "IsThereAnyIndicatorWithEnteredReferance",
    ()=>IsThereAnyIndicatorWithEnteredReferance,
    "IsThereAnyOutcomeWithEnteredReferance",
    ()=>IsThereAnyOutcomeWithEnteredReferance,
    "IsThereAnyOutcomeWithEnteredReferanceAndDefferentId",
    ()=>IsThereAnyOutcomeWithEnteredReferanceAndDefferentId,
    "IsThereAnyOutputWithEnteredReferance",
    ()=>IsThereAnyOutputWithEnteredReferance,
    "IsThereAnyOutputWithEnteredReferanceAndDefferentId",
    ()=>IsThereAnyOutputWithEnteredReferanceAndDefferentId,
    "IsTotalOfDessaggregationsOfProvinceBiggerThenTotalOfProvince",
    ()=>IsTotalOfDessaggregationsOfProvinceBiggerThenTotalOfProvince,
    "IsTotalOfDessaggregationsOfProvinceLessThenTotalOfProvince",
    ()=>IsTotalOfDessaggregationsOfProvinceLessThenTotalOfProvince,
    "IsTypeOfValuesEqual",
    ()=>IsTypeOfValuesEqual,
    "IsTypeOfValuesSameAndPrimitive",
    ()=>IsTypeOfValuesSameAndPrimitive,
    "IsValidAprStatus",
    ()=>IsValidAprStatus,
    "IsValuesEqual",
    ()=>IsValuesEqual,
    "NoProvinceSelectedForIndicator",
    ()=>NoProvinceSelectedForIndicator,
    "NoProvinceSelectedForSubIndicator",
    ()=>NoProvinceSelectedForSubIndicator,
    "NotSavedYet",
    ()=>NotSavedYet,
    "WasIndexFound",
    ()=>WasIndexFound,
    "isNotASubIndicator",
    ()=>isNotASubIndicator,
    "isTheTotalTargetOfDessaggregationsEqualToTotalTargetOfIndicator",
    ()=>isTheTotalTargetOfDessaggregationsEqualToTotalTargetOfIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/utils/OptionLists.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/GlobalHelpers.tsx [app-ssr] (ecmascript)");
;
;
const IsValidAprStatus = (status)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["projectAprStatusList"].includes(status);
};
const IsEnteredStatusLocaltedAtTheLowerLevelThenTheCurrentStatus = (projectAprStatus, status)=>{
    const projectCurrentStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>step.acceptStatusValue == projectAprStatus || step.rejectStatusValue == projectAprStatus)?.stepValue;
    const inputAcceptStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>step.acceptStatusValue == status)?.stepValue;
    return projectCurrentStatusValue && inputAcceptStatusValue && projectCurrentStatusValue > inputAcceptStatusValue;
};
const IsEnteredStatusCallsToRejectAtTheLevelAboveTheCurrentLimit = (projectAprStatus, status)=>{
    const projectCurrentStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>step.acceptStatusValue == projectAprStatus || step.rejectStatusValue == projectAprStatus)?.stepValue;
    const inputRejectStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>step.rejectStatusValue == status)?.stepValue;
    return projectCurrentStatusValue && inputRejectStatusValue && projectCurrentStatusValue < inputRejectStatusValue;
};
const IsEnteredStatusCallingToBeApproveAtLevelAboveTheAllowedLevel = (projectAprStatus, status)=>{
    let isRejected = false;
    const projectCurrentStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>{
        if (step.acceptStatusValue == projectAprStatus) return true;
        else if (step.rejectStatusValue == projectAprStatus) {
            isRejected = true;
            return true;
        }
        return false;
    })?.stepValue;
    const inputRejectStatusValue = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].find((step)=>step.rejectStatusValue == status || step.acceptStatusValue == status)?.stepValue;
    return projectCurrentStatusValue && inputRejectStatusValue && (projectCurrentStatusValue - inputRejectStatusValue) * -1 >= (isRejected ? 1 : 2);
};
const IsMainDatabaseNotAvailableForSelection = (indicators)=>{
    return indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == "adult_psychosocial_support") && indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == "child_psychosocial_support") && indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == "parenting_skills") && indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == "child_care_practices");
};
const IsCurrentTypeOptionAvailable = (indicators, option, localIndicator)=>{
    return indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == option.value && indicator.id !== localIndicator.id);
};
const IsMainDatabase = (indicator)=>{
    return indicator.database == "main_database";
};
const HasSubIndicator = (indicator)=>{
    return indicator.subIndicator !== null;
};
const isTheTotalTargetOfDessaggregationsEqualToTotalTargetOfIndicator = (selectedIndicator, dessaggregations)=>{
    const selectedIndicatorId = selectedIndicator.id;
    const subIndicatorId = selectedIndicator.subIndicator?.id ?? null;
    let mainTotal = 0;
    let subTotal = 0;
    dessaggregations.forEach((d)=>{
        if (d.indicatorId == selectedIndicatorId) mainTotal += Number(d.target);
        if (subIndicatorId && d.indicatorId == subIndicatorId) subTotal += Number(d.target);
    });
    const mainTarget = Number(selectedIndicator.target ?? 0);
    const subTarget = Number(selectedIndicator.subIndicator?.target ?? 0);
    if (mainTarget === mainTotal && (!subIndicatorId || subTarget === subTotal)) {
        return false;
    }
    return true;
};
const IsThereAnyOutputWithEnteredReferance = (outputs, enteredReferance)=>{
    return outputs.some((output)=>output.outputRef == enteredReferance);
};
const IsThereAnyOutputWithEnteredReferanceAndDefferentId = (outputs, enteredOutput)=>{
    return outputs.some((output)=>output.outputRef === enteredOutput.outputRef && output.id !== enteredOutput.id);
};
const IsThereAnyOutcomeWithEnteredReferance = (outcomes, outcome)=>{
    return outcomes.some((o)=>o.outcomeRef == outcome.outcomeRef);
};
const IsThereAnyOutcomeWithEnteredReferanceAndDefferentId = (outcomes, outcome)=>{
    return outcomes.some((o)=>o.outcomeRef == outcome.outcomeRef && o.id != outcome.id);
};
const IsCreateMode = (mode)=>{
    return mode == "create";
};
const IsEditMode = (mode)=>{
    return mode == "edit" || mode == "update";
};
const IsShowMode = (mode)=>{
    return mode == "show";
};
const IsNotCreateMode = (mode)=>{
    return mode != "create";
};
const IsNotEditMode = (mode)=>{
    return mode != "edit" && mode != "update";
};
const IsNotShowMode = (mode)=>{
    return mode != "show";
};
const IsCreateOrEditMode = (mode)=>{
    return mode == "create" || mode == "edit" || mode == "update";
};
const IsEditOrShowMode = (mode)=>{
    return mode == "edit" || mode == "update" || mode == "show";
};
const IsCreateOrShowMode = (mode)=>{
    return mode == "create" || mode == "show";
};
const HasDessaggregationTheseFeature = (dessaggregation, description, province, indicatorRef)=>{
    return dessaggregation.dessaggration === description && dessaggregation.province === province && dessaggregation.indicatorRef === indicatorRef;
};
const IsTotalOfDessaggregationsOfProvinceBiggerThenTotalOfProvince = (dessaggregationsTotal, provinceTotal)=>{
    return dessaggregationsTotal > provinceTotal;
};
const IsTotalOfDessaggregationsOfProvinceLessThenTotalOfProvince = (dessaggregationsTotal, provinceTotal)=>{
    return dessaggregationsTotal < provinceTotal;
};
const WasIndexFound = (index)=>{
    return index !== -1;
};
const IsTheDessaggregationOfThisIndicatorAndProvince = (dessaggration, province, indicatorRef)=>{
    return dessaggration.province === province && dessaggration.indicatorRef === indicatorRef;
};
const IsIndicatorDatabaseMainDatabase = (indicator)=>{
    return indicator.database == "main_database";
};
const IsIndicatorDatabaseEnactDatabase = (indicator)=>{
    return indicator.database == "enact_database";
};
const IsNotIndicatorDatabaseEnactDatabase = (indicator)=>{
    return indicator.database != "enact_database";
};
const AreDessaggregationsTheSame = (firstDessaggregation, secondDessaggregation)=>{
    return firstDessaggregation.dessaggration == secondDessaggregation.dessaggration && firstDessaggregation.indicatorRef == secondDessaggregation.indicatorRef && firstDessaggregation.province == secondDessaggregation.province && firstDessaggregation.target == secondDessaggregation.target;
};
const AreDessaggregationsEdited = (dessaggrationsBeforeEdit, dessaggrationsAfterEdit)=>{
    let areEqual = true;
    if (dessaggrationsBeforeEdit.length != dessaggrationsAfterEdit.length) areEqual = false;
    if (areEqual) for (let dessaggration of dessaggrationsBeforeEdit)areEqual = !!dessaggrationsAfterEdit.find((d)=>AreDessaggregationsTheSame(d, dessaggration));
    return !areEqual;
};
const IsIdFeild = (feildName)=>{
    return feildName == "id";
};
const IsCurrentTypeOptionIsTheCurrentIndicatorOption = (indicator, typeOption)=>{
    return indicator.type === typeOption;
};
const IsCurrentTypeOptionHasBeenTakenByOtherIndicators = (indicators, typeOption)=>{
    return !indicators.find((indicator)=>indicator.database == "main_database" && indicator.type == typeOption);
};
const IsThereAnyIndicatorWithEnteredReferance = (indicators, enteredRef)=>{
    return indicators.some((indicator)=>indicator.indicatorRef == enteredRef);
};
const IsThereAndIndicatorWithEnteredReferanceAndDefferentId = (indicators, indicator)=>{
    return indicators.some((i)=>i.indicatorRef == indicator.indicatorRef && i.id !== indicator.id);
};
const IsIndicatorRelatedToThisOutput = (outputId, indicatorOutputId)=>{
    return outputId === indicatorOutputId;
};
const IsOutputRelatedToThisOutcome = (outcomeId, outputOutcomeId)=>{
    return outcomeId === outputOutcomeId;
};
const IsNotMainDatabase = (database)=>{
    return database != "main_database";
};
const IsOutputSaved = (output)=>{
    return output.id !== null;
};
const IsOutcomeSaved = (outcome)=>{
    return outcome.id !== null;
};
const IsANullValue = (value)=>{
    return value == null;
};
const IsNotANullValue = (value)=>{
    return value != null;
};
const IsCreatePage = (pageIdentifier)=>{
    return pageIdentifier == "create";
};
const IsEditPage = (pageIdentifier)=>{
    return pageIdentifier == "edit";
};
const IsShowPage = (pageIdentifier)=>{
    return pageIdentifier == "show";
};
const IsIndicatorSaved = (indicator)=>{
    return IsNotANullValue(indicator.id);
};
const NotSavedYet = (value)=>{
    return value.id == null;
};
const IsDessaggregationSaved = (dessaggration)=>{
    return IsNotANullValue(dessaggration.id);
};
const isNotASubIndicator = (subIndicator)=>{
    return subIndicator == null;
};
const NoProvinceSelectedForIndicator = (indicator)=>{
    return indicator.provinces.length == 0;
};
const NoProvinceSelectedForSubIndicator = (subIndicator)=>{
    return subIndicator.provinces.length == 0;
};
const AtLeastOneProvinceSelectedForIndicator = (indicator)=>{
    return indicator.provinces.length >= 1;
};
const AreObjectsStructureBaseShallowEqual = (first, second)=>{
    const firstKeys = Object.keys(first);
    const secondKeys = Object.keys(second);
    if (firstKeys.length !== secondKeys.length) return false;
    return firstKeys.every((key)=>first[key] == second[key]);
};
const AreObjectsStructureBaseDeepEqual = (first, second)=>{
    if (first === second) return true;
    if (typeof first !== "object" || typeof second !== "object" || first === null || second === null) return false;
    const firstKeys = Object.keys(first);
    const secondKeys = Object.keys(second);
    for (const key of firstKeys){
        if (!secondKeys.includes(key)) return false;
        if (!AreObjectsStructureBaseDeepEqual(first[key], second[key])) return false;
    }
    return true;
};
const AreArraysShallowEqual = (first, second)=>{
    if (first.length !== second.length) return false;
    const secondCopy = [
        ...second
    ];
    for (const itemFirst of first){
        const index = secondCopy.findIndex((item)=>IsEqual(item, itemFirst));
        if (index === -1) return false;
        secondCopy.splice(index, 1);
    }
    return true;
};
const IsEqual = (first, second)=>{
    if (first === second) return true;
    if (IsTypeOfValuesSameAndPrimitive(first, second) && IsValuesEqual(first, second)) return true;
    if (IsNonPrimitiveType(first) && IsNonPrimitiveType(second) && AreObjectsValueBaseDeepEqual(first, second)) return true;
    return false;
};
const AreArraysDeepEqual = (first, second)=>{
    if (first.length != second.length) return false;
    for(const index in first)if (first[index] !== second[index]) return false;
    return true;
};
const IsTypeOfValuesEqual = (first, second)=>{
    return typeof first === typeof second;
};
const IsValuesEqual = (first, second)=>{
    return first === second;
};
const IsPrimitiveType = (value)=>{
    return typeof value == "string" || typeof value == "boolean" || typeof value == "number" || typeof value == null || typeof value == undefined || typeof value == "symbol" || typeof value == "bigint";
};
const IsPrimitiveTypeAndNotNullOrUndefined = (value)=>{
    return IsNotANullOrUndefinedValue(value) && IsPrimitiveType(value);
};
const IsNonPrimitiveType = (value)=>{
    return typeof value == "object";
};
const IsNonePrimitiveTypeAndNotNullOrUndefined = (value)=>{
    return IsNotANullOrUndefinedValue(value) && IsNonPrimitiveType(value);
};
const IsTypeOfValuesSameAndPrimitive = (first, second)=>{
    return IsTypeOfValuesEqual(first, second) && IsPrimitiveType(first) && IsPrimitiveType(second);
};
const IsAUndefinedValue = (value)=>{
    return value === undefined;
};
const IsANullOrUndefinedValue = (value)=>{
    return value === null || value == undefined;
};
const AreObjectsValueBaseDeepEqual = (first, second)=>{
    const checkIfObjectsAreStructureBaseDeepEqual = AreObjectsStructureBaseDeepEqual(first, second);
    if (checkIfObjectsAreStructureBaseDeepEqual) {
        const firstKeys = Object.keys(first);
        for (const key of firstKeys){
            if (!IsTypeOfValuesEqual(first[key], second[key])) {
                /* eslint-disable */ console.log(...oo_oo(`3594438441_608_8_608_22_4`, 1));
                return false;
            } else if (IsTypeOfValuesSameAndPrimitive(first[key], second[key]) && first[key] !== second[key]) return false;
            else if (Array.isArray(first[key]) && Array.isArray(second[key]) && !AreArraysShallowEqual(first[key], second[key])) return false;
            else if (IsNonePrimitiveTypeAndNotNullOrUndefined(first[key]) && !AreObjectsValueBaseDeepEqual(first[key], second[key])) return false;
            else if (IsANullOrUndefinedValue(first[key]) && IsANullOrUndefinedValue(second[key]) && !(first[key] === second[key])) return false;
        }
        return true;
    }
    return false;
};
const IsIndicatorEdited = (indicatorBeforeEdit, indicatorAfterEdit)=>{
    const indicatorBeforeEditCopy = {
        ...indicatorBeforeEdit
    };
    const indicatorAfterEditCopy = {
        ...indicatorAfterEdit
    };
    const indicatorBeforeEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(indicatorBeforeEditCopy);
    const indicatorAfterEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(indicatorAfterEditCopy);
    return !AreObjectsValueBaseDeepEqual(indicatorBeforeEditCopyWithoutIdFeilds, indicatorAfterEditCopyWithoutIdFeilds);
};
const IsOutcomeEdited = (outcomeBeforeEdit, outcomeAfterEdit)=>{
    const outcomeBeforeEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(outcomeBeforeEdit);
    const outcomeAfterEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(outcomeAfterEdit);
    return !AreObjectsValueBaseDeepEqual(outcomeBeforeEditCopyWithoutIdFeilds, outcomeAfterEditCopyWithoutIdFeilds);
};
const IsOutputEdited = (outputBeforeEdit, outputAfterEdit)=>{
    const outputBeforeEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(outputBeforeEdit);
    const outputAfterEditCopyWithoutIdFeilds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(outputAfterEdit);
    return !AreObjectsValueBaseDeepEqual(outputBeforeEditCopyWithoutIdFeilds, outputAfterEditCopyWithoutIdFeilds);
};
const IsNotANullOrUndefinedValue = (value)=>{
    return value !== null && value !== undefined;
};
function IsDefined(value) {
    return value !== undefined;
}
const IsEnterKey = (key)=>{
    return key === "Enter";
};
const IsDeleteKey = (key)=>{
    return key === "Delete";
};
const IsCtrlKeyPressed = (ctrlKey)=>{
    return ctrlKey === true;
};
const IsShiftKeyPressed = (shiftKey)=>{
    return shiftKey === true;
};
const IsAltKeyPressed = (altKey)=>{
    return altKey === true;
};
const IsMetaKeyPressed = (metaKey)=>{
    return metaKey === true;
};
const IsNotSubIndicator = (indicator)=>{
    return IsANullOrUndefinedValue(indicator.parent_indicator);
};
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5eb7(){var _0x5312cb=['3256wREwNO','negativeZero','startsWith','toUpperCase','NEGATIVE_INFINITY','defaultLimits','length','_connected','5kjcSVz','next.js','213606VniQVN','origin','bigint','_connecting','get','then','Symbol','Map','index','funcName','resetWhenQuietMs','_isMap','type','2241WiVaRR','object','warn','nodeModules','node','1766730179713','1284920DYQWdu','_hasMapOnItsPath','sortProps','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','_setNodeLabel','now','hostname','POSITIVE_INFINITY','expressionsToEvaluate','4787388frDXrm','totalStrLength','','reduceOnCount','autoExpandLimit','_webSocketErrorDocsLink','3810','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','_processTreeNodeResult','edge','_connectAttemptCount','_ws','\\x20server','logger\\x20websocket\\x20error','1437783aYwZoA','reduceLimits','unshift','unknown','onerror','replace','hrtime','_HTMLAllCollection','expId','console','reload','root_exp_id','parent','allStrLength','strLength','setter','sort','_console_ninja','_capIfString','root_exp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','undefined','_type','_p_','_socket','_setNodeQueryPath','','log','port','_hasSetOnItsPath','capped','_p_name','host','reducedLimits','127.0.0.1','[object\\x20Set]','onmessage','value','_cleanNode','resolveGetters','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','substr','performance','autoExpandPreviousObjects','prototype','onopen','_allowedToSend','_getOwnPropertyNames','_treeNodePropertiesBeforeFullValue','indexOf','import(\\x27path\\x27)','slice','bind','_treeNodePropertiesAfterFullValue','constructor','[object\\x20Date]','perLogpoint','pop','_setNodeExpandableState','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','call','null','current','serialize','readyState','[object\\x20BigInt]','_getOwnPropertySymbols','_isSet','1078085AFsroT','autoExpand','count','trace','valueOf','isExpressionToEvaluate','_allowedToConnectOnSend','time','toLowerCase','gateway.docker.internal','path','hits','resolve','_additionalMetadata','fromCharCode','stack',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'next.js','_addProperty','_getOwnPropertyDescriptor','versions','symbol','close','_quotedRegExp','map','Set','default','NEXT_RUNTIME','Number','_inNextEdge','args','_sortProps','_ninjaIgnoreNextError','send','onclose','push','unref','error','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','33847uocYVR','process','getWebSocketClass','autoExpandPropertyCount','iterator','reducePolicy','_inBrowser','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','7710dhZant','toString','rootExpression','array','expo','_maxConnectAttemptCount','charAt','elements','eventReceivedCallback','forEach','_disposeWebsocket','_objectToString','modules','1.0.0','\\x20browser','Boolean','function','_WebSocket','env','reduceOnAccumulatedProcessingTimeMs','endsWith','Error','_extendedWarning','match','_isUndefined','positiveInfinity','_setNodePermissions','...','url','resetOnProcessingTimeAverageMs','getter','negativeInfinity','_blacklistedProperty','_Symbol','name','osName','Buffer','emulator','perf_hooks','[object\\x20Array]','stackTraceLimit','Promise','_WebSocketClass','cappedElements','_isNegativeZero','global','catch','_dateToString','noFunctions','_reconnectTimeout','_connectToHostNow','test','_setNodeId','string','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_addLoadNode','_sendErrorMessage','location','_consoleNinjaAllowedToStart','4OBrhKf','props','_hasSymbolPropertyOnItsPath','level','_isPrimitiveType','_isArray','dockerizedApp','includes','_setNodeExpressionPath','react-native','concat','coverage','HTMLAllCollection','1','_attemptToReconnectShortly','message','split','timeStamp','_console_ninja_session','number','disabledTrace','_property','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_propertyName','_addObjectProperty','depth','String','_addFunctionsNode','data','_keyStrRegExp','getOwnPropertySymbols','autoExpandMaxDepth','ninjaSuppressConsole','_undefined','WebSocket','elapsed'];_0x5eb7=function(){return _0x5312cb;};return _0x5eb7();}var _0x548f0e=_0x49dd;(function(_0x3b8ea0,_0xb09101){var _0x276847=_0x49dd,_0x13198e=_0x3b8ea0();while(!![]){try{var _0xeebb23=-parseInt(_0x276847(0x130))/0x1*(parseInt(_0x276847(0x132))/0x2)+-parseInt(_0x276847(0x15c))/0x3+parseInt(_0x276847(0x20a))/0x4*(-parseInt(_0x276847(0x1a0))/0x5)+-parseInt(_0x276847(0x14e))/0x6+parseInt(_0x276847(0x145))/0x7+parseInt(_0x276847(0x128))/0x8*(-parseInt(_0x276847(0x13f))/0x9)+-parseInt(_0x276847(0x1cf))/0xa*(-parseInt(_0x276847(0x1c7))/0xb);if(_0xeebb23===_0xb09101)break;else _0x13198e['push'](_0x13198e['shift']());}catch(_0x3b433b){_0x13198e['push'](_0x13198e['shift']());}}}(_0x5eb7,0x68711));function z(_0x313b23,_0x229f6c,_0x11a6ff,_0x3283bf,_0x5f230b,_0x10232d){var _0xa85961=_0x49dd,_0x48df31,_0x291315,_0x559566,_0x37b425;this[_0xa85961(0x1fc)]=_0x313b23,this[_0xa85961(0x17c)]=_0x229f6c,this['port']=_0x11a6ff,this[_0xa85961(0x142)]=_0x3283bf,this[_0xa85961(0x10a)]=_0x5f230b,this[_0xa85961(0x1d7)]=_0x10232d,this['_allowedToSend']=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0xa85961(0x12f)]=!0x1,this[_0xa85961(0x135)]=!0x1,this[_0xa85961(0x1bd)]=((_0x291315=(_0x48df31=_0x313b23[_0xa85961(0x1c8)])==null?void 0x0:_0x48df31[_0xa85961(0x1e1)])==null?void 0x0:_0x291315[_0xa85961(0x1bb)])===_0xa85961(0x157),this[_0xa85961(0x1cd)]=!((_0x37b425=(_0x559566=this[_0xa85961(0x1fc)][_0xa85961(0x1c8)])==null?void 0x0:_0x559566[_0xa85961(0x1b4)])!=null&&_0x37b425['node'])&&!this[_0xa85961(0x1bd)],this[_0xa85961(0x1f9)]=null,this[_0xa85961(0x158)]=0x0,this['_maxConnectAttemptCount']=0x14,this['_webSocketErrorDocsLink']='https://tinyurl.com/37x8b79t',this['_sendErrorMessage']=(this[_0xa85961(0x1cd)]?'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20':_0xa85961(0x1ce))+this['_webSocketErrorDocsLink'];}z[_0x548f0e(0x188)][_0x548f0e(0x1c9)]=async function(){var _0x16d2fc=_0x548f0e,_0x31fecd,_0x1f5c70;if(this[_0x16d2fc(0x1f9)])return this[_0x16d2fc(0x1f9)];let _0xfb36cd;if(this[_0x16d2fc(0x1cd)]||this['_inNextEdge'])_0xfb36cd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x126)];else{if((_0x31fecd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])!=null&&_0x31fecd[_0x16d2fc(0x1e0)])_0xfb36cd=(_0x1f5c70=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])==null?void 0x0:_0x1f5c70[_0x16d2fc(0x1e0)];else try{_0xfb36cd=(await new Function(_0x16d2fc(0x1aa),_0x16d2fc(0x1eb),'nodeModules',_0x16d2fc(0x170))(await(0x0,eval)(_0x16d2fc(0x18e)),await(0x0,eval)('import(\\x27url\\x27)'),this[_0x16d2fc(0x142)]))[_0x16d2fc(0x1ba)];}catch{try{_0xfb36cd=require(require(_0x16d2fc(0x1aa))['join'](this[_0x16d2fc(0x142)],'ws'));}catch{throw new Error(_0x16d2fc(0x205));}}}return this[_0x16d2fc(0x1f9)]=_0xfb36cd,_0xfb36cd;},z[_0x548f0e(0x188)]['_connectToHostNow']=function(){var _0x3932b3=_0x548f0e;this[_0x3932b3(0x135)]||this[_0x3932b3(0x12f)]||this[_0x3932b3(0x158)]>=this[_0x3932b3(0x1d4)]||(this[_0x3932b3(0x1a6)]=!0x1,this[_0x3932b3(0x135)]=!0x0,this['_connectAttemptCount']++,this['_ws']=new Promise((_0x239dde,_0x309d9a)=>{var _0x4a4aeb=_0x3932b3;this[_0x4a4aeb(0x1c9)]()[_0x4a4aeb(0x137)](_0x23579d=>{var _0x29a84d=_0x4a4aeb;let _0x4019f0=new _0x23579d('ws://'+(!this[_0x29a84d(0x1cd)]&&this['dockerizedApp']?_0x29a84d(0x1a9):this['host'])+':'+this[_0x29a84d(0x178)]);_0x4019f0[_0x29a84d(0x160)]=()=>{var _0x4d456f=_0x29a84d;this['_allowedToSend']=!0x1,this[_0x4d456f(0x1d9)](_0x4019f0),this['_attemptToReconnectShortly'](),_0x309d9a(new Error(_0x4d456f(0x15b)));},_0x4019f0['onopen']=()=>{var _0x338227=_0x29a84d;this[_0x338227(0x1cd)]||_0x4019f0[_0x338227(0x174)]&&_0x4019f0[_0x338227(0x174)]['unref']&&_0x4019f0[_0x338227(0x174)][_0x338227(0x1c4)](),_0x239dde(_0x4019f0);},_0x4019f0[_0x29a84d(0x1c2)]=()=>{var _0x494a4c=_0x29a84d;this[_0x494a4c(0x1a6)]=!0x0,this[_0x494a4c(0x1d9)](_0x4019f0),this[_0x494a4c(0x112)]();},_0x4019f0[_0x29a84d(0x180)]=_0x3160ad=>{var _0x2bd4b5=_0x29a84d;try{if(!(_0x3160ad!=null&&_0x3160ad[_0x2bd4b5(0x120)])||!this[_0x2bd4b5(0x1d7)])return;let _0xbd6af=JSON['parse'](_0x3160ad[_0x2bd4b5(0x120)]);this['eventReceivedCallback'](_0xbd6af['method'],_0xbd6af[_0x2bd4b5(0x1be)],this['global'],this[_0x2bd4b5(0x1cd)]);}catch{}};})[_0x4a4aeb(0x137)](_0x1e115d=>(this[_0x4a4aeb(0x12f)]=!0x0,this[_0x4a4aeb(0x135)]=!0x1,this[_0x4a4aeb(0x1a6)]=!0x1,this[_0x4a4aeb(0x18a)]=!0x0,this['_connectAttemptCount']=0x0,_0x1e115d))[_0x4a4aeb(0x1fd)](_0x307016=>(this[_0x4a4aeb(0x12f)]=!0x1,this[_0x4a4aeb(0x135)]=!0x1,console[_0x4a4aeb(0x141)](_0x4a4aeb(0x148)+this[_0x4a4aeb(0x153)]),_0x309d9a(new Error(_0x4a4aeb(0x1c6)+(_0x307016&&_0x307016[_0x4a4aeb(0x113)])))));}));},z['prototype'][_0x548f0e(0x1d9)]=function(_0x583632){var _0x13adc4=_0x548f0e;this[_0x13adc4(0x12f)]=!0x1,this['_connecting']=!0x1;try{_0x583632[_0x13adc4(0x1c2)]=null,_0x583632[_0x13adc4(0x160)]=null,_0x583632[_0x13adc4(0x189)]=null;}catch{}try{_0x583632[_0x13adc4(0x19c)]<0x2&&_0x583632[_0x13adc4(0x1b6)]();}catch{}},z[_0x548f0e(0x188)][_0x548f0e(0x112)]=function(){var _0x5036a5=_0x548f0e;clearTimeout(this[_0x5036a5(0x200)]),!(this[_0x5036a5(0x158)]>=this[_0x5036a5(0x1d4)])&&(this[_0x5036a5(0x200)]=setTimeout(()=>{var _0x3cf797=_0x5036a5,_0x15c27f;this[_0x3cf797(0x12f)]||this[_0x3cf797(0x135)]||(this[_0x3cf797(0x201)](),(_0x15c27f=this['_ws'])==null||_0x15c27f[_0x3cf797(0x1fd)](()=>this[_0x3cf797(0x112)]()));},0x1f4),this['_reconnectTimeout']['unref']&&this[_0x5036a5(0x200)][_0x5036a5(0x1c4)]());},z[_0x548f0e(0x188)][_0x548f0e(0x1c1)]=async function(_0x3246fb){var _0x3a41c5=_0x548f0e;try{if(!this[_0x3a41c5(0x18a)])return;this[_0x3a41c5(0x1a6)]&&this[_0x3a41c5(0x201)](),(await this[_0x3a41c5(0x159)])[_0x3a41c5(0x1c1)](JSON['stringify'](_0x3246fb));}catch(_0x2c0162){this[_0x3a41c5(0x1e5)]?console['warn'](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162[_0x3a41c5(0x113)])):(this[_0x3a41c5(0x1e5)]=!0x0,console[_0x3a41c5(0x141)](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162['message']),_0x3246fb)),this[_0x3a41c5(0x18a)]=!0x1,this[_0x3a41c5(0x112)]();}};function H(_0x708fe1,_0x3ad9bb,_0x1f357c,_0x5c3d72,_0x57da2a,_0x8bfd1c,_0x547194,_0x427ae0=ne){var _0x35b9cb=_0x548f0e;let _0x1a1b39=_0x1f357c[_0x35b9cb(0x114)](',')['map'](_0x1779fe=>{var _0x75e4e5=_0x35b9cb,_0x1c1066,_0x27d331,_0x28e1f6,_0xbdba49,_0x48a083,_0x3e9b5c,_0x282392,_0x1fe787;try{if(!_0x708fe1[_0x75e4e5(0x116)]){let _0x786a32=((_0x27d331=(_0x1c1066=_0x708fe1[_0x75e4e5(0x1c8)])==null?void 0x0:_0x1c1066[_0x75e4e5(0x1b4)])==null?void 0x0:_0x27d331[_0x75e4e5(0x143)])||((_0xbdba49=(_0x28e1f6=_0x708fe1['process'])==null?void 0x0:_0x28e1f6[_0x75e4e5(0x1e1)])==null?void 0x0:_0xbdba49[_0x75e4e5(0x1bb)])===_0x75e4e5(0x157);(_0x57da2a===_0x75e4e5(0x1b1)||_0x57da2a==='remix'||_0x57da2a==='astro'||_0x57da2a==='angular')&&(_0x57da2a+=_0x786a32?_0x75e4e5(0x15a):_0x75e4e5(0x1dd));let _0x4af9b3='';_0x57da2a===_0x75e4e5(0x10d)&&(_0x4af9b3=(((_0x282392=(_0x3e9b5c=(_0x48a083=_0x708fe1[_0x75e4e5(0x1d3)])==null?void 0x0:_0x48a083[_0x75e4e5(0x1db)])==null?void 0x0:_0x3e9b5c['ExpoDevice'])==null?void 0x0:_0x282392[_0x75e4e5(0x1f2)])||_0x75e4e5(0x1f4))[_0x75e4e5(0x1a8)](),_0x4af9b3&&(_0x57da2a+='\\x20'+_0x4af9b3,(_0x4af9b3==='android'||_0x4af9b3==='emulator'&&((_0x1fe787=_0x708fe1[_0x75e4e5(0x208)])==null?void 0x0:_0x1fe787[_0x75e4e5(0x14b)])==='10.0.2.2')&&(_0x3ad9bb='10.0.2.2'))),_0x708fe1[_0x75e4e5(0x116)]={'id':+new Date(),'tool':_0x57da2a},_0x547194&&_0x57da2a&&!_0x786a32&&(_0x4af9b3?console[_0x75e4e5(0x177)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x4af9b3+',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'):console[_0x75e4e5(0x177)](_0x75e4e5(0x197)+(_0x57da2a[_0x75e4e5(0x1d5)](0x0)[_0x75e4e5(0x12b)]()+_0x57da2a['substr'](0x1))+',',_0x75e4e5(0x155),_0x75e4e5(0x11a)));}let _0x229d61=new z(_0x708fe1,_0x3ad9bb,_0x1779fe,_0x5c3d72,_0x8bfd1c,_0x427ae0);return _0x229d61[_0x75e4e5(0x1c1)][_0x75e4e5(0x190)](_0x229d61);}catch(_0x207f65){return console[_0x75e4e5(0x141)](_0x75e4e5(0x184),_0x207f65&&_0x207f65[_0x75e4e5(0x113)]),()=>{};}});return _0x3ca2fe=>_0x1a1b39['forEach'](_0x570669=>_0x570669(_0x3ca2fe));}function ne(_0xfba01b,_0x5795ac,_0x526e6d,_0x23f0bc){var _0x88e87e=_0x548f0e;_0x23f0bc&&_0xfba01b===_0x88e87e(0x166)&&_0x526e6d[_0x88e87e(0x208)][_0x88e87e(0x166)]();}function b(_0x1c035d){var _0x33fbbc=_0x548f0e,_0x38efc3,_0xd2aec9;let _0x2a75b9=function(_0x448dbf,_0x3bc12f){return _0x3bc12f-_0x448dbf;},_0x22bb27;if(_0x1c035d[_0x33fbbc(0x186)])_0x22bb27=function(){var _0x5310e0=_0x33fbbc;return _0x1c035d[_0x5310e0(0x186)][_0x5310e0(0x14a)]();};else{if(_0x1c035d[_0x33fbbc(0x1c8)]&&_0x1c035d['process'][_0x33fbbc(0x162)]&&((_0xd2aec9=(_0x38efc3=_0x1c035d['process'])==null?void 0x0:_0x38efc3[_0x33fbbc(0x1e1)])==null?void 0x0:_0xd2aec9[_0x33fbbc(0x1bb)])!==_0x33fbbc(0x157))_0x22bb27=function(){var _0x4e9093=_0x33fbbc;return _0x1c035d['process'][_0x4e9093(0x162)]();},_0x2a75b9=function(_0x3c76d8,_0x527272){return 0x3e8*(_0x527272[0x0]-_0x3c76d8[0x0])+(_0x527272[0x1]-_0x3c76d8[0x1])/0xf4240;};else try{let {performance:_0x3d6831}=require(_0x33fbbc(0x1f5));_0x22bb27=function(){return _0x3d6831['now']();};}catch{_0x22bb27=function(){return+new Date();};}}return{'elapsed':_0x2a75b9,'timeStamp':_0x22bb27,'now':()=>Date['now']()};}function X(_0x3759c2,_0x327f60,_0x4ef84f){var _0x3c31ac=_0x548f0e,_0xa92efe,_0x3de67f,_0x8ece1a,_0x16959d,_0x5c93bf,_0x3ba4cf,_0x41f351;if(_0x3759c2[_0x3c31ac(0x209)]!==void 0x0)return _0x3759c2[_0x3c31ac(0x209)];let _0x5474b8=((_0x3de67f=(_0xa92efe=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0xa92efe[_0x3c31ac(0x1b4)])==null?void 0x0:_0x3de67f[_0x3c31ac(0x143)])||((_0x16959d=(_0x8ece1a=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0x8ece1a['env'])==null?void 0x0:_0x16959d[_0x3c31ac(0x1bb)])===_0x3c31ac(0x157),_0x2e5086=!!(_0x4ef84f===_0x3c31ac(0x10d)&&((_0x5c93bf=_0x3759c2[_0x3c31ac(0x1d3)])==null?void 0x0:_0x5c93bf['modules']));function _0x165bf6(_0x327d5a){var _0x2198ff=_0x3c31ac;if(_0x327d5a[_0x2198ff(0x12a)]('/')&&_0x327d5a[_0x2198ff(0x1e3)]('/')){let _0x4ee469=new RegExp(_0x327d5a[_0x2198ff(0x18f)](0x1,-0x1));return _0x1a743c=>_0x4ee469[_0x2198ff(0x202)](_0x1a743c);}else{if(_0x327d5a[_0x2198ff(0x10b)]('*')||_0x327d5a[_0x2198ff(0x10b)]('?')){let _0x3c6f9e=new RegExp('^'+_0x327d5a[_0x2198ff(0x161)](/\\./g,String[_0x2198ff(0x1ae)](0x5c)+'.')['replace'](/\\*/g,'.*')[_0x2198ff(0x161)](/\\?/g,'.')+String[_0x2198ff(0x1ae)](0x24));return _0x1ed757=>_0x3c6f9e[_0x2198ff(0x202)](_0x1ed757);}else return _0x934f30=>_0x934f30===_0x327d5a;}}let _0x276fbc=_0x327f60[_0x3c31ac(0x1b8)](_0x165bf6);return _0x3759c2['_consoleNinjaAllowedToStart']=_0x5474b8||!_0x327f60,!_0x3759c2['_consoleNinjaAllowedToStart']&&((_0x3ba4cf=_0x3759c2[_0x3c31ac(0x208)])==null?void 0x0:_0x3ba4cf[_0x3c31ac(0x14b)])&&(_0x3759c2['_consoleNinjaAllowedToStart']=_0x276fbc['some'](_0x593d63=>_0x593d63(_0x3759c2[_0x3c31ac(0x208)][_0x3c31ac(0x14b)]))),_0x2e5086&&!_0x3759c2[_0x3c31ac(0x209)]&&!((_0x41f351=_0x3759c2[_0x3c31ac(0x208)])!=null&&_0x41f351[_0x3c31ac(0x14b)])&&(_0x3759c2[_0x3c31ac(0x209)]=!0x0),_0x3759c2[_0x3c31ac(0x209)];}function J(_0x2011df,_0x5af1c4,_0x1caee6,_0x2bde9f,_0x3f83e7,_0x1e8675){var _0x19fb99=_0x548f0e;_0x2011df=_0x2011df,_0x5af1c4=_0x5af1c4,_0x1caee6=_0x1caee6,_0x2bde9f=_0x2bde9f,_0x3f83e7=_0x3f83e7,_0x3f83e7=_0x3f83e7||{},_0x3f83e7[_0x19fb99(0x12d)]=_0x3f83e7[_0x19fb99(0x12d)]||{},_0x3f83e7[_0x19fb99(0x17d)]=_0x3f83e7[_0x19fb99(0x17d)]||{},_0x3f83e7[_0x19fb99(0x1cc)]=_0x3f83e7['reducePolicy']||{},_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]=_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]||{},_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]=_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]||{};let _0x10a276={'perLogpoint':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x151)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7['reducePolicy']['perLogpoint'][_0x19fb99(0x1e2)]||0x64,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)]['perLogpoint'][_0x19fb99(0x13c)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x1ec)]||0x64},'global':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x151)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x1e2)]||0x12c,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x13c)]||0x32,'resetOnProcessingTimeAverageMs':_0x3f83e7['reducePolicy'][_0x19fb99(0x1fc)]['resetOnProcessingTimeAverageMs']||0x64}},_0x3528bb=b(_0x2011df),_0x5e742b=_0x3528bb[_0x19fb99(0x127)],_0x1e8773=_0x3528bb[_0x19fb99(0x115)];function _0x3b798c(){var _0xf88f94=_0x19fb99;this[_0xf88f94(0x121)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this['_numberRegExp']=/^(0|[1-9][0-9]*)$/,this[_0xf88f94(0x1b7)]=/'([^\\\\']|\\\\')*'/,this[_0xf88f94(0x125)]=_0x2011df[_0xf88f94(0x171)],this[_0xf88f94(0x163)]=_0x2011df[_0xf88f94(0x110)],this[_0xf88f94(0x1b3)]=Object['getOwnPropertyDescriptor'],this[_0xf88f94(0x18b)]=Object['getOwnPropertyNames'],this[_0xf88f94(0x1f0)]=_0x2011df[_0xf88f94(0x138)],this['_regExpToString']=RegExp[_0xf88f94(0x188)]['toString'],this[_0xf88f94(0x1fe)]=Date[_0xf88f94(0x188)][_0xf88f94(0x1d0)];}_0x3b798c[_0x19fb99(0x188)]['serialize']=function(_0x216611,_0x5eff3c,_0x98d4f7,_0x591bd8){var _0x17b51c=_0x19fb99,_0x5097e6=this,_0x4ddf1a=_0x98d4f7['autoExpand'];function _0x2cf396(_0xa9d4ec,_0x4b33f3,_0x5bb97d){var _0x3f82bf=_0x49dd;_0x4b33f3[_0x3f82bf(0x13e)]=_0x3f82bf(0x15f),_0x4b33f3[_0x3f82bf(0x1c5)]=_0xa9d4ec[_0x3f82bf(0x113)],_0x158ad2=_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)],_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)]=_0x4b33f3,_0x5097e6[_0x3f82bf(0x18c)](_0x4b33f3,_0x5bb97d);}let _0x4268a1,_0x4a8d20,_0xfbbae=_0x2011df[_0x17b51c(0x124)];_0x2011df[_0x17b51c(0x124)]=!0x0,_0x2011df[_0x17b51c(0x165)]&&(_0x4268a1=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)],_0x4a8d20=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)],_0x4268a1&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)]=function(){}),_0x4a8d20&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)]=function(){}));try{try{_0x98d4f7[_0x17b51c(0x107)]++,_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7['autoExpandPreviousObjects'][_0x17b51c(0x1c3)](_0x5eff3c);var _0xaaa11d,_0x5c63f2,_0x231fa2,_0x3f03a6,_0x44c1a5=[],_0x7e4f4a=[],_0x348545,_0x4cc2e9=this[_0x17b51c(0x172)](_0x5eff3c),_0x133a1d=_0x4cc2e9==='array',_0x3478d3=!0x1,_0x459df2=_0x4cc2e9==='function',_0x454d51=this[_0x17b51c(0x108)](_0x4cc2e9),_0x563084=this['_isPrimitiveWrapperType'](_0x4cc2e9),_0x320d3c=_0x454d51||_0x563084,_0x5529b5={},_0x542ce0=0x0,_0x423abb=!0x1,_0x158ad2,_0x13010c=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x98d4f7[_0x17b51c(0x11d)]){if(_0x133a1d){if(_0x5c63f2=_0x5eff3c['length'],_0x5c63f2>_0x98d4f7[_0x17b51c(0x1d6)]){for(_0x231fa2=0x0,_0x3f03a6=_0x98d4f7['elements'],_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));_0x216611[_0x17b51c(0x1fa)]=!0x0;}else{for(_0x231fa2=0x0,_0x3f03a6=_0x5c63f2,_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));}_0x98d4f7[_0x17b51c(0x1ca)]+=_0x7e4f4a[_0x17b51c(0x12e)];}if(!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9===_0x17b51c(0x171))&&!_0x454d51&&_0x4cc2e9!==_0x17b51c(0x11e)&&_0x4cc2e9!==_0x17b51c(0x1f3)&&_0x4cc2e9!==_0x17b51c(0x134)){var _0x13bdc7=_0x591bd8[_0x17b51c(0x20b)]||_0x98d4f7[_0x17b51c(0x20b)];if(this['_isSet'](_0x5eff3c)?(_0xaaa11d=0x0,_0x5eff3c['forEach'](function(_0x4e268b){var _0x1aa76f=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x1aa76f(0x1a5)]&&_0x98d4f7[_0x1aa76f(0x1a1)]&&_0x98d4f7[_0x1aa76f(0x1ca)]>_0x98d4f7[_0x1aa76f(0x152)]){_0x423abb=!0x0;return;}_0x7e4f4a[_0x1aa76f(0x1c3)](_0x5097e6['_addProperty'](_0x44c1a5,_0x5eff3c,_0x1aa76f(0x1b9),_0xaaa11d++,_0x98d4f7,function(_0x56afe8){return function(){return _0x56afe8;};}(_0x4e268b)));})):this[_0x17b51c(0x13d)](_0x5eff3c)&&_0x5eff3c[_0x17b51c(0x1d8)](function(_0x4b4368,_0x4a5cce){var _0x3f9993=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x3f9993(0x1a5)]&&_0x98d4f7[_0x3f9993(0x1a1)]&&_0x98d4f7['autoExpandPropertyCount']>_0x98d4f7[_0x3f9993(0x152)]){_0x423abb=!0x0;return;}var _0xab791b=_0x4a5cce['toString']();_0xab791b[_0x3f9993(0x12e)]>0x64&&(_0xab791b=_0xab791b['slice'](0x0,0x64)+_0x3f9993(0x1ea)),_0x7e4f4a[_0x3f9993(0x1c3)](_0x5097e6[_0x3f9993(0x1b2)](_0x44c1a5,_0x5eff3c,_0x3f9993(0x139),_0xab791b,_0x98d4f7,function(_0x2460ca){return function(){return _0x2460ca;};}(_0x4b4368)));}),!_0x3478d3){try{for(_0x348545 in _0x5eff3c)if(!(_0x133a1d&&_0x13010c['test'](_0x348545))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7[_0x17b51c(0x1a5)]&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}catch{}if(_0x5529b5['_p_length']=!0x0,_0x459df2&&(_0x5529b5[_0x17b51c(0x17b)]=!0x0),!_0x423abb){var _0x516950=[][_0x17b51c(0x10e)](this[_0x17b51c(0x18b)](_0x5eff3c))['concat'](this[_0x17b51c(0x19e)](_0x5eff3c));for(_0xaaa11d=0x0,_0x5c63f2=_0x516950[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)if(_0x348545=_0x516950[_0xaaa11d],!(_0x133a1d&&_0x13010c[_0x17b51c(0x202)](_0x348545['toString']()))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)&&!_0x5529b5[typeof _0x348545!=_0x17b51c(0x1b5)?_0x17b51c(0x173)+_0x348545['toString']():_0x348545]){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7['isExpressionToEvaluate']&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}}}}if(_0x216611['type']=_0x4cc2e9,_0x320d3c?(_0x216611[_0x17b51c(0x181)]=_0x5eff3c[_0x17b51c(0x1a4)](),this[_0x17b51c(0x16e)](_0x4cc2e9,_0x216611,_0x98d4f7,_0x591bd8)):_0x4cc2e9==='date'?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1fe)][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x134)?_0x216611['value']=_0x5eff3c[_0x17b51c(0x1d0)]():_0x4cc2e9==='RegExp'?_0x216611[_0x17b51c(0x181)]=this['_regExpToString'][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x1b5)&&this[_0x17b51c(0x1f0)]?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1f0)][_0x17b51c(0x188)][_0x17b51c(0x1d0)][_0x17b51c(0x198)](_0x5eff3c):!_0x98d4f7[_0x17b51c(0x11d)]&&!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9==='undefined')&&(delete _0x216611['value'],_0x216611[_0x17b51c(0x17a)]=!0x0),_0x423abb&&(_0x216611['cappedProps']=!0x0),_0x158ad2=_0x98d4f7[_0x17b51c(0x143)]['current'],_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x216611,this[_0x17b51c(0x18c)](_0x216611,_0x98d4f7),_0x7e4f4a[_0x17b51c(0x12e)]){for(_0xaaa11d=0x0,_0x5c63f2=_0x7e4f4a[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)_0x7e4f4a[_0xaaa11d](_0xaaa11d);}_0x44c1a5[_0x17b51c(0x12e)]&&(_0x216611['props']=_0x44c1a5);}catch(_0x584964){_0x2cf396(_0x584964,_0x216611,_0x98d4f7);}this['_additionalMetadata'](_0x5eff3c,_0x216611),this[_0x17b51c(0x191)](_0x216611,_0x98d4f7),_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x158ad2,_0x98d4f7['level']--,_0x98d4f7[_0x17b51c(0x1a1)]=_0x4ddf1a,_0x98d4f7['autoExpand']&&_0x98d4f7[_0x17b51c(0x187)][_0x17b51c(0x195)]();}finally{_0x4268a1&&(_0x2011df[_0x17b51c(0x165)]['error']=_0x4268a1),_0x4a8d20&&(_0x2011df['console'][_0x17b51c(0x141)]=_0x4a8d20),_0x2011df[_0x17b51c(0x124)]=_0xfbbae;}return _0x216611;},_0x3b798c[_0x19fb99(0x188)]['_getOwnPropertySymbols']=function(_0x4c28a7){var _0xd2148d=_0x19fb99;return Object[_0xd2148d(0x122)]?Object[_0xd2148d(0x122)](_0x4c28a7):[];},_0x3b798c['prototype'][_0x19fb99(0x19f)]=function(_0x27432c){var _0x117f9a=_0x19fb99;return!!(_0x27432c&&_0x2011df['Set']&&this[_0x117f9a(0x1da)](_0x27432c)===_0x117f9a(0x17f)&&_0x27432c[_0x117f9a(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ef)]=function(_0x327172,_0x1bf02d,_0x68c506){var _0x42d895=_0x19fb99;if(!_0x68c506[_0x42d895(0x183)]){let _0x31f3c6=this[_0x42d895(0x1b3)](_0x327172,_0x1bf02d);if(_0x31f3c6&&_0x31f3c6[_0x42d895(0x136)])return!0x0;}return _0x68c506[_0x42d895(0x1ff)]?typeof _0x327172[_0x1bf02d]==_0x42d895(0x1df):!0x1;},_0x3b798c['prototype'][_0x19fb99(0x172)]=function(_0x4b4ff7){var _0x89a987=_0x19fb99,_0x2df42a='';return _0x2df42a=typeof _0x4b4ff7,_0x2df42a===_0x89a987(0x140)?this[_0x89a987(0x1da)](_0x4b4ff7)==='[object\\x20Array]'?_0x2df42a=_0x89a987(0x1d2):this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x193)?_0x2df42a='date':this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x19d)?_0x2df42a='bigint':_0x4b4ff7===null?_0x2df42a=_0x89a987(0x199):_0x4b4ff7[_0x89a987(0x192)]&&(_0x2df42a=_0x4b4ff7[_0x89a987(0x192)][_0x89a987(0x1f1)]||_0x2df42a):_0x2df42a==='undefined'&&this[_0x89a987(0x163)]&&_0x4b4ff7 instanceof this['_HTMLAllCollection']&&(_0x2df42a='HTMLAllCollection'),_0x2df42a;},_0x3b798c[_0x19fb99(0x188)]['_objectToString']=function(_0x4ea4a3){var _0xe65ac2=_0x19fb99;return Object[_0xe65ac2(0x188)][_0xe65ac2(0x1d0)]['call'](_0x4ea4a3);},_0x3b798c['prototype'][_0x19fb99(0x108)]=function(_0x486186){var _0x59de18=_0x19fb99;return _0x486186==='boolean'||_0x486186===_0x59de18(0x204)||_0x486186==='number';},_0x3b798c[_0x19fb99(0x188)]['_isPrimitiveWrapperType']=function(_0x57b53f){var _0x3d404c=_0x19fb99;return _0x57b53f===_0x3d404c(0x1de)||_0x57b53f==='String'||_0x57b53f===_0x3d404c(0x1bc);},_0x3b798c['prototype'][_0x19fb99(0x1b2)]=function(_0x51d7e9,_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116){var _0x327fee=this;return function(_0x5f212a){var _0x45776a=_0x49dd,_0x480d1e=_0x10ecad[_0x45776a(0x143)][_0x45776a(0x19a)],_0x2270b6=_0x10ecad['node']['index'],_0x3242a9=_0x10ecad['node']['parent'];_0x10ecad[_0x45776a(0x143)][_0x45776a(0x168)]=_0x480d1e,_0x10ecad[_0x45776a(0x143)][_0x45776a(0x13a)]=typeof _0x32ddbe=='number'?_0x32ddbe:_0x5f212a,_0x51d7e9[_0x45776a(0x1c3)](_0x327fee[_0x45776a(0x119)](_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116)),_0x10ecad['node'][_0x45776a(0x168)]=_0x3242a9,_0x10ecad['node'][_0x45776a(0x13a)]=_0x2270b6;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11c)]=function(_0x4fff24,_0xf060cd,_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d){var _0x11f0a7=_0x19fb99,_0x261b2c=this;return _0xf060cd[typeof _0x46c20e!=_0x11f0a7(0x1b5)?_0x11f0a7(0x173)+_0x46c20e[_0x11f0a7(0x1d0)]():_0x46c20e]=!0x0,function(_0x3a475e){var _0x2f5d31=_0x11f0a7,_0x2b9d6c=_0x2e08a7[_0x2f5d31(0x143)]['current'],_0x4b248b=_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)],_0xbed829=_0x2e08a7['node']['parent'];_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0x2b9d6c,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x3a475e,_0x4fff24[_0x2f5d31(0x1c3)](_0x261b2c[_0x2f5d31(0x119)](_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d)),_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0xbed829,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x4b248b;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x119)]=function(_0x1bf49f,_0x10ac96,_0x57dfa6,_0xee7322,_0x598c3f){var _0x326486=_0x19fb99,_0x57fd55=this;_0x598c3f||(_0x598c3f=function(_0x46b469,_0x55c36d){return _0x46b469[_0x55c36d];});var _0x4331ba=_0x57dfa6[_0x326486(0x1d0)](),_0x58db2f=_0xee7322[_0x326486(0x14d)]||{},_0x56fbc0=_0xee7322[_0x326486(0x11d)],_0x28a895=_0xee7322['isExpressionToEvaluate'];try{var _0x4d3354=this[_0x326486(0x13d)](_0x1bf49f),_0x4f8709=_0x4331ba;_0x4d3354&&_0x4f8709[0x0]==='\\x27'&&(_0x4f8709=_0x4f8709[_0x326486(0x185)](0x1,_0x4f8709[_0x326486(0x12e)]-0x2));var _0x15481e=_0xee7322[_0x326486(0x14d)]=_0x58db2f[_0x326486(0x173)+_0x4f8709];_0x15481e&&(_0xee7322[_0x326486(0x11d)]=_0xee7322[_0x326486(0x11d)]+0x1),_0xee7322[_0x326486(0x1a5)]=!!_0x15481e;var _0x3a61d9=typeof _0x57dfa6==_0x326486(0x1b5),_0x1e1792={'name':_0x3a61d9||_0x4d3354?_0x4331ba:this[_0x326486(0x11b)](_0x4331ba)};if(_0x3a61d9&&(_0x1e1792['symbol']=!0x0),!(_0x10ac96==='array'||_0x10ac96===_0x326486(0x1e4))){var _0x4503a0=this[_0x326486(0x1b3)](_0x1bf49f,_0x57dfa6);if(_0x4503a0&&(_0x4503a0['set']&&(_0x1e1792[_0x326486(0x16b)]=!0x0),_0x4503a0[_0x326486(0x136)]&&!_0x15481e&&!_0xee7322[_0x326486(0x183)]))return _0x1e1792[_0x326486(0x1ed)]=!0x0,this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x32a36e;try{_0x32a36e=_0x598c3f(_0x1bf49f,_0x57dfa6);}catch(_0x44aaa6){return _0x1e1792={'name':_0x4331ba,'type':_0x326486(0x15f),'error':_0x44aaa6['message']},this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x27eaec=this[_0x326486(0x172)](_0x32a36e),_0x1dd8cf=this['_isPrimitiveType'](_0x27eaec);if(_0x1e1792[_0x326486(0x13e)]=_0x27eaec,_0x1dd8cf)this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x14aecf=_0x326486;_0x1e1792['value']=_0x32a36e[_0x14aecf(0x1a4)](),!_0x15481e&&_0x57fd55['_capIfString'](_0x27eaec,_0x1e1792,_0xee7322,{});});else{var _0x1fd626=_0xee7322[_0x326486(0x1a1)]&&_0xee7322[_0x326486(0x107)]<_0xee7322[_0x326486(0x123)]&&_0xee7322[_0x326486(0x187)][_0x326486(0x18d)](_0x32a36e)<0x0&&_0x27eaec!==_0x326486(0x1df)&&_0xee7322['autoExpandPropertyCount']<_0xee7322[_0x326486(0x152)];_0x1fd626||_0xee7322[_0x326486(0x107)]<_0x56fbc0||_0x15481e?this[_0x326486(0x19b)](_0x1e1792,_0x32a36e,_0xee7322,_0x15481e||{}):this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x187576=_0x326486;_0x27eaec==='null'||_0x27eaec==='undefined'||(delete _0x1e1792[_0x187576(0x181)],_0x1e1792[_0x187576(0x17a)]=!0x0);});}return _0x1e1792;}finally{_0xee7322[_0x326486(0x14d)]=_0x58db2f,_0xee7322[_0x326486(0x11d)]=_0x56fbc0,_0xee7322[_0x326486(0x1a5)]=_0x28a895;}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x16e)]=function(_0x56e4d4,_0x9663b4,_0x4ca9b4,_0x4f8a61){var _0x289244=_0x19fb99,_0x543170=_0x4f8a61['strLength']||_0x4ca9b4['strLength'];if((_0x56e4d4===_0x289244(0x204)||_0x56e4d4===_0x289244(0x11e))&&_0x9663b4[_0x289244(0x181)]){let _0x2b9781=_0x9663b4[_0x289244(0x181)][_0x289244(0x12e)];_0x4ca9b4[_0x289244(0x169)]+=_0x2b9781,_0x4ca9b4[_0x289244(0x169)]>_0x4ca9b4[_0x289244(0x14f)]?(_0x9663b4[_0x289244(0x17a)]='',delete _0x9663b4[_0x289244(0x181)]):_0x2b9781>_0x543170&&(_0x9663b4[_0x289244(0x17a)]=_0x9663b4[_0x289244(0x181)]['substr'](0x0,_0x543170),delete _0x9663b4[_0x289244(0x181)]);}},_0x3b798c['prototype'][_0x19fb99(0x13d)]=function(_0x20e242){var _0x22bc15=_0x19fb99;return!!(_0x20e242&&_0x2011df[_0x22bc15(0x139)]&&this[_0x22bc15(0x1da)](_0x20e242)==='[object\\x20Map]'&&_0x20e242[_0x22bc15(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11b)]=function(_0x51405e){var _0x339753=_0x19fb99;if(_0x51405e[_0x339753(0x1e6)](/^\\d+$/))return _0x51405e;var _0xa32815;try{_0xa32815=JSON['stringify'](''+_0x51405e);}catch{_0xa32815='\\x22'+this[_0x339753(0x1da)](_0x51405e)+'\\x22';}return _0xa32815[_0x339753(0x1e6)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0xa32815=_0xa32815[_0x339753(0x185)](0x1,_0xa32815['length']-0x2):_0xa32815=_0xa32815[_0x339753(0x161)](/'/g,'\\x5c\\x27')[_0x339753(0x161)](/\\\\\"/g,'\\x22')[_0x339753(0x161)](/(^\"|\"$)/g,'\\x27'),_0xa32815;},_0x3b798c[_0x19fb99(0x188)]['_processTreeNodeResult']=function(_0x19aa6c,_0x15bfd6,_0x57de46,_0x17e0d5){var _0x5136d0=_0x19fb99;this['_treeNodePropertiesBeforeFullValue'](_0x19aa6c,_0x15bfd6),_0x17e0d5&&_0x17e0d5(),this[_0x5136d0(0x1ad)](_0x57de46,_0x19aa6c),this[_0x5136d0(0x191)](_0x19aa6c,_0x15bfd6);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x18c)]=function(_0x3d1ee7,_0x70e5ea){var _0x548bce=_0x19fb99;this['_setNodeId'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x175)](_0x3d1ee7,_0x70e5ea),this['_setNodeExpressionPath'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x1e9)](_0x3d1ee7,_0x70e5ea);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x203)]=function(_0x39276,_0x2973e9){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x175)]=function(_0x3d5358,_0x1ce0bc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x149)]=function(_0x5460c7,_0x5726fc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1e7)]=function(_0xb18247){var _0x5a9038=_0x19fb99;return _0xb18247===this[_0x5a9038(0x125)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x191)]=function(_0xb3362f,_0x257171){var _0x24e002=_0x19fb99;this[_0x24e002(0x149)](_0xb3362f,_0x257171),this[_0x24e002(0x196)](_0xb3362f),_0x257171[_0x24e002(0x147)]&&this[_0x24e002(0x1bf)](_0xb3362f),this[_0x24e002(0x11f)](_0xb3362f,_0x257171),this['_addLoadNode'](_0xb3362f,_0x257171),this[_0x24e002(0x182)](_0xb3362f);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ad)]=function(_0x2dbd2f,_0x37c5b1){var _0x320ee5=_0x19fb99;try{_0x2dbd2f&&typeof _0x2dbd2f[_0x320ee5(0x12e)]==_0x320ee5(0x117)&&(_0x37c5b1[_0x320ee5(0x12e)]=_0x2dbd2f[_0x320ee5(0x12e)]);}catch{}if(_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x117)||_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1bc)){if(isNaN(_0x37c5b1['value']))_0x37c5b1['nan']=!0x0,delete _0x37c5b1['value'];else switch(_0x37c5b1[_0x320ee5(0x181)]){case Number[_0x320ee5(0x14c)]:_0x37c5b1[_0x320ee5(0x1e8)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case Number[_0x320ee5(0x12c)]:_0x37c5b1[_0x320ee5(0x1ee)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case 0x0:this[_0x320ee5(0x1fb)](_0x37c5b1['value'])&&(_0x37c5b1[_0x320ee5(0x129)]=!0x0);break;}}else _0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1df)&&typeof _0x2dbd2f[_0x320ee5(0x1f1)]==_0x320ee5(0x204)&&_0x2dbd2f[_0x320ee5(0x1f1)]&&_0x37c5b1['name']&&_0x2dbd2f['name']!==_0x37c5b1['name']&&(_0x37c5b1[_0x320ee5(0x13b)]=_0x2dbd2f[_0x320ee5(0x1f1)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1fb)]=function(_0x3fe3ce){var _0x5bd9dd=_0x19fb99;return 0x1/_0x3fe3ce===Number[_0x5bd9dd(0x12c)];},_0x3b798c[_0x19fb99(0x188)]['_sortProps']=function(_0x302641){var _0x20eea1=_0x19fb99;!_0x302641[_0x20eea1(0x20b)]||!_0x302641[_0x20eea1(0x20b)][_0x20eea1(0x12e)]||_0x302641[_0x20eea1(0x13e)]===_0x20eea1(0x1d2)||_0x302641['type']===_0x20eea1(0x139)||_0x302641['type']===_0x20eea1(0x1b9)||_0x302641['props'][_0x20eea1(0x16c)](function(_0x2e3c0f,_0x466671){var _0x2def12=_0x20eea1,_0x299cd3=_0x2e3c0f[_0x2def12(0x1f1)][_0x2def12(0x1a8)](),_0x569a8c=_0x466671[_0x2def12(0x1f1)]['toLowerCase']();return _0x299cd3<_0x569a8c?-0x1:_0x299cd3>_0x569a8c?0x1:0x0;});},_0x3b798c['prototype'][_0x19fb99(0x11f)]=function(_0x1fce5c,_0x59600b){var _0x272775=_0x19fb99;if(!(_0x59600b[_0x272775(0x1ff)]||!_0x1fce5c['props']||!_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)])){for(var _0x5b060d=[],_0x576482=[],_0x469b84=0x0,_0x1419a1=_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)];_0x469b84<_0x1419a1;_0x469b84++){var _0x554dbc=_0x1fce5c[_0x272775(0x20b)][_0x469b84];_0x554dbc['type']===_0x272775(0x1df)?_0x5b060d[_0x272775(0x1c3)](_0x554dbc):_0x576482['push'](_0x554dbc);}if(!(!_0x576482['length']||_0x5b060d[_0x272775(0x12e)]<=0x1)){_0x1fce5c[_0x272775(0x20b)]=_0x576482;var _0x5ac4d9={'functionsNode':!0x0,'props':_0x5b060d};this['_setNodeId'](_0x5ac4d9,_0x59600b),this['_setNodeLabel'](_0x5ac4d9,_0x59600b),this['_setNodeExpandableState'](_0x5ac4d9),this['_setNodePermissions'](_0x5ac4d9,_0x59600b),_0x5ac4d9['id']+='\\x20f',_0x1fce5c[_0x272775(0x20b)][_0x272775(0x15e)](_0x5ac4d9);}}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x206)]=function(_0x53bb34,_0x23ecf2){},_0x3b798c['prototype'][_0x19fb99(0x196)]=function(_0x59c87d){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x109)]=function(_0x480385){var _0x3b79b1=_0x19fb99;return Array['isArray'](_0x480385)||typeof _0x480385=='object'&&this[_0x3b79b1(0x1da)](_0x480385)===_0x3b79b1(0x1f6);},_0x3b798c['prototype'][_0x19fb99(0x1e9)]=function(_0x3277e3,_0x15bc20){},_0x3b798c[_0x19fb99(0x188)]['_cleanNode']=function(_0x3d12db){var _0x1bb90c=_0x19fb99;delete _0x3d12db[_0x1bb90c(0x106)],delete _0x3d12db[_0x1bb90c(0x179)],delete _0x3d12db[_0x1bb90c(0x146)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x10c)]=function(_0x804785,_0x46b090){};let _0x1ab812=new _0x3b798c(),_0x4253f5={'props':_0x3f83e7[_0x19fb99(0x12d)]['props']||0x64,'elements':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x1d6)]||0x64,'strLength':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x16a)]||0x400*0x32,'totalStrLength':_0x3f83e7['defaultLimits'][_0x19fb99(0x14f)]||0x400*0x32,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x152)]||0x1388,'autoExpandMaxDepth':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x123)]||0xa},_0x5ccf32={'props':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x20b)]||0x5,'elements':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x1d6)]||0x5,'strLength':_0x3f83e7['reducedLimits'][_0x19fb99(0x16a)]||0x100,'totalStrLength':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x14f)]||0x100*0x3,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x152)]||0x1e,'autoExpandMaxDepth':_0x3f83e7['reducedLimits']['autoExpandMaxDepth']||0x2};if(_0x1e8675){let _0x2f3a37=_0x1ab812['serialize']['bind'](_0x1ab812);_0x1ab812[_0x19fb99(0x19b)]=function(_0x4f58de,_0x29d7d0,_0x30b459,_0x1f5fdf){return _0x2f3a37(_0x4f58de,_0x1e8675(_0x29d7d0),_0x30b459,_0x1f5fdf);};}function _0xc68888(_0x535031,_0x3340fc,_0x337e66,_0x22242c,_0x124bfa,_0x5f1e1f){var _0x46fc5e=_0x19fb99;let _0x56fb0c,_0x26a7c9;try{_0x26a7c9=_0x1e8773(),_0x56fb0c=_0x1caee6[_0x3340fc],!_0x56fb0c||_0x26a7c9-_0x56fb0c['ts']>_0x10a276['perLogpoint'][_0x46fc5e(0x13c)]&&_0x56fb0c[_0x46fc5e(0x1a2)]&&_0x56fb0c[_0x46fc5e(0x1a7)]/_0x56fb0c[_0x46fc5e(0x1a2)]<_0x10a276[_0x46fc5e(0x194)]['resetOnProcessingTimeAverageMs']?(_0x1caee6[_0x3340fc]=_0x56fb0c={'count':0x0,'time':0x0,'ts':_0x26a7c9},_0x1caee6['hits']={}):_0x26a7c9-_0x1caee6[_0x46fc5e(0x1ab)]['ts']>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x13c)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a7)]/_0x1caee6[_0x46fc5e(0x1ab)]['count']<_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x1ec)]&&(_0x1caee6[_0x46fc5e(0x1ab)]={});let _0x135eed=[],_0x4de057=_0x56fb0c[_0x46fc5e(0x15d)]||_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]?_0x5ccf32:_0x4253f5,_0x5ea472=_0x57de65=>{var _0x1e64a0=_0x46fc5e;let _0x2f1ff9={};return _0x2f1ff9[_0x1e64a0(0x20b)]=_0x57de65[_0x1e64a0(0x20b)],_0x2f1ff9[_0x1e64a0(0x1d6)]=_0x57de65['elements'],_0x2f1ff9[_0x1e64a0(0x16a)]=_0x57de65[_0x1e64a0(0x16a)],_0x2f1ff9['totalStrLength']=_0x57de65[_0x1e64a0(0x14f)],_0x2f1ff9[_0x1e64a0(0x152)]=_0x57de65[_0x1e64a0(0x152)],_0x2f1ff9['autoExpandMaxDepth']=_0x57de65[_0x1e64a0(0x123)],_0x2f1ff9[_0x1e64a0(0x147)]=!0x1,_0x2f1ff9['noFunctions']=!_0x5af1c4,_0x2f1ff9[_0x1e64a0(0x11d)]=0x1,_0x2f1ff9['level']=0x0,_0x2f1ff9[_0x1e64a0(0x164)]=_0x1e64a0(0x167),_0x2f1ff9[_0x1e64a0(0x1d1)]=_0x1e64a0(0x16f),_0x2f1ff9[_0x1e64a0(0x1a1)]=!0x0,_0x2f1ff9[_0x1e64a0(0x187)]=[],_0x2f1ff9[_0x1e64a0(0x1ca)]=0x0,_0x2f1ff9['resolveGetters']=_0x3f83e7['resolveGetters'],_0x2f1ff9[_0x1e64a0(0x169)]=0x0,_0x2f1ff9[_0x1e64a0(0x143)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x2f1ff9;};for(var _0x19c1cf=0x0;_0x19c1cf<_0x124bfa[_0x46fc5e(0x12e)];_0x19c1cf++)_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'timeNode':_0x535031==='time'||void 0x0},_0x124bfa[_0x19c1cf],_0x5ea472(_0x4de057),{}));if(_0x535031==='trace'||_0x535031===_0x46fc5e(0x1c5)){let _0x11d4f0=Error[_0x46fc5e(0x1f7)];try{Error[_0x46fc5e(0x1f7)]=0x1/0x0,_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'stackNode':!0x0},new Error()[_0x46fc5e(0x1af)],_0x5ea472(_0x4de057),{'strLength':0x1/0x0}));}finally{Error[_0x46fc5e(0x1f7)]=_0x11d4f0;}}return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':_0x135eed,'id':_0x3340fc,'context':_0x5f1e1f}]};}catch(_0x29c306){return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':[{'type':_0x46fc5e(0x15f),'error':_0x29c306&&_0x29c306[_0x46fc5e(0x113)]}],'id':_0x3340fc,'context':_0x5f1e1f}]};}finally{try{if(_0x56fb0c&&_0x26a7c9){let _0x52a27e=_0x1e8773();_0x56fb0c[_0x46fc5e(0x1a2)]++,_0x56fb0c[_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x56fb0c['ts']=_0x52a27e,_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]++,_0x1caee6['hits'][_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x1caee6[_0x46fc5e(0x1ab)]['ts']=_0x52a27e,(_0x56fb0c[_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x194)][_0x46fc5e(0x151)]||_0x56fb0c['time']>_0x10a276['perLogpoint']['reduceOnAccumulatedProcessingTimeMs'])&&(_0x56fb0c[_0x46fc5e(0x15d)]=!0x0),(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x151)]||_0x1caee6[_0x46fc5e(0x1ab)]['time']>_0x10a276['global'][_0x46fc5e(0x1e2)])&&(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]=!0x0);}}catch{}}}return _0xc68888;}function G(_0x357a3e){var _0x1c1d5c=_0x548f0e;if(_0x357a3e&&typeof _0x357a3e==_0x1c1d5c(0x140)&&_0x357a3e[_0x1c1d5c(0x192)])switch(_0x357a3e['constructor'][_0x1c1d5c(0x1f1)]){case _0x1c1d5c(0x1f8):return _0x357a3e['hasOwnProperty'](Symbol[_0x1c1d5c(0x1cb)])?Promise[_0x1c1d5c(0x1ac)]():_0x357a3e;case'bound\\x20Promise':return Promise[_0x1c1d5c(0x1ac)]();}return _0x357a3e;}function _0x49dd(_0x48794b,_0x215201){var _0x5eb787=_0x5eb7();return _0x49dd=function(_0x49dd64,_0x5b9134){_0x49dd64=_0x49dd64-0x106;var _0x4735f0=_0x5eb787[_0x49dd64];return _0x4735f0;},_0x49dd(_0x48794b,_0x215201);}((_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x5bf3d1,_0xfe754b,_0x5a9d76,_0x1aab36,_0x3bc27c,_0x57f4e7,_0x4fa6c3)=>{var _0xf735ce=_0x548f0e;if(_0x4ab1c6['_console_ninja'])return _0x4ab1c6['_console_ninja'];let _0x313a8d={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x4ab1c6,_0x5a9d76,_0x478f2c))return _0x4ab1c6[_0xf735ce(0x16d)]=_0x313a8d,_0x4ab1c6['_console_ninja'];let _0x418c01=b(_0x4ab1c6),_0xd76728=_0x418c01[_0xf735ce(0x127)],_0x3e56d8=_0x418c01[_0xf735ce(0x115)],_0x3e2373=_0x418c01[_0xf735ce(0x14a)],_0x48f2ad={'hits':{},'ts':{}},_0x505066=J(_0x4ab1c6,_0x1aab36,_0x48f2ad,_0x5bf3d1,_0x4fa6c3,_0x478f2c==='next.js'?G:void 0x0),_0x48cb15=(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9)=>{var _0x27df57=_0xf735ce;let _0x1159ce=_0x4ab1c6['_console_ninja'];try{return _0x4ab1c6['_console_ninja']=_0x313a8d,_0x505066(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9);}finally{_0x4ab1c6[_0x27df57(0x16d)]=_0x1159ce;}},_0xcc7412=_0xab4b0c=>{_0x48f2ad['ts'][_0xab4b0c]=_0x3e56d8();},_0x3aeb93=(_0xbe2a9d,_0x37862a)=>{var _0x30e3cb=_0xf735ce;let _0x37627d=_0x48f2ad['ts'][_0x37862a];if(delete _0x48f2ad['ts'][_0x37862a],_0x37627d){let _0x464639=_0xd76728(_0x37627d,_0x3e56d8());_0x45f648(_0x48cb15(_0x30e3cb(0x1a7),_0xbe2a9d,_0x3e2373(),_0x5efb7d,[_0x464639],_0x37862a));}},_0x5b170d=_0x4b3a1c=>{var _0x5a439b=_0xf735ce,_0x1bd0d3;return _0x478f2c===_0x5a439b(0x1b1)&&_0x4ab1c6['origin']&&((_0x1bd0d3=_0x4b3a1c==null?void 0x0:_0x4b3a1c['args'])==null?void 0x0:_0x1bd0d3[_0x5a439b(0x12e)])&&(_0x4b3a1c['args'][0x0]['origin']=_0x4ab1c6[_0x5a439b(0x133)]),_0x4b3a1c;};_0x4ab1c6[_0xf735ce(0x16d)]={'consoleLog':(_0x1f92a3,_0x3d1b32)=>{var _0x384ddc=_0xf735ce;_0x4ab1c6[_0x384ddc(0x165)][_0x384ddc(0x177)][_0x384ddc(0x1f1)]!=='disabledLog'&&_0x45f648(_0x48cb15(_0x384ddc(0x177),_0x1f92a3,_0x3e2373(),_0x5efb7d,_0x3d1b32));},'consoleTrace':(_0x16d5a,_0x223858)=>{var _0x616644=_0xf735ce,_0xdf7629,_0x7ea927;_0x4ab1c6[_0x616644(0x165)]['log'][_0x616644(0x1f1)]!==_0x616644(0x118)&&((_0x7ea927=(_0xdf7629=_0x4ab1c6[_0x616644(0x1c8)])==null?void 0x0:_0xdf7629['versions'])!=null&&_0x7ea927[_0x616644(0x143)]&&(_0x4ab1c6[_0x616644(0x1c0)]=!0x0),_0x45f648(_0x5b170d(_0x48cb15(_0x616644(0x1a3),_0x16d5a,_0x3e2373(),_0x5efb7d,_0x223858))));},'consoleError':(_0x38f47b,_0x35429f)=>{_0x4ab1c6['_ninjaIgnoreNextError']=!0x0,_0x45f648(_0x5b170d(_0x48cb15('error',_0x38f47b,_0x3e2373(),_0x5efb7d,_0x35429f)));},'consoleTime':_0x4cf735=>{_0xcc7412(_0x4cf735);},'consoleTimeEnd':(_0x566c48,_0x364eea)=>{_0x3aeb93(_0x364eea,_0x566c48);},'autoLog':(_0x1eb1b1,_0xa812f2)=>{var _0x1ace51=_0xf735ce;_0x45f648(_0x48cb15(_0x1ace51(0x177),_0xa812f2,_0x3e2373(),_0x5efb7d,[_0x1eb1b1]));},'autoLogMany':(_0x56ca86,_0x4bac87)=>{var _0x3394a4=_0xf735ce;_0x45f648(_0x48cb15(_0x3394a4(0x177),_0x56ca86,_0x3e2373(),_0x5efb7d,_0x4bac87));},'autoTrace':(_0x417845,_0x145484)=>{var _0x27ae88=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x27ae88(0x1a3),_0x145484,_0x3e2373(),_0x5efb7d,[_0x417845])));},'autoTraceMany':(_0xca37d7,_0x262246)=>{var _0x26f92c=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x26f92c(0x1a3),_0xca37d7,_0x3e2373(),_0x5efb7d,_0x262246)));},'autoTime':(_0x32789a,_0x59deba,_0xcc1c2c)=>{_0xcc7412(_0xcc1c2c);},'autoTimeEnd':(_0x58bdab,_0x21cfd7,_0x507017)=>{_0x3aeb93(_0x21cfd7,_0x507017);},'coverage':_0x237fb5=>{var _0x4ec628=_0xf735ce;_0x45f648({'method':_0x4ec628(0x10f),'version':_0x5bf3d1,'args':[{'id':_0x237fb5}]});}};let _0x45f648=H(_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x3bc27c,_0x57f4e7),_0x5efb7d=_0x4ab1c6[_0xf735ce(0x116)];return _0x4ab1c6['_console_ninja'];})(globalThis,_0x548f0e(0x17e),_0x548f0e(0x154),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.501\\\\node_modules\",_0x548f0e(0x131),_0x548f0e(0x1dc),_0x548f0e(0x144),_0x548f0e(0x1b0),_0x548f0e(0x150),_0x548f0e(0x176),_0x548f0e(0x111),{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}});");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
}),
"[project]/constants/System.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ARROW_DOWN_BUTTON_PROVIDER",
    ()=>ARROW_DOWN_BUTTON_PROVIDER,
    "ARROW_LEFT_BUTTON_PROVIDER",
    ()=>ARROW_LEFT_BUTTON_PROVIDER,
    "ARROW_RIGHT_BUTTON_PROVIDER",
    ()=>ARROW_RIGHT_BUTTON_PROVIDER,
    "ARROW_UP_BUTTON_PROVIDER",
    ()=>ARROW_UP_BUTTON_PROVIDER,
    "DELETE_BUTTON_PROVIDER_ID",
    ()=>DELETE_BUTTON_PROVIDER_ID,
    "GLOBAL_SEARCH_BUTTON_PROVIDER",
    ()=>GLOBAL_SEARCH_BUTTON_PROVIDER,
    "NEXT_INPUT_BUTTON_PROVIDER",
    ()=>NEXT_INPUT_BUTTON_PROVIDER,
    "PREVIOUS_INPUT_BUTTON_PROVIDER",
    ()=>PREVIOUS_INPUT_BUTTON_PROVIDER,
    "SELECT_ALL_BUTTON_PROVIDER",
    ()=>SELECT_ALL_BUTTON_PROVIDER,
    "SIDEBAR_OPEN_TOGGLER_PROVIDER",
    ()=>SIDEBAR_OPEN_TOGGLER_PROVIDER,
    "SUBMIT_BUTTON_PROVIDER_ID",
    ()=>SUBMIT_BUTTON_PROVIDER_ID
]);
const SUBMIT_BUTTON_PROVIDER_ID = "submitBtnProvider";
const DELETE_BUTTON_PROVIDER_ID = "deleteBtnProvider";
const SELECT_ALL_BUTTON_PROVIDER = "selectAllBtnProvider";
const ARROW_DOWN_BUTTON_PROVIDER = "arrowDownBtnProvider";
const ARROW_UP_BUTTON_PROVIDER = "arrowUpBtnProvider";
const ARROW_LEFT_BUTTON_PROVIDER = "arrowLeftBtnProvider";
const ARROW_RIGHT_BUTTON_PROVIDER = "arrowRightBtnProvider";
const NEXT_INPUT_BUTTON_PROVIDER = "nextInputBtnProvider";
const PREVIOUS_INPUT_BUTTON_PROVIDER = "previousInputBtnProvider";
const GLOBAL_SEARCH_BUTTON_PROVIDER = "globalSearchBtnProvider";
const SIDEBAR_OPEN_TOGGLER_PROVIDER = "sideBarOpenTogglerProvider";
}),
"[project]/core/KeyboardEventHundlers.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/System.ts [app-ssr] (ecmascript)");
;
;
class KeyboardEventHandlers {
    /**
   * When the enter button is being pressed the method will checks if there is a button with id SUBMIT_BUTTON _PROVIDER_ID.
   * If it find some. it will click on it otherwise it will do nothing.
   */ onEnterPressed() {
        const submitBtn = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SUBMIT_BUTTON_PROVIDER_ID"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(submitBtn)) submitBtn?.click();
    }
    /**
   * When the delete button i being pressed the method will checks if there is a button with id DELETE_BUTTON_PROVIDER_ID.
   * If it find some. it will click on it otherwise it will do nothing.
   */ onDeletePressed() {
        const deleteBtn = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DELETE_BUTTON_PROVIDER_ID"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(deleteBtn)) deleteBtn?.click();
    }
    /**
   * When the Ctrl + A button is being pressed the method will checks if there is a button with id SELECT_ALL_BUTTON_PROVIDER.
   * If it find some. it will click on it otherwise it will do nothing.
   */ onCtrlPlusAPressed() {
        const selectAllBtn = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SELECT_ALL_BUTTON_PROVIDER"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(selectAllBtn)) selectAllBtn?.click();
    }
    /**
   * When the Ctrl + B button is being pressed the method will checks if there is a button with id SIDEBAR_OPEN_TOGGLER_PROVIDER.
   * If it find some. it will click on it otherwise it will do nothing.
   */ onCtrlPlusBPressed() {
        const sideBarOpenerButton = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SIDEBAR_OPEN_TOGGLER_PROVIDER"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(sideBarOpenerButton)) sideBarOpenerButton?.click();
    }
    /**
   * When the arrow right button is being pressed the method will checks if there is a button with id ARROW_RIGHT_BUTTON_PROVIDER.
   * if it find some. it will click on it otherwise it will do nothing.
   */ onArrowRightPressed() {
        const nextButton = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ARROW_RIGHT_BUTTON_PROVIDER"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(nextButton)) nextButton?.click();
    }
    /**
   * When the arrow right button is being pressed the method will checks if there is a button with id ARROW_LEFT_BUTTON_PROVIDER.
   * if it find some. it will click on it otherwise it will do nothing.
   */ onArrowLeftPressed() {
        const backButton = document.getElementById(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ARROW_LEFT_BUTTON_PROVIDER"]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(backButton)) backButton?.click();
    }
}
const __TURBOPACK__default__export__ = KeyboardEventHandlers;
}),
"[project]/providers/GlobalListeners.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// The component will only create a single instance of class KeyboardManager and one instance of class KeyboardEventHundler.
// and register some keyboard events on window for appling shortcuts on entire system.
// It will automatically remove all the registered listeners from window .
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$EventContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/EventContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$KeyboardEventHundlers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/core/KeyboardEventHundlers.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const GlobaleListenersRegisterer = ()=>{
    const { KeyboardManager } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$EventContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEventProvider"])();
    const hasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (hasRef.current) return;
        hasRef.current = true;
        const KEH = new __TURBOPACK__imported__module__$5b$project$5d2f$core$2f$KeyboardEventHundlers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        KeyboardManager.registerKey("enter", KEH.onEnterPressed);
        KeyboardManager.registerKey("delete", KEH.onDeletePressed);
        KeyboardManager.registerKey("control->a", KEH.onCtrlPlusAPressed);
        return ()=>{
            KeyboardManager.destroy();
        };
    }, []);
    return null;
};
const __TURBOPACK__default__export__ = GlobaleListenersRegisterer;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/components/preloaders/TopProgressBar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/TopProgressBar.tsx
__turbopack_context__.s([
    "default",
    ()=>TopProgressBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nprogress$2f$nprogress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/nprogress/nprogress.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function TopProgressBar() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const timeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nprogress$2f$nprogress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].configure({
            showSpinner: false,
            trickleSpeed: 200,
            minimum: 0.3
        });
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // شروع لودر
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nprogress$2f$nprogress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].start();
        // اگر تایمر قبلی بود پاکش کن
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        // پایان لودر (بعد از اینکه route settle شد)
        timeoutRef.current = setTimeout(()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nprogress$2f$nprogress$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].done(true);
        }, 400); // عدد UX-friendly
        return ()=>{
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, [
        pathname,
        searchParams
    ]);
    return null;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4393fda4._.js.map