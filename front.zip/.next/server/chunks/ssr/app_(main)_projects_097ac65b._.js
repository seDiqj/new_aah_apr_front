module.exports = [
"[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cardsBottomButtons",
    ()=>cardsBottomButtons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/System.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
;
;
;
;
;
const cardsBottomButtons = (backBtnOnClick, backBtnOnClickFuncInput, saveBtnOnClick, nextBtnOnClick, nextBtnOnClickFuncInput, section, backBtnDisabled, nextBtnDisabled)=>{
    const { reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                id: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ARROW_LEFT_BUTTON_PROVIDER"],
                disabled: backBtnDisabled,
                variant: "outline",
                onClick: ()=>backBtnOnClick(backBtnOnClickFuncInput),
                children: "Back"
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/CardsBottomButtons.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            saveBtnOnClick && section && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                id: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SUBMIT_BUTTON_PROVIDER_ID"],
                disabled: saveBtnOnClick == null,
                onClick: ()=>reqForConfirmationModelFunc(getConfirmationMessage(section), saveBtnOnClick),
                children: "Save"
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/CardsBottomButtons.tsx",
                lineNumber: 35,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                id: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$System$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ARROW_RIGHT_BUTTON_PROVIDER"],
                disabled: nextBtnDisabled,
                onClick: ()=>nextBtnOnClick(nextBtnOnClickFuncInput),
                variant: "outline",
                children: "Next"
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/CardsBottomButtons.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
function getConfirmationMessage(section) {
    switch(section){
        case "project":
            return __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProjectCreationMessage"];
        default:
            return __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Isp3CreationMessage"];
    }
}
}),
"[project]/app/(main)/projects/Components/OutcomeForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-ssr] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-ssr] (ecmascript) <export default as Trash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/OutcomeEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const OutcomeForm = ({ mode })=>{
    const { reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { outcomes, setOutcomes, setCurrentTab, handleDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const [reqForOutcomeEditModel, setReqForOutcomeEditModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForOutcomeShowModel, setReqForOutcomeShowModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [outcomeIdForEditOrShow, setOutcomeIdForEditOrShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [reqForOutcomeForm, setReqForOutcomeForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                className: "relative h-full flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                        className: "flex flex-row items-center justify-end w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setReqForOutcomeForm(!reqForOutcomeForm),
                                children: "Add Outcomes"
                            }, void 0, false, {
                                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                lineNumber: 69,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex flex-col gap-4 overflow-auto h-[70%]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: [
                                outcomes.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-center text-sm text-muted-foreground py-3",
                                    children: "No outcomes added yet."
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                    lineNumber: 79,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                outcomes.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between px-3 py-2 border-b last:border-b-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-medium",
                                                        children: item.outcome
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-sm text-muted-foreground",
                                                        children: item.outcomeRef
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                        lineNumber: 90,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                lineNumber: 88,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-row items-center justify-end gap-2",
                                                children: [
                                                    !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__["Trash"], {
                                                        onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DeleteOutcomeMessage"], ()=>{
                                                                setOutcomes((prev)=>prev.filter((_, i)=>i !== index));
                                                                handleDelete(`projects/outcome`, item.id);
                                                            }),
                                                        className: "cursor-pointer text-red-500 hover:text-red-700",
                                                        size: 18
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                        lineNumber: 96,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotANullValue"])(item.id) && (!readOnly ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                        className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                        onClick: ()=>{
                                                            setOutcomeIdForEditOrShow(item.id);
                                                            setReqForOutcomeEditModel(true);
                                                        },
                                                        size: 18
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                        lineNumber: 114,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                        className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                        onClick: ()=>{
                                                            setOutcomeIdForEditOrShow(item.id);
                                                            setReqForOutcomeShowModel(true);
                                                        },
                                                        size: 18
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                        lineNumber: 125,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                                lineNumber: 94,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                                        lineNumber: 84,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex flex-row w-full gap-2 items-start justify-end absolute bottom-5",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "project", undefined, setCurrentTab, "output")
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                        lineNumber: 142,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && reqForOutcomeForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutcomeForm,
                onOpenChange: setReqForOutcomeForm,
                mode: "create",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                lineNumber: 154,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForOutcomeEditModel && outcomeIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutcomeEditModel,
                onOpenChange: setReqForOutcomeEditModel,
                outcomeId: outcomeIdForEditOrShow,
                mode: readOnly ? "show" : "edit",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                lineNumber: 163,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForOutcomeShowModel && outcomeIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutcomeShowModel,
                onOpenChange: setReqForOutcomeShowModel,
                outcomeId: outcomeIdForEditOrShow,
                mode: readOnly ? "show" : "edit",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutcomeForm.tsx",
                lineNumber: 172,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = OutcomeForm;
}),
"[project]/app/(main)/projects/Components/OutputForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/accordion.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-ssr] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-ssr] (ecmascript) <export default as Trash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/OutputEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const OutputForm = ({ mode })=>{
    const { reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { setCurrentTab, outcomes, outputs, setOutputs, handleDelete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const [reqForOutputEditModel, setReqForOutputEditModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForOutputShowModel, setReqForOutputShowModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [outputIdForEditOrShow, setOutputIdForEditOrShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [reqForOutputForm, setReqForOutputForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                className: "relative h-full flex flex-col overflow-y-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                        className: "flex flex-row items-center justify-end w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setReqForOutputForm(!reqForOutputForm),
                                children: "Add Output"
                            }, void 0, false, {
                                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                lineNumber: 77,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex flex-col gap-6 overflow-auto h-[70%]",
                        children: outcomes.length >= 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Accordion"], {
                            type: "single",
                            collapsible: true,
                            className: "w-full",
                            children: outcomes.filter((o)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsOutcomeSaved"])(o)).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionItem"], {
                                    value: `item-${index}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionTrigger"], {
                                            children: item.outcome
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                            lineNumber: 91,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionContent"], {
                                            className: "flex flex-col gap-4 text-balance max-h-96 overflow-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 overflow-auto border rounded-xl",
                                                children: [
                                                    outputs.filter((o)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsOutputRelatedToThisOutcome"])(Number(item.id), Number(o.outcomeId))).length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-center text-sm text-muted-foreground py-3",
                                                        children: "No outputs added yet."
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                        lineNumber: 101,
                                                        columnNumber: 27
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    outputs.filter((outputItem)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsOutputRelatedToThisOutcome"])(Number(item.id), Number(outputItem.outcomeId))).map((outputItem, outIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between px-3 py-2 border-b last:border-b-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex flex-col",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-medium",
                                                                            children: outputItem.output
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                            lineNumber: 118,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-sm text-muted-foreground",
                                                                            children: outputItem.outputRef
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                            lineNumber: 121,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                    lineNumber: 117,
                                                                    columnNumber: 31
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex flex-row items-center justify-end gap-2",
                                                                    children: [
                                                                        !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__["Trash"], {
                                                                            onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DeleteOutputMessage"], ()=>{
                                                                                    setOutputs((prev)=>prev.filter((_, i)=>i !== index));
                                                                                    handleDelete(`projects/output`, outputItem.id);
                                                                                }),
                                                                            className: "cursor-pointer text-red-500 hover:text-red-700",
                                                                            size: 18
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                            lineNumber: 127,
                                                                            columnNumber: 35
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        outputItem.id && (!readOnly ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                                            className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                                            onClick: ()=>{
                                                                                setOutputIdForEditOrShow(outputItem.id);
                                                                                setReqForOutputEditModel(true);
                                                                            },
                                                                            size: 18
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                            lineNumber: 148,
                                                                            columnNumber: 37
                                                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                                            className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                                            onClick: ()=>{
                                                                                setOutputIdForEditOrShow(outputItem.id);
                                                                                setReqForOutputShowModel(true);
                                                                            },
                                                                            size: 18
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                            lineNumber: 159,
                                                                            columnNumber: 37
                                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                                    lineNumber: 125,
                                                                    columnNumber: 31
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, outIndex, true, {
                                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                            lineNumber: 113,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                                lineNumber: 94,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                            lineNumber: 92,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, index, true, {
                                    fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                                    lineNumber: 90,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                            lineNumber: 86,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-row items-center justify-center text-center text-muted-foreground text-sm",
                            children: "No output added yet !"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                            lineNumber: 179,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                        lineNumber: 84,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex flex-row w-full gap-2 items-start justify-end absolute bottom-5",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "outcome", undefined, setCurrentTab, "indicator")
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && reqForOutputForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutputForm,
                onOpenChange: setReqForOutputForm,
                mode: "create",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                lineNumber: 197,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForOutputEditModel && outputIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutputEditModel,
                onOpenChange: ()=>setReqForOutputEditModel(false),
                mode: readOnly ? "show" : "edit",
                pageIdentifier: mode,
                outputId: outputIdForEditOrShow
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                lineNumber: 206,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForOutputShowModel && outputIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForOutputShowModel,
                onOpenChange: ()=>setReqForOutputShowModel(false),
                mode: readOnly ? "show" : "edit",
                pageIdentifier: mode,
                outputId: outputIdForEditOrShow
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/OutputForm.tsx",
                lineNumber: 216,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = OutputForm;
}),
"[project]/app/(main)/projects/Components/DessaggregationForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/separator.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/table.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/checkbox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/StringToCapital.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$DessaggregationFormHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/DessaggregationFormHelpers.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const DessaggregationForm = ({ mode })=>{
    const { indicators, setCurrentTab, dessaggregations, setDessaggregations } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const { reqForToastAndSetMessage, axiosInstance, reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    let [selectedIndicator, setSelectedIndicator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])();
    const [activeDessaggregationTab, setActiveDessaggregationTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(undefined);
    const [dessaggregationBeforeEdit, setDessaggregationBeforeEdit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const hundleSubmit = ()=>{
        axiosInstance.post("/projects/d/disaggregation", {
            dessaggregations: dessaggregations
        }).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>{
            reqForToastAndSetMessage(error.response.data.message);
        });
    };
    const handleUpdateDessaggregation = ()=>{
        axiosInstance.put("/projects/dissaggregation", {
            dessaggregations: dessaggregations
        }).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    const addOrRemoveDessaggregation = (shouldBeAdd, description, province, indicator)=>{
        if (shouldBeAdd) {
            setDessaggregations((prev)=>{
                // Check if dessaggregation is already in dessaggregations list.
                if (prev.some((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HasDessaggregationTheseFeature"])(d, description, province, indicator.indicatorRef))) return prev;
                return [
                    ...prev,
                    {
                        id: null,
                        indicatorId: selectedIndicator.id,
                        indicatorRef: selectedIndicator.indicatorRef,
                        dessaggration: description,
                        province: province,
                        target: 0
                    }
                ];
            });
        } else {
            setDessaggregations((prev)=>prev.filter((d)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HasDessaggregationTheseFeature"])(d, description, province, indicator.indicatorRef)));
        }
    };
    const calculateProvinceDessaggregationsTotal = (province, indicatorRef)=>{
        return dessaggregations.filter((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsTheDessaggregationOfThisIndicatorAndProvince"])(d, province, indicatorRef)).reduce((sum, d)=>sum + Number(d.target || 0), 0);
    };
    const handleDessaggregationsInputsChange = (description, province, indicator, newTarget)=>{
        const num = newTarget === "" ? 0 : Number(newTarget);
        setDessaggregations((prev)=>{
            const foundIndex = prev.findIndex((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HasDessaggregationTheseFeature"])(d, description, province, indicator.indicatorRef));
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WasIndexFound"])(foundIndex)) {
                const copy = [
                    ...prev
                ];
                copy[foundIndex] = {
                    ...copy[foundIndex],
                    target: num
                };
                return copy;
            } else {
                return [
                    ...prev,
                    {
                        id: null,
                        indicatorId: indicator.id,
                        indicatorRef: indicator.indicatorRef,
                        dessaggration: description,
                        province: province,
                        target: num
                    }
                ];
            }
        });
    };
    const onCancel = ()=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AreDessaggregationsEdited"])(dessaggregationBeforeEdit, dessaggregations)) reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CancelButtonMessage"], ()=>{
            setDessaggregations(dessaggregationBeforeEdit);
            setSelectedIndicator(null);
        });
        else {
            setDessaggregations(dessaggregationBeforeEdit);
            setSelectedIndicator(null);
        }
    };
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full w-full relative overflow-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: "Dessaggregation"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardDescription"], {
                            children: "Define dessaggregation for your indicators."
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                            lineNumber: 240,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                    lineNumber: 238,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "grid gap-6 overflow-auto h-[70%]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-3 w-full",
                        children: [
                            indicators.filter((indicator)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsIndicatorSaved"])(indicator)).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                                    className: "w-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                                        className: "flex items-center justify-between ",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-base font-medium",
                                                children: item.indicator
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                lineNumber: 253,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                onClick: ()=>{
                                                    setSelectedIndicator(item);
                                                    setActiveDessaggregationTab((0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringToCapital"])(item.dessaggregationType));
                                                    setDessaggregationBeforeEdit(dessaggregations);
                                                },
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? "Add" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? "Check" : "Edit"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                lineNumber: 256,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                        lineNumber: 252,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, index, false, {
                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                    lineNumber: 251,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))),
                            selectedIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Dialog"], {
                                open: true,
                                onOpenChange: ()=>{
                                    setDessaggregations(dessaggregationBeforeEdit);
                                    setSelectedIndicator(null);
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogContent"], {
                                    className: "flex flex-col justify-between sm:max-w-2xl md:max-w-4xl lg:max-w-6xl h-[90vh]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogHeader"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                                children: `${selectedIndicator.indicator}: (Target : ${selectedIndicator.target})`
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                lineNumber: 285,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                            lineNumber: 284,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col w-full h-full z-50 overflow-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-row items-center justify-around",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Tabs"], {
                                                    value: activeDessaggregationTab,
                                                    onValueChange: setActiveDessaggregationTab,
                                                    className: "w-full h-full",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsList"], {
                                                            className: "items-center justify-around w-full",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                                    value: selectedIndicator.dessaggregationType.toLowerCase(),
                                                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringToCapital"])(selectedIndicator.dessaggregationType)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                    lineNumber: 299,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                selectedIndicator.subIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                                                    value: selectedIndicator.subIndicator.dessaggregationType.toLowerCase(),
                                                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringToCapital"])(selectedIndicator.subIndicator.dessaggregationType)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                    lineNumber: 307,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                            lineNumber: 298,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                                            className: "w-full",
                                                            value: selectedIndicator.dessaggregationType.toLowerCase(),
                                                            children: selectedIndicator.provinces.map((province)=>{
                                                                const totalForProvince = calculateProvinceDessaggregationsTotal(province.province, selectedIndicator.indicatorRef);
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Table"], {
                                                                            className: "border-2 mx-auto w-[90%]",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCaption"], {
                                                                                    className: "caption-top text-left",
                                                                                    children: `${province.province} (Target : ${province.target})`
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 333,
                                                                                    columnNumber: 35
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHeader"], {
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                        className: "border-2 w-10",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {}, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 340,
                                                                                                    columnNumber: 41
                                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 339,
                                                                                                columnNumber: 39
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: "Description"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 342,
                                                                                                columnNumber: 39
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: "Target"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 345,
                                                                                                columnNumber: 39
                                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                        lineNumber: 338,
                                                                                        columnNumber: 37
                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 337,
                                                                                    columnNumber: 35
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableBody"], {
                                                                                    children: [
                                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$DessaggregationFormHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getReliableDessaggregationOptionsAccordingToDessagregationType"])(selectedIndicator.dessaggregationType).map((opt, i)=>{
                                                                                            const existing = dessaggregations.find((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HasDessaggregationTheseFeature"])(d, opt, province.province, selectedIndicator?.indicatorRef));
                                                                                            const isChecked = !!existing;
                                                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        className: "text-center w-10",
                                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                                                                            checked: isChecked,
                                                                                                            onCheckedChange: (checked)=>addOrRemoveDessaggregation(checked, opt, province.province, selectedIndicator),
                                                                                                            disabled: readOnly
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                            lineNumber: 369,
                                                                                                            columnNumber: 45
                                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 368,
                                                                                                        columnNumber: 43
                                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        className: "text-center",
                                                                                                        children: opt
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 383,
                                                                                                        columnNumber: 43
                                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                                                                                            type: "number",
                                                                                                            value: existing ? String(existing.target) : "",
                                                                                                            onChange: (e)=>handleDessaggregationsInputsChange(opt, province.province, selectedIndicator, e.target.value),
                                                                                                            className: "mx-auto max-w-[200px] text-center",
                                                                                                            disabled: readOnly
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                            lineNumber: 388,
                                                                                                            columnNumber: 45
                                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 387,
                                                                                                        columnNumber: 43
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                ]
                                                                                            }, i, true, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 367,
                                                                                                columnNumber: 41
                                                                                            }, ("TURBOPACK compile-time value", void 0));
                                                                                        }),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    className: "text-center w-10",
                                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                                                                        className: "hidden"
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 413,
                                                                                                        columnNumber: 41
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 412,
                                                                                                    columnNumber: 39
                                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    className: "text-center",
                                                                                                    children: "TOTAL TARGET"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 415,
                                                                                                    columnNumber: 39
                                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                                                                                        disabled: true,
                                                                                                        value: totalForProvince,
                                                                                                        className: "mx-auto max-w-[200px] text-center"
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 419,
                                                                                                        columnNumber: 41
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 418,
                                                                                                    columnNumber: 39
                                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                            lineNumber: 411,
                                                                                            columnNumber: 37
                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 351,
                                                                                    columnNumber: 35
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 332,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsTotalOfDessaggregationsOfProvinceBiggerThenTotalOfProvince"])(totalForProvince, province.target || 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex flex-row items-center justify-start w-[90%] mx-auto",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-red-500 text-sm mt-2",
                                                                                children: [
                                                                                    "⚠ The total target (",
                                                                                    totalForProvince,
                                                                                    ") exceeds the assigned target (",
                                                                                    province.target,
                                                                                    ") for ",
                                                                                    province.province,
                                                                                    "!"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                lineNumber: 434,
                                                                                columnNumber: 37
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 433,
                                                                            columnNumber: 35
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsTotalOfDessaggregationsOfProvinceLessThenTotalOfProvince"])(totalForProvince, province.target || 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex flex-row items-center justify-start w-[90%] mx-auto",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-red-500 text-sm mt-2",
                                                                                children: [
                                                                                    "⚠ The total target (",
                                                                                    totalForProvince,
                                                                                    ") should be equal to assigned target (",
                                                                                    province.target,
                                                                                    ") for ",
                                                                                    province.province,
                                                                                    "!"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                lineNumber: 447,
                                                                                columnNumber: 37
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 446,
                                                                            columnNumber: 35
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
                                                                            className: "my-5"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 455,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, province.province, true, {
                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                    lineNumber: 331,
                                                                    columnNumber: 31
                                                                }, ("TURBOPACK compile-time value", void 0));
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                            lineNumber: 319,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        selectedIndicator.subIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                                            value: selectedIndicator.subIndicator.dessaggregationType.toLowerCase(),
                                                            children: selectedIndicator.subIndicator.provinces.map((province)=>{
                                                                const totalForProvince = calculateProvinceDessaggregationsTotal(province.province, selectedIndicator?.subIndicator.indicatorRef);
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Table"], {
                                                                            className: "border-2 mx-auto w-[90%]",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCaption"], {
                                                                                    className: "caption-top text-left",
                                                                                    children: `${province.province} (Target : ${province.target})`
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 478,
                                                                                    columnNumber: 39
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHeader"], {
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                        className: "border-2 w-10",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {}, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 484,
                                                                                                    columnNumber: 45
                                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 483,
                                                                                                columnNumber: 43
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: "Description"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 486,
                                                                                                columnNumber: 43
                                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                                                                className: "text-center",
                                                                                                children: "Target"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 489,
                                                                                                columnNumber: 43
                                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                        lineNumber: 482,
                                                                                        columnNumber: 41
                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 481,
                                                                                    columnNumber: 39
                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableBody"], {
                                                                                    children: [
                                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$DessaggregationFormHelpers$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getReliableDessaggregationOptionsForSubIndicatorAccordingToDessagregationType"])(selectedIndicator.subIndicator.dessaggregationType).map((opt, i)=>{
                                                                                            const existing = dessaggregations.find((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HasDessaggregationTheseFeature"])(d, opt, province.province, selectedIndicator?.subIndicator.indicatorRef));
                                                                                            const isChecked = !!existing;
                                                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        className: "text-center w-10",
                                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                                                                            checked: isChecked,
                                                                                                            onCheckedChange: (checked)=>addOrRemoveDessaggregation(checked, opt, province.province, selectedIndicator.subIndicator),
                                                                                                            disabled: readOnly
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                            lineNumber: 514,
                                                                                                            columnNumber: 49
                                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 513,
                                                                                                        columnNumber: 47
                                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        className: "text-center",
                                                                                                        children: opt
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 528,
                                                                                                        columnNumber: 47
                                                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                                                                                            type: "number",
                                                                                                            value: existing ? String(existing.target) : "",
                                                                                                            onChange: (e)=>{
                                                                                                                handleDessaggregationsInputsChange(opt, province.province, selectedIndicator.subIndicator, e.target.value);
                                                                                                            },
                                                                                                            className: "mx-auto max-w-[200px] text-center",
                                                                                                            disabled: readOnly
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                            lineNumber: 533,
                                                                                                            columnNumber: 49
                                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 532,
                                                                                                        columnNumber: 47
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                ]
                                                                                            }, i, true, {
                                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                lineNumber: 512,
                                                                                                columnNumber: 45
                                                                                            }, ("TURBOPACK compile-time value", void 0));
                                                                                        }),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    className: "text-center w-10",
                                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                                                                        className: "hidden"
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 558,
                                                                                                        columnNumber: 45
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 557,
                                                                                                    columnNumber: 43
                                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    className: "text-center",
                                                                                                    children: "TOTAL TARGET"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 560,
                                                                                                    columnNumber: 43
                                                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                                                                                        disabled: true,
                                                                                                        value: totalForProvince,
                                                                                                        className: "mx-auto max-w-[200px] text-center"
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                        lineNumber: 564,
                                                                                                        columnNumber: 45
                                                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                                    lineNumber: 563,
                                                                                                    columnNumber: 43
                                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                            lineNumber: 556,
                                                                                            columnNumber: 41
                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                    lineNumber: 494,
                                                                                    columnNumber: 39
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 477,
                                                                            columnNumber: 37
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsTotalOfDessaggregationsOfProvinceBiggerThenTotalOfProvince"])(totalForProvince, province.target) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex flex-row items-center justify-start w-[90%] mx-auto",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-red-500 text-sm mt-2",
                                                                                children: [
                                                                                    "⚠ The total target (",
                                                                                    totalForProvince,
                                                                                    ") exceeds the assigned target (",
                                                                                    province.target,
                                                                                    ") for",
                                                                                    " ",
                                                                                    province.province,
                                                                                    "!"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                lineNumber: 579,
                                                                                columnNumber: 41
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 578,
                                                                            columnNumber: 39
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsTotalOfDessaggregationsOfProvinceLessThenTotalOfProvince"])(totalForProvince, province.target) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex flex-row items-center justify-start w-[90%] mx-auto",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-red-500 text-sm mt-2",
                                                                                children: [
                                                                                    "⚠ The total target (",
                                                                                    totalForProvince,
                                                                                    ") should be equal to assigned target (",
                                                                                    province.target,
                                                                                    ") for",
                                                                                    " ",
                                                                                    province.province,
                                                                                    "!"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                                lineNumber: 592,
                                                                                columnNumber: 41
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 591,
                                                                            columnNumber: 39
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
                                                                            className: "my-5"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                            lineNumber: 600,
                                                                            columnNumber: 37
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, province.province, true, {
                                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                                    lineNumber: 476,
                                                                    columnNumber: 35
                                                                }, ("TURBOPACK compile-time value", void 0));
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                            lineNumber: 463,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                    lineNumber: 293,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                lineNumber: 292,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                            lineNumber: 290,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogFooter"], {
                                            className: "z-50",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-row items-center justify-end fixed bottom-0 gap-4",
                                                children: [
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        className: "bg-blue-400",
                                                        onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResetButtonMessage"], ()=>setDessaggregations((prev)=>prev.filter((d)=>d.indicatorId != selectedIndicator.id))),
                                                        children: "Reset"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                        lineNumber: 614,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        onClick: onCancel,
                                                        className: "bg-red-400",
                                                        children: "Cancel"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                        lineNumber: 631,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        type: "button",
                                                        className: "bg-green-400",
                                                        disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isTheTotalTargetOfDessaggregationsEqualToTotalTargetOfIndicator"])(selectedIndicator, dessaggregations),
                                                        onClick: (e)=>{
                                                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isTheTotalTargetOfDessaggregationsEqualToTotalTargetOfIndicator"])(selectedIndicator, dessaggregations)) {
                                                                reqForToastAndSetMessage("The total target of dessaggregations should be equal to total target of indicator !");
                                                                return;
                                                            }
                                                            reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DoneButtonMessage"], ()=>{
                                                                setSelectedIndicator(null);
                                                                hundleSubmit();
                                                            });
                                                        },
                                                        children: "Done"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                        lineNumber: 635,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                                lineNumber: 612,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                            lineNumber: 611,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                    lineNumber: 283,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                                lineNumber: 276,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                        lineNumber: 246,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                    lineNumber: 245,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                    className: "flex flex-row items-center justify-end w-full absolute bottom-5",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "indicator", undefined, setCurrentTab, "aprPreview")
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
                    lineNumber: 674,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/projects/Components/DessaggregationForm.tsx",
            lineNumber: 237,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = DessaggregationForm;
}),
"[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/checkbox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/utils/OptionLists.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/PermissionContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const AprFinalizationSubPage = ({ mode })=>{
    const { reqForToastAndSetMessage, axiosInstance, reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { projectId, actionLogs, setActionLogs, projectAprStatus, setProjectAprStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const { permissions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePermissions"])();
    const [comment, setComment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [reqForCreationModel, setReqForCreationModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForSubmitionModel, setReqForSubmitionModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForGrantFinalizationModel, setReqForGrantFinalizationModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForHqFinalizationModel, setReqForHqFinalizationModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const changeProjectAprStatus = (status)=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsValidAprStatus"])(status)) {
            reqForToastAndSetMessage("Wronge status !");
            return;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsEnteredStatusLocaltedAtTheLowerLevelThenTheCurrentStatus"])(projectAprStatus, status)) {
            reqForToastAndSetMessage(`You can not set the project status to ${status} while its ${projectAprStatus} ! 
            Note: if you wanna to change the apr status of project to ${status} please before that reject it at the top level stages and then try agein.`);
            return;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsEnteredStatusCallsToRejectAtTheLevelAboveTheCurrentLimit"])(projectAprStatus, status)) {
            reqForToastAndSetMessage(`You can not reject a project at the ${status} stage while its on ${projectAprStatus} stage !`);
            return;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsEnteredStatusCallingToBeApproveAtLevelAboveTheAllowedLevel"])(projectAprStatus, status)) {
            reqForToastAndSetMessage(`You can not change the apr status of a project to ${status} while not yet accepted at the previos levels !`);
            return;
        }
        axiosInstance.post(`projects/status/change_apr_status/${projectId}`, {
            newStatus: status,
            comment: comment
        }).then((response)=>{
            reqForToastAndSetMessage(response.data.message);
            setProjectAprStatus(response.data.data);
            [
                setReqForCreationModel,
                setReqForSubmitionModel,
                setReqForGrantFinalizationModel,
                setReqForHqFinalizationModel
            ].map((value)=>value((prev)=>prev ? !prev : prev));
        }).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get(`/projects/get_project_finalizers_details/${projectId}`).then((response)=>setActionLogs(response.data.data)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    }, [
        projectAprStatus
    ]);
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                        children: "Apr Finalization"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                        lineNumber: 145,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "grid gap-6",
                    children: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["aprFinalizationSteps"].filter((step)=>permissions.includes(step.permission)).map((step, index)=>{
                            const canReject = index !== 0;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between gap-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3 w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialog"], {
                                            open: step.id == "create" ? reqForCreationModel : step.id == "submit" ? reqForSubmitionModel : step.id == "grantFinalize" ? reqForGrantFinalizationModel : reqForHqFinalizationModel,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTrigger"], {
                                                        asChild: true,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                            id: step.id,
                                                            checked: (()=>{
                                                                const currentIdx = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["projectAprStatusList"].indexOf(projectAprStatus);
                                                                const stepIdx = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["projectAprStatusList"].indexOf(step.acceptStatusValue);
                                                                const isRejected = step.rejectStatusValue ? projectAprStatus === step.rejectStatusValue : false;
                                                                return !isRejected && stepIdx !== -1 && currentIdx >= stepIdx;
                                                            })() || projectAprStatus == step.acceptStatusValue,
                                                            onCheckedChange: ()=>step.id == "create" ? setReqForCreationModel(true) : step.id == "submit" ? setReqForSubmitionModel(true) : step.id == "grantFinalize" ? setReqForGrantFinalizationModel(true) : setReqForHqFinalizationModel(true),
                                                            disabled: readOnly
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 172,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                        lineNumber: 171,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 170,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                                                    className: "space-y-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                                                    children: canReject ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                        children: [
                                                                            "Do you want to",
                                                                            " ",
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-green-600",
                                                                                children: "Accept"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                                lineNumber: 215,
                                                                                columnNumber: 33
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            " ",
                                                                            "or ",
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-red-600",
                                                                                children: "Reject"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                                lineNumber: 216,
                                                                                columnNumber: 36
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            " ",
                                                                            "this step?"
                                                                        ]
                                                                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                        children: [
                                                                            "Confirm",
                                                                            " ",
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-green-600",
                                                                                children: step.label
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                                lineNumber: 222,
                                                                                columnNumber: 33
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            "?"
                                                                        ]
                                                                    }, void 0, true)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 211,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                                                    children: step.description
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 229,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 210,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex flex-col gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                                                    htmlFor: `comment-${step.id}`,
                                                                    className: "text-sm font-medium",
                                                                    children: "Enter your comment"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 236,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                                                                    id: `comment-${step.id}`,
                                                                    value: comment,
                                                                    onChange: (e)=>setComment(e.target.value),
                                                                    className: "resize-none border rounded p-2 text-sm",
                                                                    placeholder: "Write your comment here...",
                                                                    disabled: readOnly
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 242,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 235,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                                                            className: "flex justify-between",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                                                    onClick: ()=>step.id == "create" ? setReqForCreationModel(false) : step.id == "submit" ? setReqForSubmitionModel(false) : step.id == "grantFinalize" ? setReqForGrantFinalizationModel(false) : setReqForHqFinalizationModel(false),
                                                                    children: "Cancel"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 253,
                                                                    columnNumber: 27
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                canReject ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                                            variant: "destructive",
                                                                            onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RejectFinalizationMessage"], ()=>{
                                                                                    if (comment.trim()) {
                                                                                        changeProjectAprStatus(step.rejectStatusValue);
                                                                                    } else {
                                                                                        reqForToastAndSetMessage("Comment section is required !");
                                                                                    }
                                                                                }),
                                                                            disabled: readOnly,
                                                                            children: "Reject"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                            lineNumber: 269,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                                            onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AcceptFinalizationMessage"], ()=>{
                                                                                    if (comment.trim()) {
                                                                                        changeProjectAprStatus(step.acceptStatusValue);
                                                                                    } else {
                                                                                        reqForToastAndSetMessage("Comment section is required !");
                                                                                    }
                                                                                }),
                                                                            disabled: readOnly,
                                                                            children: "Accept"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                            lineNumber: 292,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 268,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                                    onClick: ()=>{
                                                                        if (comment.trim()) {
                                                                            changeProjectAprStatus(step.acceptStatusValue);
                                                                        } else {
                                                                            reqForToastAndSetMessage("Comment section is required !");
                                                                        }
                                                                    },
                                                                    disabled: readOnly,
                                                                    children: step.buttonLabel
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                                    lineNumber: 315,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 252,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                            lineNumber: 159,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-row items-center justify-between w-full",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: step.id,
                                                    children: step.label
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 337,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: `${actionLogs.find((log)=>log.action === step.id)?.name ?? "Pending"} - ${actionLogs.find((log)=>log.action === step.id)?.date ?? "N/A"}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                        lineNumber: 340,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 339,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                            lineNumber: 336,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                    lineNumber: 158,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            }, step.id, false, {
                                fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                lineNumber: 154,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0));
                        }),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-8 max-w-full overflow-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-semibold mb-4",
                                    children: "Action Progress"
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                    lineNumber: 360,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-4 overflow-x-auto p-3  rounded-xl shadow-inner",
                                    children: actionLogs.map((log, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 shrink-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-col items-center text-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: log.avatar,
                                                            alt: log.name,
                                                            className: "w-10 h-10 rounded-full border-2 border-gray-300 object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 366,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs mt-1 font-medium",
                                                            children: log.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 371,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `text-xs px-2 py-1 rounded-full mt-1 ${log.action === "Accepted" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                                            children: log.action
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                            lineNumber: 372,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                i < actionLogs.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-10 h-[2px] bg-gray-300 mx-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                                    lineNumber: 384,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, log.id, true, {
                                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                            lineNumber: 364,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                                    lineNumber: 362,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                            lineNumber: 359,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
                    lineNumber: 148,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx",
            lineNumber: 143,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = AprFinalizationSubPage;
}),
"[project]/app/(main)/projects/Components/AprLogsSubPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/table.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
const AprLogsSubPage = ({ mode })=>{
    const { axiosInstance, reqForToastAndSetMessage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { projectId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const [selectedComment, setSelectedComment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [logs, setLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get(`/projects/logs/${projectId}`).then((response)=>setLogs(response.data.data)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                        children: "Apr Finalization"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                        lineNumber: 53,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "grid gap-6 overflow-y-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Table"], {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "w-[150px]",
                                                    children: "Action"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                    lineNumber: 60,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "w-[120px]",
                                                    children: "Doer"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                    lineNumber: 61,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "w-[250px]",
                                                    children: "Comment"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                    lineNumber: 62,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "w-[120px]",
                                                    children: "Date"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                            lineNumber: 59,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                        lineNumber: 58,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableBody"], {
                                        children: logs.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableRow"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        children: item.action
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                        lineNumber: 69,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        children: item.userName
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                        lineNumber: 70,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>{
                                                                setSelectedComment(item.comment);
                                                                setOpen(true);
                                                            },
                                                            className: "block max-w-[220px] truncate text-left hover:underline",
                                                            title: "Click for check full comment",
                                                            children: item.comment
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                            lineNumber: 72,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                        lineNumber: 71,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        children: item.date
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                        lineNumber: 83,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, index, true, {
                                                fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                lineNumber: 68,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                        lineNumber: 66,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Dialog"], {
                                open: open,
                                onOpenChange: setOpen,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogContent"], {
                                    className: "max-w-lg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogHeader"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                                children: "Comment"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                lineNumber: 92,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-2 text-sm text-gray-700",
                                            children: selectedComment
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                            lineNumber: 94,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 flex justify-end",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                onClick: ()=>setOpen(false),
                                                children: "Close"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                                lineNumber: 98,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                                lineNumber: 89,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/projects/Components/AprLogsSubPage.tsx",
            lineNumber: 51,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = AprLogsSubPage;
}),
"[project]/app/(main)/projects/Components/IndicatorForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/accordion.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-ssr] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-ssr] (ecmascript) <export default as Trash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/IndicatorEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/ConfirmationModelsTexts.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const IndicatorForm = ({ mode })=>{
    const { reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { outputs, indicators, setIndicators, setCurrentTab, handleDelete, setDessaggregations } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const [indicatorIdForEditOrShow, setIndicatorIdForEditOrShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [reqForIndicatorEditModel, setReqForIndicatorEditModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForIndicatorShowModel, setReqForIndicatorShowModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    const [reqForIndicatorForm, setReqForIndicatorForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                className: "relative h-full flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                        className: "flex flex-row items-center justify-end w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setReqForIndicatorForm(!reqForIndicatorForm),
                                children: "Add Indicator"
                            }, void 0, false, {
                                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                lineNumber: 80,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                            lineNumber: 78,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex flex-col gap-6 overflow-auto h-[70%]",
                        children: outputs.length >= 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Accordion"], {
                            type: "single",
                            collapsible: true,
                            className: "w-full",
                            children: outputs.filter((o)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsOutputSaved"])(o)).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionItem"], {
                                    value: `item-${index}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionTrigger"], {
                                            children: item.output
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                            lineNumber: 96,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccordionContent"], {
                                            className: "flex flex-col gap-6 max-h-[600px] overflow-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 max-h-[200px] overflow-auto border rounded-xl",
                                                children: indicators.filter((ind)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsIndicatorRelatedToThisOutput"])(Number(item.id), Number(ind.outputId)))// .filter((ind) => IsNotSubIndicator(ind))
                                                .map((indItem, indIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between px-3 py-2 border-b last:border-b-0",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex flex-col",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "font-medium",
                                                                        children: indItem.indicator
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                        lineNumber: 114,
                                                                        columnNumber: 33
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-sm text-muted-foreground",
                                                                        children: indItem.indicatorRef
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                        lineNumber: 117,
                                                                        columnNumber: 33
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                lineNumber: 113,
                                                                columnNumber: 31
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex flex-row items-center justify-end gap-2",
                                                                children: [
                                                                    !readOnly && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__["Trash"], {
                                                                        onClick: ()=>reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DeleteIndicatorMessage"], ()=>{
                                                                                setIndicators((prev)=>prev.filter((_, i)=>i !== indIndex));
                                                                                setDessaggregations((prev)=>prev.filter((d)=>indicators.some((i)=>i.id == d.indicatorId)));
                                                                                handleDelete("projects/indicator", indItem.id);
                                                                            }),
                                                                        className: "cursor-pointer text-red-500 hover:text-red-700",
                                                                        size: 18
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                        lineNumber: 124,
                                                                        columnNumber: 35
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    indItem.id && (readOnly ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                                        className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                                        onClick: ()=>{
                                                                            setReqForIndicatorShowModel(true);
                                                                            setIndicatorIdForEditOrShow(Number(indItem.id));
                                                                        },
                                                                        size: 18
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                        lineNumber: 154,
                                                                        columnNumber: 37
                                                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                                        className: "cursor-pointer text-orange-500 hover:text-orange-700",
                                                                        onClick: ()=>{
                                                                            setReqForIndicatorEditModel(true);
                                                                            setIndicatorIdForEditOrShow(Number(indItem.id));
                                                                        },
                                                                        size: 18
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                        lineNumber: 165,
                                                                        columnNumber: 37
                                                                    }, ("TURBOPACK compile-time value", void 0)))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                                lineNumber: 122,
                                                                columnNumber: 31
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, indIndex, true, {
                                                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                        lineNumber: 109,
                                                        columnNumber: 29
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                                lineNumber: 99,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                            lineNumber: 97,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, index, true, {
                                    fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                                    lineNumber: 95,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-row items-center justify-center text-center text-sm text-muted-foreground",
                            children: "No indicator added yet !"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                            lineNumber: 185,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex flex-row w-full gap-2 items-start justify-end absolute bottom-5",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "output", undefined, setCurrentTab, "dessaggregation")
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                        lineNumber: 191,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && reqForIndicatorForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForIndicatorForm,
                onClose: ()=>setReqForIndicatorForm(false),
                mode: "create",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                lineNumber: 203,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForIndicatorEditModel && indicatorIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForIndicatorEditModel,
                onClose: ()=>setReqForIndicatorEditModel(false),
                indicatorId: indicatorIdForEditOrShow,
                mode: "edit",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                lineNumber: 212,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            reqForIndicatorShowModel && indicatorIdForEditOrShow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: reqForIndicatorShowModel,
                onClose: ()=>setReqForIndicatorShowModel(false),
                indicatorId: indicatorIdForEditOrShow,
                mode: "show",
                pageIdentifier: mode
            }, void 0, false, {
                fileName: "[project]/app/(main)/projects/Components/IndicatorForm.tsx",
                lineNumber: 221,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = IndicatorForm;
}),
"[project]/app/(main)/projects/Components/Isp3SubPage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/multi-select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
const Isp3SubPage = ({ mode })=>{
    const { axiosInstance, reqForToastAndSetMessage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { indicators, setCurrentTab, isp3, setIsp3 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const hundleSubmit = ()=>{
        if (readOnly) return;
        axiosInstance.post("/projects/is/isp3", {
            isp3s: isp3
        }).then((response)=>{
            reqForToastAndSetMessage(response.data.message);
        }).catch((error)=>{
            reqForToastAndSetMessage(error.response.data.message);
        });
    };
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>/* eslint-disable */ console.log(...oo_oo(`404560340_63_18_63_35_4`, isp3)), [
        isp3
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full w-full relative overflow-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: "ISP3"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardDescription"], {
                            children: "Link indicators to isp3."
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "flex flex-col gap-6 overflow-auto h-[70%]",
                    children: isp3.map((item, index)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                    className: "whitespace-nowrap",
                                    children: item.name
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                                    lineNumber: 80,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-[280px] flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MultiSelect"], {
                                        options: indicators.filter((indicator)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsIndicatorSaved"])(indicator)).map((ind)=>({
                                                label: ind.indicatorRef,
                                                value: String(ind.id)
                                            })),
                                        value: item.indicators.map((ind)=>String(ind)),
                                        onValueChange: (value)=>setIsp3((prev)=>prev.map((i)=>i.name === item.name ? {
                                                        ...i,
                                                        indicators: value
                                                    } : i)),
                                        placeholder: "Select indicator to link",
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                                        lineNumber: 83,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                                    lineNumber: 82,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, index, true, {
                            fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                            lineNumber: 76,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0));
                    })
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                    lineNumber: 73,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                    className: "flex flex-row items-center justify-end w-full absolute bottom-5",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "aprPreview", readOnly ? undefined : hundleSubmit, setCurrentTab, "finalization", "isp3")
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
                    lineNumber: 107,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/projects/Components/Isp3SubPage.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = Isp3SubPage;
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5eb7(){var _0x5312cb=['3256wREwNO','negativeZero','startsWith','toUpperCase','NEGATIVE_INFINITY','defaultLimits','length','_connected','5kjcSVz','next.js','213606VniQVN','origin','bigint','_connecting','get','then','Symbol','Map','index','funcName','resetWhenQuietMs','_isMap','type','2241WiVaRR','object','warn','nodeModules','node','1766156314250','1284920DYQWdu','_hasMapOnItsPath','sortProps','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','_setNodeLabel','now','hostname','POSITIVE_INFINITY','expressionsToEvaluate','4787388frDXrm','totalStrLength','','reduceOnCount','autoExpandLimit','_webSocketErrorDocsLink','3810','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','_processTreeNodeResult','edge','_connectAttemptCount','_ws','\\x20server','logger\\x20websocket\\x20error','1437783aYwZoA','reduceLimits','unshift','unknown','onerror','replace','hrtime','_HTMLAllCollection','expId','console','reload','root_exp_id','parent','allStrLength','strLength','setter','sort','_console_ninja','_capIfString','root_exp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','undefined','_type','_p_','_socket','_setNodeQueryPath','','log','port','_hasSetOnItsPath','capped','_p_name','host','reducedLimits','127.0.0.1','[object\\x20Set]','onmessage','value','_cleanNode','resolveGetters','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','substr','performance','autoExpandPreviousObjects','prototype','onopen','_allowedToSend','_getOwnPropertyNames','_treeNodePropertiesBeforeFullValue','indexOf','import(\\x27path\\x27)','slice','bind','_treeNodePropertiesAfterFullValue','constructor','[object\\x20Date]','perLogpoint','pop','_setNodeExpandableState','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','call','null','current','serialize','readyState','[object\\x20BigInt]','_getOwnPropertySymbols','_isSet','1078085AFsroT','autoExpand','count','trace','valueOf','isExpressionToEvaluate','_allowedToConnectOnSend','time','toLowerCase','gateway.docker.internal','path','hits','resolve','_additionalMetadata','fromCharCode','stack',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'next.js','_addProperty','_getOwnPropertyDescriptor','versions','symbol','close','_quotedRegExp','map','Set','default','NEXT_RUNTIME','Number','_inNextEdge','args','_sortProps','_ninjaIgnoreNextError','send','onclose','push','unref','error','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','33847uocYVR','process','getWebSocketClass','autoExpandPropertyCount','iterator','reducePolicy','_inBrowser','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','7710dhZant','toString','rootExpression','array','expo','_maxConnectAttemptCount','charAt','elements','eventReceivedCallback','forEach','_disposeWebsocket','_objectToString','modules','1.0.0','\\x20browser','Boolean','function','_WebSocket','env','reduceOnAccumulatedProcessingTimeMs','endsWith','Error','_extendedWarning','match','_isUndefined','positiveInfinity','_setNodePermissions','...','url','resetOnProcessingTimeAverageMs','getter','negativeInfinity','_blacklistedProperty','_Symbol','name','osName','Buffer','emulator','perf_hooks','[object\\x20Array]','stackTraceLimit','Promise','_WebSocketClass','cappedElements','_isNegativeZero','global','catch','_dateToString','noFunctions','_reconnectTimeout','_connectToHostNow','test','_setNodeId','string','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_addLoadNode','_sendErrorMessage','location','_consoleNinjaAllowedToStart','4OBrhKf','props','_hasSymbolPropertyOnItsPath','level','_isPrimitiveType','_isArray','dockerizedApp','includes','_setNodeExpressionPath','react-native','concat','coverage','HTMLAllCollection','1','_attemptToReconnectShortly','message','split','timeStamp','_console_ninja_session','number','disabledTrace','_property','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_propertyName','_addObjectProperty','depth','String','_addFunctionsNode','data','_keyStrRegExp','getOwnPropertySymbols','autoExpandMaxDepth','ninjaSuppressConsole','_undefined','WebSocket','elapsed'];_0x5eb7=function(){return _0x5312cb;};return _0x5eb7();}var _0x548f0e=_0x49dd;(function(_0x3b8ea0,_0xb09101){var _0x276847=_0x49dd,_0x13198e=_0x3b8ea0();while(!![]){try{var _0xeebb23=-parseInt(_0x276847(0x130))/0x1*(parseInt(_0x276847(0x132))/0x2)+-parseInt(_0x276847(0x15c))/0x3+parseInt(_0x276847(0x20a))/0x4*(-parseInt(_0x276847(0x1a0))/0x5)+-parseInt(_0x276847(0x14e))/0x6+parseInt(_0x276847(0x145))/0x7+parseInt(_0x276847(0x128))/0x8*(-parseInt(_0x276847(0x13f))/0x9)+-parseInt(_0x276847(0x1cf))/0xa*(-parseInt(_0x276847(0x1c7))/0xb);if(_0xeebb23===_0xb09101)break;else _0x13198e['push'](_0x13198e['shift']());}catch(_0x3b433b){_0x13198e['push'](_0x13198e['shift']());}}}(_0x5eb7,0x68711));function z(_0x313b23,_0x229f6c,_0x11a6ff,_0x3283bf,_0x5f230b,_0x10232d){var _0xa85961=_0x49dd,_0x48df31,_0x291315,_0x559566,_0x37b425;this[_0xa85961(0x1fc)]=_0x313b23,this[_0xa85961(0x17c)]=_0x229f6c,this['port']=_0x11a6ff,this[_0xa85961(0x142)]=_0x3283bf,this[_0xa85961(0x10a)]=_0x5f230b,this[_0xa85961(0x1d7)]=_0x10232d,this['_allowedToSend']=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0xa85961(0x12f)]=!0x1,this[_0xa85961(0x135)]=!0x1,this[_0xa85961(0x1bd)]=((_0x291315=(_0x48df31=_0x313b23[_0xa85961(0x1c8)])==null?void 0x0:_0x48df31[_0xa85961(0x1e1)])==null?void 0x0:_0x291315[_0xa85961(0x1bb)])===_0xa85961(0x157),this[_0xa85961(0x1cd)]=!((_0x37b425=(_0x559566=this[_0xa85961(0x1fc)][_0xa85961(0x1c8)])==null?void 0x0:_0x559566[_0xa85961(0x1b4)])!=null&&_0x37b425['node'])&&!this[_0xa85961(0x1bd)],this[_0xa85961(0x1f9)]=null,this[_0xa85961(0x158)]=0x0,this['_maxConnectAttemptCount']=0x14,this['_webSocketErrorDocsLink']='https://tinyurl.com/37x8b79t',this['_sendErrorMessage']=(this[_0xa85961(0x1cd)]?'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20':_0xa85961(0x1ce))+this['_webSocketErrorDocsLink'];}z[_0x548f0e(0x188)][_0x548f0e(0x1c9)]=async function(){var _0x16d2fc=_0x548f0e,_0x31fecd,_0x1f5c70;if(this[_0x16d2fc(0x1f9)])return this[_0x16d2fc(0x1f9)];let _0xfb36cd;if(this[_0x16d2fc(0x1cd)]||this['_inNextEdge'])_0xfb36cd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x126)];else{if((_0x31fecd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])!=null&&_0x31fecd[_0x16d2fc(0x1e0)])_0xfb36cd=(_0x1f5c70=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])==null?void 0x0:_0x1f5c70[_0x16d2fc(0x1e0)];else try{_0xfb36cd=(await new Function(_0x16d2fc(0x1aa),_0x16d2fc(0x1eb),'nodeModules',_0x16d2fc(0x170))(await(0x0,eval)(_0x16d2fc(0x18e)),await(0x0,eval)('import(\\x27url\\x27)'),this[_0x16d2fc(0x142)]))[_0x16d2fc(0x1ba)];}catch{try{_0xfb36cd=require(require(_0x16d2fc(0x1aa))['join'](this[_0x16d2fc(0x142)],'ws'));}catch{throw new Error(_0x16d2fc(0x205));}}}return this[_0x16d2fc(0x1f9)]=_0xfb36cd,_0xfb36cd;},z[_0x548f0e(0x188)]['_connectToHostNow']=function(){var _0x3932b3=_0x548f0e;this[_0x3932b3(0x135)]||this[_0x3932b3(0x12f)]||this[_0x3932b3(0x158)]>=this[_0x3932b3(0x1d4)]||(this[_0x3932b3(0x1a6)]=!0x1,this[_0x3932b3(0x135)]=!0x0,this['_connectAttemptCount']++,this['_ws']=new Promise((_0x239dde,_0x309d9a)=>{var _0x4a4aeb=_0x3932b3;this[_0x4a4aeb(0x1c9)]()[_0x4a4aeb(0x137)](_0x23579d=>{var _0x29a84d=_0x4a4aeb;let _0x4019f0=new _0x23579d('ws://'+(!this[_0x29a84d(0x1cd)]&&this['dockerizedApp']?_0x29a84d(0x1a9):this['host'])+':'+this[_0x29a84d(0x178)]);_0x4019f0[_0x29a84d(0x160)]=()=>{var _0x4d456f=_0x29a84d;this['_allowedToSend']=!0x1,this[_0x4d456f(0x1d9)](_0x4019f0),this['_attemptToReconnectShortly'](),_0x309d9a(new Error(_0x4d456f(0x15b)));},_0x4019f0['onopen']=()=>{var _0x338227=_0x29a84d;this[_0x338227(0x1cd)]||_0x4019f0[_0x338227(0x174)]&&_0x4019f0[_0x338227(0x174)]['unref']&&_0x4019f0[_0x338227(0x174)][_0x338227(0x1c4)](),_0x239dde(_0x4019f0);},_0x4019f0[_0x29a84d(0x1c2)]=()=>{var _0x494a4c=_0x29a84d;this[_0x494a4c(0x1a6)]=!0x0,this[_0x494a4c(0x1d9)](_0x4019f0),this[_0x494a4c(0x112)]();},_0x4019f0[_0x29a84d(0x180)]=_0x3160ad=>{var _0x2bd4b5=_0x29a84d;try{if(!(_0x3160ad!=null&&_0x3160ad[_0x2bd4b5(0x120)])||!this[_0x2bd4b5(0x1d7)])return;let _0xbd6af=JSON['parse'](_0x3160ad[_0x2bd4b5(0x120)]);this['eventReceivedCallback'](_0xbd6af['method'],_0xbd6af[_0x2bd4b5(0x1be)],this['global'],this[_0x2bd4b5(0x1cd)]);}catch{}};})[_0x4a4aeb(0x137)](_0x1e115d=>(this[_0x4a4aeb(0x12f)]=!0x0,this[_0x4a4aeb(0x135)]=!0x1,this[_0x4a4aeb(0x1a6)]=!0x1,this[_0x4a4aeb(0x18a)]=!0x0,this['_connectAttemptCount']=0x0,_0x1e115d))[_0x4a4aeb(0x1fd)](_0x307016=>(this[_0x4a4aeb(0x12f)]=!0x1,this[_0x4a4aeb(0x135)]=!0x1,console[_0x4a4aeb(0x141)](_0x4a4aeb(0x148)+this[_0x4a4aeb(0x153)]),_0x309d9a(new Error(_0x4a4aeb(0x1c6)+(_0x307016&&_0x307016[_0x4a4aeb(0x113)])))));}));},z['prototype'][_0x548f0e(0x1d9)]=function(_0x583632){var _0x13adc4=_0x548f0e;this[_0x13adc4(0x12f)]=!0x1,this['_connecting']=!0x1;try{_0x583632[_0x13adc4(0x1c2)]=null,_0x583632[_0x13adc4(0x160)]=null,_0x583632[_0x13adc4(0x189)]=null;}catch{}try{_0x583632[_0x13adc4(0x19c)]<0x2&&_0x583632[_0x13adc4(0x1b6)]();}catch{}},z[_0x548f0e(0x188)][_0x548f0e(0x112)]=function(){var _0x5036a5=_0x548f0e;clearTimeout(this[_0x5036a5(0x200)]),!(this[_0x5036a5(0x158)]>=this[_0x5036a5(0x1d4)])&&(this[_0x5036a5(0x200)]=setTimeout(()=>{var _0x3cf797=_0x5036a5,_0x15c27f;this[_0x3cf797(0x12f)]||this[_0x3cf797(0x135)]||(this[_0x3cf797(0x201)](),(_0x15c27f=this['_ws'])==null||_0x15c27f[_0x3cf797(0x1fd)](()=>this[_0x3cf797(0x112)]()));},0x1f4),this['_reconnectTimeout']['unref']&&this[_0x5036a5(0x200)][_0x5036a5(0x1c4)]());},z[_0x548f0e(0x188)][_0x548f0e(0x1c1)]=async function(_0x3246fb){var _0x3a41c5=_0x548f0e;try{if(!this[_0x3a41c5(0x18a)])return;this[_0x3a41c5(0x1a6)]&&this[_0x3a41c5(0x201)](),(await this[_0x3a41c5(0x159)])[_0x3a41c5(0x1c1)](JSON['stringify'](_0x3246fb));}catch(_0x2c0162){this[_0x3a41c5(0x1e5)]?console['warn'](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162[_0x3a41c5(0x113)])):(this[_0x3a41c5(0x1e5)]=!0x0,console[_0x3a41c5(0x141)](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162['message']),_0x3246fb)),this[_0x3a41c5(0x18a)]=!0x1,this[_0x3a41c5(0x112)]();}};function H(_0x708fe1,_0x3ad9bb,_0x1f357c,_0x5c3d72,_0x57da2a,_0x8bfd1c,_0x547194,_0x427ae0=ne){var _0x35b9cb=_0x548f0e;let _0x1a1b39=_0x1f357c[_0x35b9cb(0x114)](',')['map'](_0x1779fe=>{var _0x75e4e5=_0x35b9cb,_0x1c1066,_0x27d331,_0x28e1f6,_0xbdba49,_0x48a083,_0x3e9b5c,_0x282392,_0x1fe787;try{if(!_0x708fe1[_0x75e4e5(0x116)]){let _0x786a32=((_0x27d331=(_0x1c1066=_0x708fe1[_0x75e4e5(0x1c8)])==null?void 0x0:_0x1c1066[_0x75e4e5(0x1b4)])==null?void 0x0:_0x27d331[_0x75e4e5(0x143)])||((_0xbdba49=(_0x28e1f6=_0x708fe1['process'])==null?void 0x0:_0x28e1f6[_0x75e4e5(0x1e1)])==null?void 0x0:_0xbdba49[_0x75e4e5(0x1bb)])===_0x75e4e5(0x157);(_0x57da2a===_0x75e4e5(0x1b1)||_0x57da2a==='remix'||_0x57da2a==='astro'||_0x57da2a==='angular')&&(_0x57da2a+=_0x786a32?_0x75e4e5(0x15a):_0x75e4e5(0x1dd));let _0x4af9b3='';_0x57da2a===_0x75e4e5(0x10d)&&(_0x4af9b3=(((_0x282392=(_0x3e9b5c=(_0x48a083=_0x708fe1[_0x75e4e5(0x1d3)])==null?void 0x0:_0x48a083[_0x75e4e5(0x1db)])==null?void 0x0:_0x3e9b5c['ExpoDevice'])==null?void 0x0:_0x282392[_0x75e4e5(0x1f2)])||_0x75e4e5(0x1f4))[_0x75e4e5(0x1a8)](),_0x4af9b3&&(_0x57da2a+='\\x20'+_0x4af9b3,(_0x4af9b3==='android'||_0x4af9b3==='emulator'&&((_0x1fe787=_0x708fe1[_0x75e4e5(0x208)])==null?void 0x0:_0x1fe787[_0x75e4e5(0x14b)])==='10.0.2.2')&&(_0x3ad9bb='10.0.2.2'))),_0x708fe1[_0x75e4e5(0x116)]={'id':+new Date(),'tool':_0x57da2a},_0x547194&&_0x57da2a&&!_0x786a32&&(_0x4af9b3?console[_0x75e4e5(0x177)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x4af9b3+',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'):console[_0x75e4e5(0x177)](_0x75e4e5(0x197)+(_0x57da2a[_0x75e4e5(0x1d5)](0x0)[_0x75e4e5(0x12b)]()+_0x57da2a['substr'](0x1))+',',_0x75e4e5(0x155),_0x75e4e5(0x11a)));}let _0x229d61=new z(_0x708fe1,_0x3ad9bb,_0x1779fe,_0x5c3d72,_0x8bfd1c,_0x427ae0);return _0x229d61[_0x75e4e5(0x1c1)][_0x75e4e5(0x190)](_0x229d61);}catch(_0x207f65){return console[_0x75e4e5(0x141)](_0x75e4e5(0x184),_0x207f65&&_0x207f65[_0x75e4e5(0x113)]),()=>{};}});return _0x3ca2fe=>_0x1a1b39['forEach'](_0x570669=>_0x570669(_0x3ca2fe));}function ne(_0xfba01b,_0x5795ac,_0x526e6d,_0x23f0bc){var _0x88e87e=_0x548f0e;_0x23f0bc&&_0xfba01b===_0x88e87e(0x166)&&_0x526e6d[_0x88e87e(0x208)][_0x88e87e(0x166)]();}function b(_0x1c035d){var _0x33fbbc=_0x548f0e,_0x38efc3,_0xd2aec9;let _0x2a75b9=function(_0x448dbf,_0x3bc12f){return _0x3bc12f-_0x448dbf;},_0x22bb27;if(_0x1c035d[_0x33fbbc(0x186)])_0x22bb27=function(){var _0x5310e0=_0x33fbbc;return _0x1c035d[_0x5310e0(0x186)][_0x5310e0(0x14a)]();};else{if(_0x1c035d[_0x33fbbc(0x1c8)]&&_0x1c035d['process'][_0x33fbbc(0x162)]&&((_0xd2aec9=(_0x38efc3=_0x1c035d['process'])==null?void 0x0:_0x38efc3[_0x33fbbc(0x1e1)])==null?void 0x0:_0xd2aec9[_0x33fbbc(0x1bb)])!==_0x33fbbc(0x157))_0x22bb27=function(){var _0x4e9093=_0x33fbbc;return _0x1c035d['process'][_0x4e9093(0x162)]();},_0x2a75b9=function(_0x3c76d8,_0x527272){return 0x3e8*(_0x527272[0x0]-_0x3c76d8[0x0])+(_0x527272[0x1]-_0x3c76d8[0x1])/0xf4240;};else try{let {performance:_0x3d6831}=require(_0x33fbbc(0x1f5));_0x22bb27=function(){return _0x3d6831['now']();};}catch{_0x22bb27=function(){return+new Date();};}}return{'elapsed':_0x2a75b9,'timeStamp':_0x22bb27,'now':()=>Date['now']()};}function X(_0x3759c2,_0x327f60,_0x4ef84f){var _0x3c31ac=_0x548f0e,_0xa92efe,_0x3de67f,_0x8ece1a,_0x16959d,_0x5c93bf,_0x3ba4cf,_0x41f351;if(_0x3759c2[_0x3c31ac(0x209)]!==void 0x0)return _0x3759c2[_0x3c31ac(0x209)];let _0x5474b8=((_0x3de67f=(_0xa92efe=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0xa92efe[_0x3c31ac(0x1b4)])==null?void 0x0:_0x3de67f[_0x3c31ac(0x143)])||((_0x16959d=(_0x8ece1a=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0x8ece1a['env'])==null?void 0x0:_0x16959d[_0x3c31ac(0x1bb)])===_0x3c31ac(0x157),_0x2e5086=!!(_0x4ef84f===_0x3c31ac(0x10d)&&((_0x5c93bf=_0x3759c2[_0x3c31ac(0x1d3)])==null?void 0x0:_0x5c93bf['modules']));function _0x165bf6(_0x327d5a){var _0x2198ff=_0x3c31ac;if(_0x327d5a[_0x2198ff(0x12a)]('/')&&_0x327d5a[_0x2198ff(0x1e3)]('/')){let _0x4ee469=new RegExp(_0x327d5a[_0x2198ff(0x18f)](0x1,-0x1));return _0x1a743c=>_0x4ee469[_0x2198ff(0x202)](_0x1a743c);}else{if(_0x327d5a[_0x2198ff(0x10b)]('*')||_0x327d5a[_0x2198ff(0x10b)]('?')){let _0x3c6f9e=new RegExp('^'+_0x327d5a[_0x2198ff(0x161)](/\\./g,String[_0x2198ff(0x1ae)](0x5c)+'.')['replace'](/\\*/g,'.*')[_0x2198ff(0x161)](/\\?/g,'.')+String[_0x2198ff(0x1ae)](0x24));return _0x1ed757=>_0x3c6f9e[_0x2198ff(0x202)](_0x1ed757);}else return _0x934f30=>_0x934f30===_0x327d5a;}}let _0x276fbc=_0x327f60[_0x3c31ac(0x1b8)](_0x165bf6);return _0x3759c2['_consoleNinjaAllowedToStart']=_0x5474b8||!_0x327f60,!_0x3759c2['_consoleNinjaAllowedToStart']&&((_0x3ba4cf=_0x3759c2[_0x3c31ac(0x208)])==null?void 0x0:_0x3ba4cf[_0x3c31ac(0x14b)])&&(_0x3759c2['_consoleNinjaAllowedToStart']=_0x276fbc['some'](_0x593d63=>_0x593d63(_0x3759c2[_0x3c31ac(0x208)][_0x3c31ac(0x14b)]))),_0x2e5086&&!_0x3759c2[_0x3c31ac(0x209)]&&!((_0x41f351=_0x3759c2[_0x3c31ac(0x208)])!=null&&_0x41f351[_0x3c31ac(0x14b)])&&(_0x3759c2[_0x3c31ac(0x209)]=!0x0),_0x3759c2[_0x3c31ac(0x209)];}function J(_0x2011df,_0x5af1c4,_0x1caee6,_0x2bde9f,_0x3f83e7,_0x1e8675){var _0x19fb99=_0x548f0e;_0x2011df=_0x2011df,_0x5af1c4=_0x5af1c4,_0x1caee6=_0x1caee6,_0x2bde9f=_0x2bde9f,_0x3f83e7=_0x3f83e7,_0x3f83e7=_0x3f83e7||{},_0x3f83e7[_0x19fb99(0x12d)]=_0x3f83e7[_0x19fb99(0x12d)]||{},_0x3f83e7[_0x19fb99(0x17d)]=_0x3f83e7[_0x19fb99(0x17d)]||{},_0x3f83e7[_0x19fb99(0x1cc)]=_0x3f83e7['reducePolicy']||{},_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]=_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]||{},_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]=_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]||{};let _0x10a276={'perLogpoint':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x151)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7['reducePolicy']['perLogpoint'][_0x19fb99(0x1e2)]||0x64,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)]['perLogpoint'][_0x19fb99(0x13c)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x1ec)]||0x64},'global':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x151)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x1e2)]||0x12c,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x13c)]||0x32,'resetOnProcessingTimeAverageMs':_0x3f83e7['reducePolicy'][_0x19fb99(0x1fc)]['resetOnProcessingTimeAverageMs']||0x64}},_0x3528bb=b(_0x2011df),_0x5e742b=_0x3528bb[_0x19fb99(0x127)],_0x1e8773=_0x3528bb[_0x19fb99(0x115)];function _0x3b798c(){var _0xf88f94=_0x19fb99;this[_0xf88f94(0x121)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this['_numberRegExp']=/^(0|[1-9][0-9]*)$/,this[_0xf88f94(0x1b7)]=/'([^\\\\']|\\\\')*'/,this[_0xf88f94(0x125)]=_0x2011df[_0xf88f94(0x171)],this[_0xf88f94(0x163)]=_0x2011df[_0xf88f94(0x110)],this[_0xf88f94(0x1b3)]=Object['getOwnPropertyDescriptor'],this[_0xf88f94(0x18b)]=Object['getOwnPropertyNames'],this[_0xf88f94(0x1f0)]=_0x2011df[_0xf88f94(0x138)],this['_regExpToString']=RegExp[_0xf88f94(0x188)]['toString'],this[_0xf88f94(0x1fe)]=Date[_0xf88f94(0x188)][_0xf88f94(0x1d0)];}_0x3b798c[_0x19fb99(0x188)]['serialize']=function(_0x216611,_0x5eff3c,_0x98d4f7,_0x591bd8){var _0x17b51c=_0x19fb99,_0x5097e6=this,_0x4ddf1a=_0x98d4f7['autoExpand'];function _0x2cf396(_0xa9d4ec,_0x4b33f3,_0x5bb97d){var _0x3f82bf=_0x49dd;_0x4b33f3[_0x3f82bf(0x13e)]=_0x3f82bf(0x15f),_0x4b33f3[_0x3f82bf(0x1c5)]=_0xa9d4ec[_0x3f82bf(0x113)],_0x158ad2=_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)],_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)]=_0x4b33f3,_0x5097e6[_0x3f82bf(0x18c)](_0x4b33f3,_0x5bb97d);}let _0x4268a1,_0x4a8d20,_0xfbbae=_0x2011df[_0x17b51c(0x124)];_0x2011df[_0x17b51c(0x124)]=!0x0,_0x2011df[_0x17b51c(0x165)]&&(_0x4268a1=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)],_0x4a8d20=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)],_0x4268a1&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)]=function(){}),_0x4a8d20&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)]=function(){}));try{try{_0x98d4f7[_0x17b51c(0x107)]++,_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7['autoExpandPreviousObjects'][_0x17b51c(0x1c3)](_0x5eff3c);var _0xaaa11d,_0x5c63f2,_0x231fa2,_0x3f03a6,_0x44c1a5=[],_0x7e4f4a=[],_0x348545,_0x4cc2e9=this[_0x17b51c(0x172)](_0x5eff3c),_0x133a1d=_0x4cc2e9==='array',_0x3478d3=!0x1,_0x459df2=_0x4cc2e9==='function',_0x454d51=this[_0x17b51c(0x108)](_0x4cc2e9),_0x563084=this['_isPrimitiveWrapperType'](_0x4cc2e9),_0x320d3c=_0x454d51||_0x563084,_0x5529b5={},_0x542ce0=0x0,_0x423abb=!0x1,_0x158ad2,_0x13010c=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x98d4f7[_0x17b51c(0x11d)]){if(_0x133a1d){if(_0x5c63f2=_0x5eff3c['length'],_0x5c63f2>_0x98d4f7[_0x17b51c(0x1d6)]){for(_0x231fa2=0x0,_0x3f03a6=_0x98d4f7['elements'],_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));_0x216611[_0x17b51c(0x1fa)]=!0x0;}else{for(_0x231fa2=0x0,_0x3f03a6=_0x5c63f2,_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));}_0x98d4f7[_0x17b51c(0x1ca)]+=_0x7e4f4a[_0x17b51c(0x12e)];}if(!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9===_0x17b51c(0x171))&&!_0x454d51&&_0x4cc2e9!==_0x17b51c(0x11e)&&_0x4cc2e9!==_0x17b51c(0x1f3)&&_0x4cc2e9!==_0x17b51c(0x134)){var _0x13bdc7=_0x591bd8[_0x17b51c(0x20b)]||_0x98d4f7[_0x17b51c(0x20b)];if(this['_isSet'](_0x5eff3c)?(_0xaaa11d=0x0,_0x5eff3c['forEach'](function(_0x4e268b){var _0x1aa76f=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x1aa76f(0x1a5)]&&_0x98d4f7[_0x1aa76f(0x1a1)]&&_0x98d4f7[_0x1aa76f(0x1ca)]>_0x98d4f7[_0x1aa76f(0x152)]){_0x423abb=!0x0;return;}_0x7e4f4a[_0x1aa76f(0x1c3)](_0x5097e6['_addProperty'](_0x44c1a5,_0x5eff3c,_0x1aa76f(0x1b9),_0xaaa11d++,_0x98d4f7,function(_0x56afe8){return function(){return _0x56afe8;};}(_0x4e268b)));})):this[_0x17b51c(0x13d)](_0x5eff3c)&&_0x5eff3c[_0x17b51c(0x1d8)](function(_0x4b4368,_0x4a5cce){var _0x3f9993=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x3f9993(0x1a5)]&&_0x98d4f7[_0x3f9993(0x1a1)]&&_0x98d4f7['autoExpandPropertyCount']>_0x98d4f7[_0x3f9993(0x152)]){_0x423abb=!0x0;return;}var _0xab791b=_0x4a5cce['toString']();_0xab791b[_0x3f9993(0x12e)]>0x64&&(_0xab791b=_0xab791b['slice'](0x0,0x64)+_0x3f9993(0x1ea)),_0x7e4f4a[_0x3f9993(0x1c3)](_0x5097e6[_0x3f9993(0x1b2)](_0x44c1a5,_0x5eff3c,_0x3f9993(0x139),_0xab791b,_0x98d4f7,function(_0x2460ca){return function(){return _0x2460ca;};}(_0x4b4368)));}),!_0x3478d3){try{for(_0x348545 in _0x5eff3c)if(!(_0x133a1d&&_0x13010c['test'](_0x348545))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7[_0x17b51c(0x1a5)]&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}catch{}if(_0x5529b5['_p_length']=!0x0,_0x459df2&&(_0x5529b5[_0x17b51c(0x17b)]=!0x0),!_0x423abb){var _0x516950=[][_0x17b51c(0x10e)](this[_0x17b51c(0x18b)](_0x5eff3c))['concat'](this[_0x17b51c(0x19e)](_0x5eff3c));for(_0xaaa11d=0x0,_0x5c63f2=_0x516950[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)if(_0x348545=_0x516950[_0xaaa11d],!(_0x133a1d&&_0x13010c[_0x17b51c(0x202)](_0x348545['toString']()))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)&&!_0x5529b5[typeof _0x348545!=_0x17b51c(0x1b5)?_0x17b51c(0x173)+_0x348545['toString']():_0x348545]){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7['isExpressionToEvaluate']&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}}}}if(_0x216611['type']=_0x4cc2e9,_0x320d3c?(_0x216611[_0x17b51c(0x181)]=_0x5eff3c[_0x17b51c(0x1a4)](),this[_0x17b51c(0x16e)](_0x4cc2e9,_0x216611,_0x98d4f7,_0x591bd8)):_0x4cc2e9==='date'?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1fe)][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x134)?_0x216611['value']=_0x5eff3c[_0x17b51c(0x1d0)]():_0x4cc2e9==='RegExp'?_0x216611[_0x17b51c(0x181)]=this['_regExpToString'][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x1b5)&&this[_0x17b51c(0x1f0)]?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1f0)][_0x17b51c(0x188)][_0x17b51c(0x1d0)][_0x17b51c(0x198)](_0x5eff3c):!_0x98d4f7[_0x17b51c(0x11d)]&&!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9==='undefined')&&(delete _0x216611['value'],_0x216611[_0x17b51c(0x17a)]=!0x0),_0x423abb&&(_0x216611['cappedProps']=!0x0),_0x158ad2=_0x98d4f7[_0x17b51c(0x143)]['current'],_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x216611,this[_0x17b51c(0x18c)](_0x216611,_0x98d4f7),_0x7e4f4a[_0x17b51c(0x12e)]){for(_0xaaa11d=0x0,_0x5c63f2=_0x7e4f4a[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)_0x7e4f4a[_0xaaa11d](_0xaaa11d);}_0x44c1a5[_0x17b51c(0x12e)]&&(_0x216611['props']=_0x44c1a5);}catch(_0x584964){_0x2cf396(_0x584964,_0x216611,_0x98d4f7);}this['_additionalMetadata'](_0x5eff3c,_0x216611),this[_0x17b51c(0x191)](_0x216611,_0x98d4f7),_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x158ad2,_0x98d4f7['level']--,_0x98d4f7[_0x17b51c(0x1a1)]=_0x4ddf1a,_0x98d4f7['autoExpand']&&_0x98d4f7[_0x17b51c(0x187)][_0x17b51c(0x195)]();}finally{_0x4268a1&&(_0x2011df[_0x17b51c(0x165)]['error']=_0x4268a1),_0x4a8d20&&(_0x2011df['console'][_0x17b51c(0x141)]=_0x4a8d20),_0x2011df[_0x17b51c(0x124)]=_0xfbbae;}return _0x216611;},_0x3b798c[_0x19fb99(0x188)]['_getOwnPropertySymbols']=function(_0x4c28a7){var _0xd2148d=_0x19fb99;return Object[_0xd2148d(0x122)]?Object[_0xd2148d(0x122)](_0x4c28a7):[];},_0x3b798c['prototype'][_0x19fb99(0x19f)]=function(_0x27432c){var _0x117f9a=_0x19fb99;return!!(_0x27432c&&_0x2011df['Set']&&this[_0x117f9a(0x1da)](_0x27432c)===_0x117f9a(0x17f)&&_0x27432c[_0x117f9a(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ef)]=function(_0x327172,_0x1bf02d,_0x68c506){var _0x42d895=_0x19fb99;if(!_0x68c506[_0x42d895(0x183)]){let _0x31f3c6=this[_0x42d895(0x1b3)](_0x327172,_0x1bf02d);if(_0x31f3c6&&_0x31f3c6[_0x42d895(0x136)])return!0x0;}return _0x68c506[_0x42d895(0x1ff)]?typeof _0x327172[_0x1bf02d]==_0x42d895(0x1df):!0x1;},_0x3b798c['prototype'][_0x19fb99(0x172)]=function(_0x4b4ff7){var _0x89a987=_0x19fb99,_0x2df42a='';return _0x2df42a=typeof _0x4b4ff7,_0x2df42a===_0x89a987(0x140)?this[_0x89a987(0x1da)](_0x4b4ff7)==='[object\\x20Array]'?_0x2df42a=_0x89a987(0x1d2):this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x193)?_0x2df42a='date':this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x19d)?_0x2df42a='bigint':_0x4b4ff7===null?_0x2df42a=_0x89a987(0x199):_0x4b4ff7[_0x89a987(0x192)]&&(_0x2df42a=_0x4b4ff7[_0x89a987(0x192)][_0x89a987(0x1f1)]||_0x2df42a):_0x2df42a==='undefined'&&this[_0x89a987(0x163)]&&_0x4b4ff7 instanceof this['_HTMLAllCollection']&&(_0x2df42a='HTMLAllCollection'),_0x2df42a;},_0x3b798c[_0x19fb99(0x188)]['_objectToString']=function(_0x4ea4a3){var _0xe65ac2=_0x19fb99;return Object[_0xe65ac2(0x188)][_0xe65ac2(0x1d0)]['call'](_0x4ea4a3);},_0x3b798c['prototype'][_0x19fb99(0x108)]=function(_0x486186){var _0x59de18=_0x19fb99;return _0x486186==='boolean'||_0x486186===_0x59de18(0x204)||_0x486186==='number';},_0x3b798c[_0x19fb99(0x188)]['_isPrimitiveWrapperType']=function(_0x57b53f){var _0x3d404c=_0x19fb99;return _0x57b53f===_0x3d404c(0x1de)||_0x57b53f==='String'||_0x57b53f===_0x3d404c(0x1bc);},_0x3b798c['prototype'][_0x19fb99(0x1b2)]=function(_0x51d7e9,_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116){var _0x327fee=this;return function(_0x5f212a){var _0x45776a=_0x49dd,_0x480d1e=_0x10ecad[_0x45776a(0x143)][_0x45776a(0x19a)],_0x2270b6=_0x10ecad['node']['index'],_0x3242a9=_0x10ecad['node']['parent'];_0x10ecad[_0x45776a(0x143)][_0x45776a(0x168)]=_0x480d1e,_0x10ecad[_0x45776a(0x143)][_0x45776a(0x13a)]=typeof _0x32ddbe=='number'?_0x32ddbe:_0x5f212a,_0x51d7e9[_0x45776a(0x1c3)](_0x327fee[_0x45776a(0x119)](_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116)),_0x10ecad['node'][_0x45776a(0x168)]=_0x3242a9,_0x10ecad['node'][_0x45776a(0x13a)]=_0x2270b6;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11c)]=function(_0x4fff24,_0xf060cd,_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d){var _0x11f0a7=_0x19fb99,_0x261b2c=this;return _0xf060cd[typeof _0x46c20e!=_0x11f0a7(0x1b5)?_0x11f0a7(0x173)+_0x46c20e[_0x11f0a7(0x1d0)]():_0x46c20e]=!0x0,function(_0x3a475e){var _0x2f5d31=_0x11f0a7,_0x2b9d6c=_0x2e08a7[_0x2f5d31(0x143)]['current'],_0x4b248b=_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)],_0xbed829=_0x2e08a7['node']['parent'];_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0x2b9d6c,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x3a475e,_0x4fff24[_0x2f5d31(0x1c3)](_0x261b2c[_0x2f5d31(0x119)](_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d)),_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0xbed829,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x4b248b;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x119)]=function(_0x1bf49f,_0x10ac96,_0x57dfa6,_0xee7322,_0x598c3f){var _0x326486=_0x19fb99,_0x57fd55=this;_0x598c3f||(_0x598c3f=function(_0x46b469,_0x55c36d){return _0x46b469[_0x55c36d];});var _0x4331ba=_0x57dfa6[_0x326486(0x1d0)](),_0x58db2f=_0xee7322[_0x326486(0x14d)]||{},_0x56fbc0=_0xee7322[_0x326486(0x11d)],_0x28a895=_0xee7322['isExpressionToEvaluate'];try{var _0x4d3354=this[_0x326486(0x13d)](_0x1bf49f),_0x4f8709=_0x4331ba;_0x4d3354&&_0x4f8709[0x0]==='\\x27'&&(_0x4f8709=_0x4f8709[_0x326486(0x185)](0x1,_0x4f8709[_0x326486(0x12e)]-0x2));var _0x15481e=_0xee7322[_0x326486(0x14d)]=_0x58db2f[_0x326486(0x173)+_0x4f8709];_0x15481e&&(_0xee7322[_0x326486(0x11d)]=_0xee7322[_0x326486(0x11d)]+0x1),_0xee7322[_0x326486(0x1a5)]=!!_0x15481e;var _0x3a61d9=typeof _0x57dfa6==_0x326486(0x1b5),_0x1e1792={'name':_0x3a61d9||_0x4d3354?_0x4331ba:this[_0x326486(0x11b)](_0x4331ba)};if(_0x3a61d9&&(_0x1e1792['symbol']=!0x0),!(_0x10ac96==='array'||_0x10ac96===_0x326486(0x1e4))){var _0x4503a0=this[_0x326486(0x1b3)](_0x1bf49f,_0x57dfa6);if(_0x4503a0&&(_0x4503a0['set']&&(_0x1e1792[_0x326486(0x16b)]=!0x0),_0x4503a0[_0x326486(0x136)]&&!_0x15481e&&!_0xee7322[_0x326486(0x183)]))return _0x1e1792[_0x326486(0x1ed)]=!0x0,this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x32a36e;try{_0x32a36e=_0x598c3f(_0x1bf49f,_0x57dfa6);}catch(_0x44aaa6){return _0x1e1792={'name':_0x4331ba,'type':_0x326486(0x15f),'error':_0x44aaa6['message']},this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x27eaec=this[_0x326486(0x172)](_0x32a36e),_0x1dd8cf=this['_isPrimitiveType'](_0x27eaec);if(_0x1e1792[_0x326486(0x13e)]=_0x27eaec,_0x1dd8cf)this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x14aecf=_0x326486;_0x1e1792['value']=_0x32a36e[_0x14aecf(0x1a4)](),!_0x15481e&&_0x57fd55['_capIfString'](_0x27eaec,_0x1e1792,_0xee7322,{});});else{var _0x1fd626=_0xee7322[_0x326486(0x1a1)]&&_0xee7322[_0x326486(0x107)]<_0xee7322[_0x326486(0x123)]&&_0xee7322[_0x326486(0x187)][_0x326486(0x18d)](_0x32a36e)<0x0&&_0x27eaec!==_0x326486(0x1df)&&_0xee7322['autoExpandPropertyCount']<_0xee7322[_0x326486(0x152)];_0x1fd626||_0xee7322[_0x326486(0x107)]<_0x56fbc0||_0x15481e?this[_0x326486(0x19b)](_0x1e1792,_0x32a36e,_0xee7322,_0x15481e||{}):this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x187576=_0x326486;_0x27eaec==='null'||_0x27eaec==='undefined'||(delete _0x1e1792[_0x187576(0x181)],_0x1e1792[_0x187576(0x17a)]=!0x0);});}return _0x1e1792;}finally{_0xee7322[_0x326486(0x14d)]=_0x58db2f,_0xee7322[_0x326486(0x11d)]=_0x56fbc0,_0xee7322[_0x326486(0x1a5)]=_0x28a895;}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x16e)]=function(_0x56e4d4,_0x9663b4,_0x4ca9b4,_0x4f8a61){var _0x289244=_0x19fb99,_0x543170=_0x4f8a61['strLength']||_0x4ca9b4['strLength'];if((_0x56e4d4===_0x289244(0x204)||_0x56e4d4===_0x289244(0x11e))&&_0x9663b4[_0x289244(0x181)]){let _0x2b9781=_0x9663b4[_0x289244(0x181)][_0x289244(0x12e)];_0x4ca9b4[_0x289244(0x169)]+=_0x2b9781,_0x4ca9b4[_0x289244(0x169)]>_0x4ca9b4[_0x289244(0x14f)]?(_0x9663b4[_0x289244(0x17a)]='',delete _0x9663b4[_0x289244(0x181)]):_0x2b9781>_0x543170&&(_0x9663b4[_0x289244(0x17a)]=_0x9663b4[_0x289244(0x181)]['substr'](0x0,_0x543170),delete _0x9663b4[_0x289244(0x181)]);}},_0x3b798c['prototype'][_0x19fb99(0x13d)]=function(_0x20e242){var _0x22bc15=_0x19fb99;return!!(_0x20e242&&_0x2011df[_0x22bc15(0x139)]&&this[_0x22bc15(0x1da)](_0x20e242)==='[object\\x20Map]'&&_0x20e242[_0x22bc15(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11b)]=function(_0x51405e){var _0x339753=_0x19fb99;if(_0x51405e[_0x339753(0x1e6)](/^\\d+$/))return _0x51405e;var _0xa32815;try{_0xa32815=JSON['stringify'](''+_0x51405e);}catch{_0xa32815='\\x22'+this[_0x339753(0x1da)](_0x51405e)+'\\x22';}return _0xa32815[_0x339753(0x1e6)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0xa32815=_0xa32815[_0x339753(0x185)](0x1,_0xa32815['length']-0x2):_0xa32815=_0xa32815[_0x339753(0x161)](/'/g,'\\x5c\\x27')[_0x339753(0x161)](/\\\\\"/g,'\\x22')[_0x339753(0x161)](/(^\"|\"$)/g,'\\x27'),_0xa32815;},_0x3b798c[_0x19fb99(0x188)]['_processTreeNodeResult']=function(_0x19aa6c,_0x15bfd6,_0x57de46,_0x17e0d5){var _0x5136d0=_0x19fb99;this['_treeNodePropertiesBeforeFullValue'](_0x19aa6c,_0x15bfd6),_0x17e0d5&&_0x17e0d5(),this[_0x5136d0(0x1ad)](_0x57de46,_0x19aa6c),this[_0x5136d0(0x191)](_0x19aa6c,_0x15bfd6);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x18c)]=function(_0x3d1ee7,_0x70e5ea){var _0x548bce=_0x19fb99;this['_setNodeId'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x175)](_0x3d1ee7,_0x70e5ea),this['_setNodeExpressionPath'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x1e9)](_0x3d1ee7,_0x70e5ea);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x203)]=function(_0x39276,_0x2973e9){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x175)]=function(_0x3d5358,_0x1ce0bc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x149)]=function(_0x5460c7,_0x5726fc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1e7)]=function(_0xb18247){var _0x5a9038=_0x19fb99;return _0xb18247===this[_0x5a9038(0x125)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x191)]=function(_0xb3362f,_0x257171){var _0x24e002=_0x19fb99;this[_0x24e002(0x149)](_0xb3362f,_0x257171),this[_0x24e002(0x196)](_0xb3362f),_0x257171[_0x24e002(0x147)]&&this[_0x24e002(0x1bf)](_0xb3362f),this[_0x24e002(0x11f)](_0xb3362f,_0x257171),this['_addLoadNode'](_0xb3362f,_0x257171),this[_0x24e002(0x182)](_0xb3362f);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ad)]=function(_0x2dbd2f,_0x37c5b1){var _0x320ee5=_0x19fb99;try{_0x2dbd2f&&typeof _0x2dbd2f[_0x320ee5(0x12e)]==_0x320ee5(0x117)&&(_0x37c5b1[_0x320ee5(0x12e)]=_0x2dbd2f[_0x320ee5(0x12e)]);}catch{}if(_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x117)||_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1bc)){if(isNaN(_0x37c5b1['value']))_0x37c5b1['nan']=!0x0,delete _0x37c5b1['value'];else switch(_0x37c5b1[_0x320ee5(0x181)]){case Number[_0x320ee5(0x14c)]:_0x37c5b1[_0x320ee5(0x1e8)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case Number[_0x320ee5(0x12c)]:_0x37c5b1[_0x320ee5(0x1ee)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case 0x0:this[_0x320ee5(0x1fb)](_0x37c5b1['value'])&&(_0x37c5b1[_0x320ee5(0x129)]=!0x0);break;}}else _0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1df)&&typeof _0x2dbd2f[_0x320ee5(0x1f1)]==_0x320ee5(0x204)&&_0x2dbd2f[_0x320ee5(0x1f1)]&&_0x37c5b1['name']&&_0x2dbd2f['name']!==_0x37c5b1['name']&&(_0x37c5b1[_0x320ee5(0x13b)]=_0x2dbd2f[_0x320ee5(0x1f1)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1fb)]=function(_0x3fe3ce){var _0x5bd9dd=_0x19fb99;return 0x1/_0x3fe3ce===Number[_0x5bd9dd(0x12c)];},_0x3b798c[_0x19fb99(0x188)]['_sortProps']=function(_0x302641){var _0x20eea1=_0x19fb99;!_0x302641[_0x20eea1(0x20b)]||!_0x302641[_0x20eea1(0x20b)][_0x20eea1(0x12e)]||_0x302641[_0x20eea1(0x13e)]===_0x20eea1(0x1d2)||_0x302641['type']===_0x20eea1(0x139)||_0x302641['type']===_0x20eea1(0x1b9)||_0x302641['props'][_0x20eea1(0x16c)](function(_0x2e3c0f,_0x466671){var _0x2def12=_0x20eea1,_0x299cd3=_0x2e3c0f[_0x2def12(0x1f1)][_0x2def12(0x1a8)](),_0x569a8c=_0x466671[_0x2def12(0x1f1)]['toLowerCase']();return _0x299cd3<_0x569a8c?-0x1:_0x299cd3>_0x569a8c?0x1:0x0;});},_0x3b798c['prototype'][_0x19fb99(0x11f)]=function(_0x1fce5c,_0x59600b){var _0x272775=_0x19fb99;if(!(_0x59600b[_0x272775(0x1ff)]||!_0x1fce5c['props']||!_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)])){for(var _0x5b060d=[],_0x576482=[],_0x469b84=0x0,_0x1419a1=_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)];_0x469b84<_0x1419a1;_0x469b84++){var _0x554dbc=_0x1fce5c[_0x272775(0x20b)][_0x469b84];_0x554dbc['type']===_0x272775(0x1df)?_0x5b060d[_0x272775(0x1c3)](_0x554dbc):_0x576482['push'](_0x554dbc);}if(!(!_0x576482['length']||_0x5b060d[_0x272775(0x12e)]<=0x1)){_0x1fce5c[_0x272775(0x20b)]=_0x576482;var _0x5ac4d9={'functionsNode':!0x0,'props':_0x5b060d};this['_setNodeId'](_0x5ac4d9,_0x59600b),this['_setNodeLabel'](_0x5ac4d9,_0x59600b),this['_setNodeExpandableState'](_0x5ac4d9),this['_setNodePermissions'](_0x5ac4d9,_0x59600b),_0x5ac4d9['id']+='\\x20f',_0x1fce5c[_0x272775(0x20b)][_0x272775(0x15e)](_0x5ac4d9);}}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x206)]=function(_0x53bb34,_0x23ecf2){},_0x3b798c['prototype'][_0x19fb99(0x196)]=function(_0x59c87d){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x109)]=function(_0x480385){var _0x3b79b1=_0x19fb99;return Array['isArray'](_0x480385)||typeof _0x480385=='object'&&this[_0x3b79b1(0x1da)](_0x480385)===_0x3b79b1(0x1f6);},_0x3b798c['prototype'][_0x19fb99(0x1e9)]=function(_0x3277e3,_0x15bc20){},_0x3b798c[_0x19fb99(0x188)]['_cleanNode']=function(_0x3d12db){var _0x1bb90c=_0x19fb99;delete _0x3d12db[_0x1bb90c(0x106)],delete _0x3d12db[_0x1bb90c(0x179)],delete _0x3d12db[_0x1bb90c(0x146)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x10c)]=function(_0x804785,_0x46b090){};let _0x1ab812=new _0x3b798c(),_0x4253f5={'props':_0x3f83e7[_0x19fb99(0x12d)]['props']||0x64,'elements':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x1d6)]||0x64,'strLength':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x16a)]||0x400*0x32,'totalStrLength':_0x3f83e7['defaultLimits'][_0x19fb99(0x14f)]||0x400*0x32,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x152)]||0x1388,'autoExpandMaxDepth':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x123)]||0xa},_0x5ccf32={'props':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x20b)]||0x5,'elements':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x1d6)]||0x5,'strLength':_0x3f83e7['reducedLimits'][_0x19fb99(0x16a)]||0x100,'totalStrLength':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x14f)]||0x100*0x3,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x152)]||0x1e,'autoExpandMaxDepth':_0x3f83e7['reducedLimits']['autoExpandMaxDepth']||0x2};if(_0x1e8675){let _0x2f3a37=_0x1ab812['serialize']['bind'](_0x1ab812);_0x1ab812[_0x19fb99(0x19b)]=function(_0x4f58de,_0x29d7d0,_0x30b459,_0x1f5fdf){return _0x2f3a37(_0x4f58de,_0x1e8675(_0x29d7d0),_0x30b459,_0x1f5fdf);};}function _0xc68888(_0x535031,_0x3340fc,_0x337e66,_0x22242c,_0x124bfa,_0x5f1e1f){var _0x46fc5e=_0x19fb99;let _0x56fb0c,_0x26a7c9;try{_0x26a7c9=_0x1e8773(),_0x56fb0c=_0x1caee6[_0x3340fc],!_0x56fb0c||_0x26a7c9-_0x56fb0c['ts']>_0x10a276['perLogpoint'][_0x46fc5e(0x13c)]&&_0x56fb0c[_0x46fc5e(0x1a2)]&&_0x56fb0c[_0x46fc5e(0x1a7)]/_0x56fb0c[_0x46fc5e(0x1a2)]<_0x10a276[_0x46fc5e(0x194)]['resetOnProcessingTimeAverageMs']?(_0x1caee6[_0x3340fc]=_0x56fb0c={'count':0x0,'time':0x0,'ts':_0x26a7c9},_0x1caee6['hits']={}):_0x26a7c9-_0x1caee6[_0x46fc5e(0x1ab)]['ts']>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x13c)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a7)]/_0x1caee6[_0x46fc5e(0x1ab)]['count']<_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x1ec)]&&(_0x1caee6[_0x46fc5e(0x1ab)]={});let _0x135eed=[],_0x4de057=_0x56fb0c[_0x46fc5e(0x15d)]||_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]?_0x5ccf32:_0x4253f5,_0x5ea472=_0x57de65=>{var _0x1e64a0=_0x46fc5e;let _0x2f1ff9={};return _0x2f1ff9[_0x1e64a0(0x20b)]=_0x57de65[_0x1e64a0(0x20b)],_0x2f1ff9[_0x1e64a0(0x1d6)]=_0x57de65['elements'],_0x2f1ff9[_0x1e64a0(0x16a)]=_0x57de65[_0x1e64a0(0x16a)],_0x2f1ff9['totalStrLength']=_0x57de65[_0x1e64a0(0x14f)],_0x2f1ff9[_0x1e64a0(0x152)]=_0x57de65[_0x1e64a0(0x152)],_0x2f1ff9['autoExpandMaxDepth']=_0x57de65[_0x1e64a0(0x123)],_0x2f1ff9[_0x1e64a0(0x147)]=!0x1,_0x2f1ff9['noFunctions']=!_0x5af1c4,_0x2f1ff9[_0x1e64a0(0x11d)]=0x1,_0x2f1ff9['level']=0x0,_0x2f1ff9[_0x1e64a0(0x164)]=_0x1e64a0(0x167),_0x2f1ff9[_0x1e64a0(0x1d1)]=_0x1e64a0(0x16f),_0x2f1ff9[_0x1e64a0(0x1a1)]=!0x0,_0x2f1ff9[_0x1e64a0(0x187)]=[],_0x2f1ff9[_0x1e64a0(0x1ca)]=0x0,_0x2f1ff9['resolveGetters']=_0x3f83e7['resolveGetters'],_0x2f1ff9[_0x1e64a0(0x169)]=0x0,_0x2f1ff9[_0x1e64a0(0x143)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x2f1ff9;};for(var _0x19c1cf=0x0;_0x19c1cf<_0x124bfa[_0x46fc5e(0x12e)];_0x19c1cf++)_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'timeNode':_0x535031==='time'||void 0x0},_0x124bfa[_0x19c1cf],_0x5ea472(_0x4de057),{}));if(_0x535031==='trace'||_0x535031===_0x46fc5e(0x1c5)){let _0x11d4f0=Error[_0x46fc5e(0x1f7)];try{Error[_0x46fc5e(0x1f7)]=0x1/0x0,_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'stackNode':!0x0},new Error()[_0x46fc5e(0x1af)],_0x5ea472(_0x4de057),{'strLength':0x1/0x0}));}finally{Error[_0x46fc5e(0x1f7)]=_0x11d4f0;}}return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':_0x135eed,'id':_0x3340fc,'context':_0x5f1e1f}]};}catch(_0x29c306){return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':[{'type':_0x46fc5e(0x15f),'error':_0x29c306&&_0x29c306[_0x46fc5e(0x113)]}],'id':_0x3340fc,'context':_0x5f1e1f}]};}finally{try{if(_0x56fb0c&&_0x26a7c9){let _0x52a27e=_0x1e8773();_0x56fb0c[_0x46fc5e(0x1a2)]++,_0x56fb0c[_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x56fb0c['ts']=_0x52a27e,_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]++,_0x1caee6['hits'][_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x1caee6[_0x46fc5e(0x1ab)]['ts']=_0x52a27e,(_0x56fb0c[_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x194)][_0x46fc5e(0x151)]||_0x56fb0c['time']>_0x10a276['perLogpoint']['reduceOnAccumulatedProcessingTimeMs'])&&(_0x56fb0c[_0x46fc5e(0x15d)]=!0x0),(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x151)]||_0x1caee6[_0x46fc5e(0x1ab)]['time']>_0x10a276['global'][_0x46fc5e(0x1e2)])&&(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]=!0x0);}}catch{}}}return _0xc68888;}function G(_0x357a3e){var _0x1c1d5c=_0x548f0e;if(_0x357a3e&&typeof _0x357a3e==_0x1c1d5c(0x140)&&_0x357a3e[_0x1c1d5c(0x192)])switch(_0x357a3e['constructor'][_0x1c1d5c(0x1f1)]){case _0x1c1d5c(0x1f8):return _0x357a3e['hasOwnProperty'](Symbol[_0x1c1d5c(0x1cb)])?Promise[_0x1c1d5c(0x1ac)]():_0x357a3e;case'bound\\x20Promise':return Promise[_0x1c1d5c(0x1ac)]();}return _0x357a3e;}function _0x49dd(_0x48794b,_0x215201){var _0x5eb787=_0x5eb7();return _0x49dd=function(_0x49dd64,_0x5b9134){_0x49dd64=_0x49dd64-0x106;var _0x4735f0=_0x5eb787[_0x49dd64];return _0x4735f0;},_0x49dd(_0x48794b,_0x215201);}((_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x5bf3d1,_0xfe754b,_0x5a9d76,_0x1aab36,_0x3bc27c,_0x57f4e7,_0x4fa6c3)=>{var _0xf735ce=_0x548f0e;if(_0x4ab1c6['_console_ninja'])return _0x4ab1c6['_console_ninja'];let _0x313a8d={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x4ab1c6,_0x5a9d76,_0x478f2c))return _0x4ab1c6[_0xf735ce(0x16d)]=_0x313a8d,_0x4ab1c6['_console_ninja'];let _0x418c01=b(_0x4ab1c6),_0xd76728=_0x418c01[_0xf735ce(0x127)],_0x3e56d8=_0x418c01[_0xf735ce(0x115)],_0x3e2373=_0x418c01[_0xf735ce(0x14a)],_0x48f2ad={'hits':{},'ts':{}},_0x505066=J(_0x4ab1c6,_0x1aab36,_0x48f2ad,_0x5bf3d1,_0x4fa6c3,_0x478f2c==='next.js'?G:void 0x0),_0x48cb15=(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9)=>{var _0x27df57=_0xf735ce;let _0x1159ce=_0x4ab1c6['_console_ninja'];try{return _0x4ab1c6['_console_ninja']=_0x313a8d,_0x505066(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9);}finally{_0x4ab1c6[_0x27df57(0x16d)]=_0x1159ce;}},_0xcc7412=_0xab4b0c=>{_0x48f2ad['ts'][_0xab4b0c]=_0x3e56d8();},_0x3aeb93=(_0xbe2a9d,_0x37862a)=>{var _0x30e3cb=_0xf735ce;let _0x37627d=_0x48f2ad['ts'][_0x37862a];if(delete _0x48f2ad['ts'][_0x37862a],_0x37627d){let _0x464639=_0xd76728(_0x37627d,_0x3e56d8());_0x45f648(_0x48cb15(_0x30e3cb(0x1a7),_0xbe2a9d,_0x3e2373(),_0x5efb7d,[_0x464639],_0x37862a));}},_0x5b170d=_0x4b3a1c=>{var _0x5a439b=_0xf735ce,_0x1bd0d3;return _0x478f2c===_0x5a439b(0x1b1)&&_0x4ab1c6['origin']&&((_0x1bd0d3=_0x4b3a1c==null?void 0x0:_0x4b3a1c['args'])==null?void 0x0:_0x1bd0d3[_0x5a439b(0x12e)])&&(_0x4b3a1c['args'][0x0]['origin']=_0x4ab1c6[_0x5a439b(0x133)]),_0x4b3a1c;};_0x4ab1c6[_0xf735ce(0x16d)]={'consoleLog':(_0x1f92a3,_0x3d1b32)=>{var _0x384ddc=_0xf735ce;_0x4ab1c6[_0x384ddc(0x165)][_0x384ddc(0x177)][_0x384ddc(0x1f1)]!=='disabledLog'&&_0x45f648(_0x48cb15(_0x384ddc(0x177),_0x1f92a3,_0x3e2373(),_0x5efb7d,_0x3d1b32));},'consoleTrace':(_0x16d5a,_0x223858)=>{var _0x616644=_0xf735ce,_0xdf7629,_0x7ea927;_0x4ab1c6[_0x616644(0x165)]['log'][_0x616644(0x1f1)]!==_0x616644(0x118)&&((_0x7ea927=(_0xdf7629=_0x4ab1c6[_0x616644(0x1c8)])==null?void 0x0:_0xdf7629['versions'])!=null&&_0x7ea927[_0x616644(0x143)]&&(_0x4ab1c6[_0x616644(0x1c0)]=!0x0),_0x45f648(_0x5b170d(_0x48cb15(_0x616644(0x1a3),_0x16d5a,_0x3e2373(),_0x5efb7d,_0x223858))));},'consoleError':(_0x38f47b,_0x35429f)=>{_0x4ab1c6['_ninjaIgnoreNextError']=!0x0,_0x45f648(_0x5b170d(_0x48cb15('error',_0x38f47b,_0x3e2373(),_0x5efb7d,_0x35429f)));},'consoleTime':_0x4cf735=>{_0xcc7412(_0x4cf735);},'consoleTimeEnd':(_0x566c48,_0x364eea)=>{_0x3aeb93(_0x364eea,_0x566c48);},'autoLog':(_0x1eb1b1,_0xa812f2)=>{var _0x1ace51=_0xf735ce;_0x45f648(_0x48cb15(_0x1ace51(0x177),_0xa812f2,_0x3e2373(),_0x5efb7d,[_0x1eb1b1]));},'autoLogMany':(_0x56ca86,_0x4bac87)=>{var _0x3394a4=_0xf735ce;_0x45f648(_0x48cb15(_0x3394a4(0x177),_0x56ca86,_0x3e2373(),_0x5efb7d,_0x4bac87));},'autoTrace':(_0x417845,_0x145484)=>{var _0x27ae88=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x27ae88(0x1a3),_0x145484,_0x3e2373(),_0x5efb7d,[_0x417845])));},'autoTraceMany':(_0xca37d7,_0x262246)=>{var _0x26f92c=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x26f92c(0x1a3),_0xca37d7,_0x3e2373(),_0x5efb7d,_0x262246)));},'autoTime':(_0x32789a,_0x59deba,_0xcc1c2c)=>{_0xcc7412(_0xcc1c2c);},'autoTimeEnd':(_0x58bdab,_0x21cfd7,_0x507017)=>{_0x3aeb93(_0x21cfd7,_0x507017);},'coverage':_0x237fb5=>{var _0x4ec628=_0xf735ce;_0x45f648({'method':_0x4ec628(0x10f),'version':_0x5bf3d1,'args':[{'id':_0x237fb5}]});}};let _0x45f648=H(_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x3bc27c,_0x57f4e7),_0x5efb7d=_0x4ab1c6[_0xf735ce(0x116)];return _0x4ab1c6['_console_ninja'];})(globalThis,_0x548f0e(0x17e),_0x548f0e(0x154),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.501\\\\node_modules\",_0x548f0e(0x131),_0x548f0e(0x1dc),_0x548f0e(0x144),_0x548f0e(0x1b0),_0x548f0e(0x150),_0x548f0e(0x176),_0x548f0e(0x111),{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}});");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
}),
"[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ComponentContext",
    ()=>ComponentContext,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useProjectShowContext",
    ()=>useProjectShowContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/BreadCrumb.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ExcelSheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/ExcelSheet.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/SubHeader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/index.tsx [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/withPermission.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/ProjectForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutcomeForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutputForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/DessaggregationForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/utils/OptionLists.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprLogsSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/IndicatorForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/Isp3SubPage.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ShowProjectPage = ()=>{
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    const { reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        id: null,
        projectCode: "",
        projectTitle: "",
        projectGoal: "",
        projectDonor: "",
        startDate: "",
        endDate: "",
        status: "active",
        projectManager: "",
        provinces: [],
        thematicSector: [],
        reportingPeriod: "",
        reportingDate: "",
        aprStatus: "NotCreatedYet",
        description: ""
    });
    const [outcomes, setOutcomes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [outputs, setOutputs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [indicators, setIndicators] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [dessaggregations, setDessaggregations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isp3, setIsp3] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isp3s"].map((i)=>({
            name: i,
            indicators: []
        })));
    const [projectId, setProjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [projectProvinces, setProjectProvinces] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        "kabul"
    ]);
    const [projectGoal, setProjectGoal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentTab, setCurrentTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("project");
    const [actionLogs, setActionLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [logs, setLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [projectAprStatus, setProjectAprStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("notCreatedYet");
    // Fetch data
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get(`/projects/${id}`).then((response)=>{
            const { outcomesInfo, ...project } = response.data.data;
            project["provinces"] = project.provinces.map((province)=>province.name);
            setFormData(project);
            setProjectGoal(project.projectGoal);
            setProjectProvinces(project["provinces"]);
            setOutcomes(outcomesInfo.map((outcome)=>{
                const { outputs, ...outcomeInfo } = outcome;
                return outcomeInfo;
            }));
            setOutputs(outcomesInfo.flatMap((outcome)=>{
                const outputs = outcome.outputs.flatMap((output)=>{
                    const { indicators, ...outputInfo } = output;
                    outputInfo["outcomeId"] = outcome.id;
                    outputInfo["outcomeRef"] = outcome.outcomeRef;
                    return outputInfo;
                });
                return outputs;
            }));
            setIndicators(outcomesInfo.flatMap((outcome)=>{
                const indicators = outcome.outputs.flatMap((output)=>output.indicators.flatMap((indicator)=>{
                        const { dessaggregations, ...indicatorInfo } = indicator;
                        indicatorInfo["outputId"] = output.id;
                        indicatorInfo["outputRef"] = output.outputRef;
                        return indicatorInfo;
                    }));
                return indicators;
            }));
            setDessaggregations(outcomesInfo.flatMap((outcome)=>{
                const dessaggregations = outcome.outputs.flatMap((output)=>output.indicators.flatMap((indicator)=>indicator.dessaggregations.flatMap((dessaggregation)=>{
                            dessaggregation["indicatorId"] = dessaggregation.indicator_id;
                            return dessaggregation;
                        })));
                return dessaggregations;
            }));
            setProjectAprStatus(project.aprStatus);
            setProjectId(project.id);
            outcomesInfo.flatMap((outcome)=>{
                const isp3s = outcome.outputs.flatMap((output)=>output.indicators.flatMap((indicator)=>indicator.isp3.flatMap((isp)=>{
                            setIsp3((prev)=>prev.map((i)=>i.name == isp.description ? {
                                        ...i,
                                        indicators: [
                                            ...i.indicators,
                                            isp.pivot.indicator_id
                                        ]
                                    } : i));
                        })));
                return isp3s;
            });
        }).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    }, []);
    const handleDelete = (url, id)=>{
        if (!id) return;
        axiosInstance.delete(url + `/${id}`).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ComponentContext.Provider, {
            value: {
                formData,
                setFormData,
                outcomes,
                setOutcomes,
                outputs,
                setOutputs,
                indicators,
                setIndicators,
                dessaggregations,
                setDessaggregations,
                projectId,
                setProjectId,
                projectGoal,
                setProjectGoal,
                projectProvinces,
                setProjectProvinces,
                currentTab,
                setCurrentTab,
                logs,
                setLogs,
                projectAprStatus,
                setProjectAprStatus,
                isp3,
                setIsp3,
                actionLogs,
                setActionLogs,
                handleDelete
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-full p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Navbar14"], {}, void 0, false, {
                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                        lineNumber: 221,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row items-center justify-start my-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                            lineNumber: 223,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                        lineNumber: 222,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        pageTitle: "Create New Project"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                        lineNumber: 225,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 h-[440px] w-full flex-col gap-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Tabs"], {
                            defaultValue: "project",
                            onValueChange: (value)=>setCurrentTab(value),
                            value: currentTab,
                            className: "h-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsList"], {
                                    className: "w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "project",
                                            children: "Project"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 235,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "outcome",
                                            children: "OutCome"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 236,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "output",
                                            children: "Output"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 237,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "indicator",
                                            children: "Indicator"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 238,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "dessaggregation",
                                            children: "Disaggregation"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 239,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "aprPreview",
                                            children: "APR Preview"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 242,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "isp3",
                                            children: "ISP3"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 243,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "finalization",
                                            children: "APR Finalization"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 244,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "logs",
                                            children: "Logs"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                            lineNumber: 245,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 234,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "project",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 250,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 249,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "outcome",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 255,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 254,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "output",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 260,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 259,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "indicator",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 265,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 264,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "dessaggregation",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 270,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 269,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "aprPreview",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ExcelSheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 275,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 274,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "isp3",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 280,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 279,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "finalization",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 285,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 284,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "logs",
                                    className: "max-h-full overflow-y-hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                        lineNumber: 293,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                                    lineNumber: 289,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                            lineNumber: 227,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                        lineNumber: 226,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
                lineNumber: 220,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/(main)/projects/project_show/[id]/page.tsx",
            lineNumber: 189,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const ComponentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({});
const useProjectShowContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ComponentContext);
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["withPermission"])(ShowProjectPage, "Project.view");
}),
"[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ComponentContext",
    ()=>ComponentContext,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useProjectContext",
    ()=>useProjectContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/BreadCrumb.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ExcelSheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/ExcelSheet.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/SubHeader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/index.tsx [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/withPermission.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutcomeForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutputForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/DessaggregationForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/ProjectForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprLogsSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/IndicatorForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/Isp3SubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/FormsDefaultValues.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const NewProjectPage = ()=>{
    const { reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProjectDefault"])());
    const [outcomes, setOutcomes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [outputs, setOutputs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [indicators, setIndicators] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [dessaggregations, setDessaggregations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isp3, setIsp3] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Isp3Default"])());
    const [projectAprStatus, setProjectAprStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("notCreatedYet");
    const [actionLogs, setActionLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [projectId, setProjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [projectProvinces, setProjectProvinces] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        "kabul"
    ]);
    const [projectGoal, setProjectGoal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentTab, setCurrentTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("project");
    const handleDelete = (url, id)=>{
        if (!id) return;
        axiosInstance.delete(url + `/${id}`).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ComponentContext.Provider, {
            value: {
                outcomes,
                outputs,
                indicators,
                setOutcomes,
                setOutputs,
                setIndicators,
                setCurrentTab,
                projectProvinces,
                setProjectProvinces,
                projectId,
                setProjectId,
                projectGoal,
                setProjectGoal,
                dessaggregations,
                setDessaggregations,
                formData,
                setFormData,
                actionLogs,
                setActionLogs,
                projectAprStatus,
                setProjectAprStatus,
                isp3,
                setIsp3,
                handleDelete
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-full p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Navbar14"], {}, void 0, false, {
                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row items-center justify-start my-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        pageTitle: "Create New Project"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 h-[440px] w-full flex-col gap-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Tabs"], {
                            defaultValue: "project",
                            onValueChange: (value)=>setCurrentTab(value),
                            value: currentTab,
                            className: "h-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsList"], {
                                    className: "w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "project",
                                            children: "Project"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 109,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "outcome",
                                            children: "OutCome"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 110,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "output",
                                            children: "Output"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 111,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "indicator",
                                            children: "Indicator"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 112,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "dessaggregation",
                                            children: "Disaggregation"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 113,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "isp3",
                                            children: "ISP3"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 117,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "finalization",
                                            children: "APR Finalization"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 118,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "logs",
                                            children: "Logs"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                            lineNumber: 119,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "project",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 124,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 123,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "outcome",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 128,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "output",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 134,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 133,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "indicator",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 139,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 138,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "dessaggregation",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 144,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 143,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "aprPreview",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$ExcelSheet$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 149,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 148,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "isp3",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 154,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 153,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "finalization",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 159,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 158,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "logs",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "create"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                        lineNumber: 164,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                                    lineNumber: 163,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                            lineNumber: 102,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                        lineNumber: 101,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
                lineNumber: 95,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/(main)/projects/create_new_project/page.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const ComponentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({});
const useProjectContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ComponentContext);
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["withPermission"])(NewProjectPage, "Project.create");
}),
"[project]/app/(main)/projects/Components/ProjectForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/CardsBottomButtons.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/multi-select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/single-select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/FormsSchema.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/Constants.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ProjectForm = ({ mode })=>{
    const { reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { projectId, setProjectId, setCurrentTab, setProjectProvinces, formData, setFormData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    const [formErrors, setFormErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const hundleFormChange = (e)=>{
        const name = e.target.name;
        const value = e.target.value;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const hundleSubmit = ()=>{
        const result = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProjectFormSchema"].safeParse(formData);
        if (!result.success) {
            const errors = {};
            result.error.issues.forEach((issue)=>{
                const field = issue.path[0];
                if (field) errors[field] = issue.message;
            });
            setFormErrors(errors);
            reqForToastAndSetMessage("Please fix validation errors before submitting.");
            return;
        }
        setFormErrors({});
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode)) {
            axiosInstance.post("/projects", formData).then((response)=>{
                setProjectId(response.data.data.id);
                reqForToastAndSetMessage(response.data.message);
            }).catch((error)=>{
                reqForToastAndSetMessage(error.response.data.message);
            });
            return;
        }
        axiosInstance.post(`projects/${projectId}`, formData).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    const readOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$Constants$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IsShowMode"])(mode);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                        children: "Project Details"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                        lineNumber: 106,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "overflow-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "projectCode",
                                        children: "Project Code"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 112,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "projectCode",
                                        name: "projectCode",
                                        value: formData.projectCode,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.projectCode ? "!border-red-500" : ""}`,
                                        title: formErrors.projectCode,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 113,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "projectTitle",
                                        children: "Project Title"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 127,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                                        id: "projectTitle",
                                        name: "projectTitle",
                                        value: formData.projectTitle,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.projectTitle ? "!border-red-500" : ""}`,
                                        title: formErrors.projectTitle,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 128,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 126,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "projectGoal",
                                        children: "Project Goal"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 142,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                                        id: "projectGoal",
                                        name: "projectGoal",
                                        value: formData.projectGoal,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.projectGoal ? "!border-red-500" : ""}`,
                                        title: formErrors.projectGoal,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 143,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 141,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "projectDonor",
                                        children: "Donor"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 157,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "projectDonor",
                                        name: "projectDonor",
                                        value: formData.projectDonor,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.projectDonor ? "!border-red-500" : ""}`,
                                        title: formErrors.projectDonor,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 158,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 156,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "startDate",
                                        children: "Start Date"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 172,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "startDate",
                                        name: "startDate",
                                        type: "date",
                                        value: formData.startDate,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.startDate ? "!border-red-500" : ""}`,
                                        title: formErrors.startDate,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 173,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 171,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "endDate",
                                        children: "End Date"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 188,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "endDate",
                                        name: "endDate",
                                        type: "date",
                                        value: formData.endDate,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.endDate ? "!border-red-500" : ""}`,
                                        title: formErrors.endDate,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 189,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 187,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "status",
                                        children: "Status"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 204,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                        options: [
                                            {
                                                value: "planed",
                                                label: "Planed"
                                            },
                                            {
                                                value: "ongoing",
                                                label: "On Going"
                                            },
                                            {
                                                value: "completed",
                                                label: "Compleated"
                                            },
                                            {
                                                value: "onhold",
                                                label: "On Hold"
                                            },
                                            {
                                                value: "canclled",
                                                label: "Canclled"
                                            }
                                        ],
                                        value: formData.status,
                                        onValueChange: (value)=>{
                                            setFormData((prev)=>({
                                                    ...prev,
                                                    status: value
                                                }));
                                        },
                                        placeholder: "Project Status",
                                        error: formErrors.status,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 203,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "projectManeger",
                                        children: "Project Manager"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 227,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "projectManager",
                                        name: "projectManager",
                                        value: formData.projectManager,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.projectManager ? "!border-red-500" : ""}`,
                                        title: formErrors.projectManager,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 228,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 226,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "province",
                                        children: "Province"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 242,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MultiSelect"], {
                                        options: [
                                            {
                                                value: "kabul",
                                                label: "Kabul"
                                            },
                                            {
                                                value: "badakhshan",
                                                label: "Badakhshan"
                                            },
                                            {
                                                value: "ghor",
                                                label: "Ghor"
                                            },
                                            {
                                                value: "helmand",
                                                label: "Helmand"
                                            },
                                            {
                                                value: "daikundi",
                                                label: "Daikundi"
                                            }
                                        ],
                                        value: formData.provinces,
                                        onValueChange: (value)=>{
                                            setFormData((prev)=>({
                                                    ...prev,
                                                    provinces: value
                                                }));
                                            setProjectProvinces(value);
                                        },
                                        placeholder: "Project Provinces ...",
                                        error: formErrors.provinces,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 243,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 241,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "thematicSector",
                                        children: "Thematic Sector"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 266,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MultiSelect"], {
                                        options: [
                                            {
                                                value: "mhpss",
                                                label: "MHPSS"
                                            },
                                            {
                                                value: "wash",
                                                label: "WASH"
                                            },
                                            {
                                                value: "health",
                                                label: "Health"
                                            },
                                            {
                                                value: "nutrition",
                                                label: "Nutrition"
                                            }
                                        ],
                                        value: formData.thematicSector,
                                        onValueChange: (value)=>{
                                            setFormData((prev)=>({
                                                    ...prev,
                                                    thematicSector: value
                                                }));
                                        },
                                        placeholder: "Project Status",
                                        disabled: readOnly,
                                        error: formErrors.thematicSector
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 267,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 265,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "reportingPeriod",
                                        children: "Reporting Period"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 288,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                                        id: "reportingPeriod",
                                        name: "reportingPeriod",
                                        value: formData.reportingPeriod,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.reportingPeriod ? "!border-red-500" : ""}`,
                                        title: formErrors.reportingPeriod,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 289,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 287,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "reportingDate",
                                        children: "Reporting Date"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 303,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                        id: "reportingDate",
                                        name: "reportingDate",
                                        value: formData.reportingDate,
                                        onChange: hundleFormChange,
                                        type: "text",
                                        className: `border p-2 rounded ${formErrors.reportingDate ? "!border-red-500" : ""}`,
                                        title: formErrors.reportingDate,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 304,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 302,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-1 col-span-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "description",
                                        children: "Description"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 319,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                                        placeholder: "Type your message here.",
                                        id: "description",
                                        name: "description",
                                        value: formData.description,
                                        onChange: hundleFormChange,
                                        className: `border p-2 rounded ${formErrors.description ? "!border-red-500" : ""}`,
                                        title: formErrors.description,
                                        disabled: readOnly
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                        lineNumber: 320,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                                lineNumber: 318,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                    lineNumber: 109,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                    className: "flex justify-end gap-4",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$CardsBottomButtons$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cardsBottomButtons"])(setCurrentTab, "project", readOnly ? undefined : hundleSubmit, setCurrentTab, "outcome", "project", true)
                }, void 0, false, {
                    fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
                    lineNumber: 336,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/projects/Components/ProjectForm.tsx",
            lineNumber: 104,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = ProjectForm;
}),
"[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ComponentContext",
    ()=>ComponentContext,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useProjectEditContext",
    ()=>useProjectEditContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/BreadCrumb.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/SubHeader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/index.tsx [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/withPermission.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/ProjectForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutputForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/DessaggregationForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprFinalizationSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/OutcomeForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/AprLogsSubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/IndicatorForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/Components/Isp3SubPage.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/IndicatorEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/OutcomeEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/OutputEditModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/FormsDefaultValues.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const EditProjectPage = ()=>{
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    const { reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParentContext"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        id: null,
        projectCode: "",
        projectTitle: "",
        projectGoal: "",
        projectDonor: "",
        startDate: "",
        endDate: "",
        status: "active",
        projectManager: "",
        provinces: [],
        thematicSector: [],
        reportingPeriod: "",
        reportingDate: "",
        aprStatus: "NotCreatedYet",
        description: ""
    });
    const [outcomes, setOutcomes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [outputs, setOutputs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [indicators, setIndicators] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [dessaggregations, setDessaggregations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isp3, setIsp3] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Isp3Default"])());
    const [projectId, setProjectId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [projectProvinces, setProjectProvinces] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        "kabul"
    ]);
    const [projectGoal, setProjectGoal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentTab, setCurrentTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("project");
    const [actionLogs, setActionLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [logs, setLogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [projectAprStatus, setProjectAprStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("notCreatedYet");
    // Fech project data
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        axiosInstance.get(`/projects/${id}`).then((response)=>{
            /* eslint-disable */ console.log(...oo_oo(`802560895_90_8_90_39_4`, response.data.data));
            const { outcomesInfo, ...project } = response.data.data;
            project["provinces"] = project.provinces.map((province)=>province.name);
            setFormData(project);
            setProjectProvinces(project["provinces"]);
            setOutcomes(outcomesInfo.map((outcome)=>{
                const { outputs, ...outcomeInfo } = outcome;
                return outcomeInfo;
            }));
            setOutputs(outcomesInfo.flatMap((outcome)=>{
                const outputs = outcome.outputs.flatMap((output)=>{
                    const { indicators, ...outputInfo } = output;
                    outputInfo["outcomeId"] = outcome.id;
                    outputInfo["outcomeRef"] = outcome.outcomeRef;
                    return outputInfo;
                });
                return outputs;
            }));
            setIndicators(outcomesInfo.flatMap((outcome)=>{
                const indicators = outcome.outputs.flatMap((output)=>output.indicators.flatMap((indicator)=>{
                        const { dessaggregations, ...indicatorInfo } = indicator;
                        indicatorInfo["outputId"] = output.id;
                        indicatorInfo["outputRef"] = output.outputRef;
                        return indicatorInfo;
                    }));
                return indicators;
            }));
            setDessaggregations(outcomesInfo.flatMap((outcome)=>{
                const dessaggregations = outcome.outputs.flatMap((output)=>output.indicators.flatMap((indicator)=>indicator.dessaggregations.flatMap((dessaggregation)=>{
                            dessaggregation["indicatorId"] = dessaggregation.indicator_id;
                            return dessaggregation;
                        })));
                return dessaggregations;
            }));
            setProjectAprStatus(project.aprStatus);
            setProjectId(project.id);
            const newIsp3 = [
                ...isp3
            ];
            outcomesInfo.forEach((outcome)=>{
                outcome.outputs.forEach((output)=>{
                    output.indicators.forEach((indicator)=>{
                        indicator.isp3.forEach((isp)=>{
                            const index = newIsp3.findIndex((i)=>i.name === isp.description);
                            if (index !== -1) {
                                newIsp3[index] = {
                                    ...newIsp3[index],
                                    indicators: [
                                        ...newIsp3[index].indicators,
                                        isp.pivot.indicator_id
                                    ]
                                };
                            }
                        });
                    });
                });
            });
            setIsp3(newIsp3);
        }).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    }, []);
    const [reqForOutcomeForm, setReqForOutcomeForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForOutputForm, setReqForOutputForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reqForIndicatorForm, setReqForIndicatorForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleDelete = (url, id)=>{
        if (!id) return;
        axiosInstance.delete(url + `/${id}`).then((response)=>reqForToastAndSetMessage(response.data.message)).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ComponentContext.Provider, {
            value: {
                formData,
                setFormData,
                outcomes,
                setOutcomes,
                outputs,
                setOutputs,
                indicators,
                setIndicators,
                dessaggregations,
                setDessaggregations,
                projectId,
                setProjectId,
                projectGoal,
                setProjectGoal,
                projectProvinces,
                setProjectProvinces,
                currentTab,
                setCurrentTab,
                logs,
                setLogs,
                projectAprStatus,
                setProjectAprStatus,
                isp3,
                setIsp3,
                actionLogs,
                setActionLogs,
                handleDelete
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-full p-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Navbar14"], {}, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 228,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row items-center justify-start my-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$BreadCrumb$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                            lineNumber: 230,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 229,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$SubHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        pageTitle: "Edit Project"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 232,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 h-[440px] w-full flex-col gap-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Tabs"], {
                            defaultValue: "project",
                            onValueChange: (value)=>setCurrentTab(value),
                            value: currentTab,
                            className: "h-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsList"], {
                                    className: "w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "project",
                                            children: "Project"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 242,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "outcome",
                                            children: "OutCome"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 243,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "output",
                                            children: "Output"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 244,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "indicator",
                                            children: "Indicator"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 245,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "dessaggregation",
                                            children: "Disaggregation"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 246,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "isp3",
                                            children: "ISP3"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 250,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "finalization",
                                            children: "APR Finalization"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 251,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                            value: "logs",
                                            children: "Logs"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                            lineNumber: 252,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 241,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "project",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$ProjectForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 257,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 256,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "outcome",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutcomeForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 262,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 261,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "output",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$OutputForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 267,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 266,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "indicator",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$IndicatorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 272,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 271,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "dessaggregation",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$DessaggregationForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 277,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 276,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "isp3",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$Isp3SubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 282,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 281,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "finalization",
                                    className: "h-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprFinalizationSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 287,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 286,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                    value: "logs",
                                    className: "h-full overflow-hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$Components$2f$AprLogsSubPage$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        mode: "edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                        lineNumber: 292,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                                    lineNumber: 291,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                            lineNumber: 234,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 233,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    reqForIndicatorForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$IndicatorEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IndicatorModel"], {
                        isOpen: reqForIndicatorForm,
                        onClose: ()=>setReqForIndicatorForm(false),
                        mode: "create",
                        pageIdentifier: "edit"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 298,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    reqForOutcomeForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutcomeEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        isOpen: reqForOutcomeForm,
                        onOpenChange: setReqForOutcomeForm,
                        mode: "create",
                        pageIdentifier: "edit"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 307,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    reqForOutputForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$OutputEditModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        isOpen: reqForOutputForm,
                        onOpenChange: setReqForOutputForm,
                        mode: "create",
                        pageIdentifier: "edit"
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                        lineNumber: 316,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
                lineNumber: 227,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/(main)/projects/edit_project/[id]/page.tsx",
            lineNumber: 196,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const ComponentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({});
const useProjectEditContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ComponentContext);
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$withPermission$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["withPermission"])(EditProjectPage, "Project.edit");
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5eb7(){var _0x5312cb=['3256wREwNO','negativeZero','startsWith','toUpperCase','NEGATIVE_INFINITY','defaultLimits','length','_connected','5kjcSVz','next.js','213606VniQVN','origin','bigint','_connecting','get','then','Symbol','Map','index','funcName','resetWhenQuietMs','_isMap','type','2241WiVaRR','object','warn','nodeModules','node','1766156314250','1284920DYQWdu','_hasMapOnItsPath','sortProps','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','_setNodeLabel','now','hostname','POSITIVE_INFINITY','expressionsToEvaluate','4787388frDXrm','totalStrLength','','reduceOnCount','autoExpandLimit','_webSocketErrorDocsLink','3810','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','_processTreeNodeResult','edge','_connectAttemptCount','_ws','\\x20server','logger\\x20websocket\\x20error','1437783aYwZoA','reduceLimits','unshift','unknown','onerror','replace','hrtime','_HTMLAllCollection','expId','console','reload','root_exp_id','parent','allStrLength','strLength','setter','sort','_console_ninja','_capIfString','root_exp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','undefined','_type','_p_','_socket','_setNodeQueryPath','','log','port','_hasSetOnItsPath','capped','_p_name','host','reducedLimits','127.0.0.1','[object\\x20Set]','onmessage','value','_cleanNode','resolveGetters','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','substr','performance','autoExpandPreviousObjects','prototype','onopen','_allowedToSend','_getOwnPropertyNames','_treeNodePropertiesBeforeFullValue','indexOf','import(\\x27path\\x27)','slice','bind','_treeNodePropertiesAfterFullValue','constructor','[object\\x20Date]','perLogpoint','pop','_setNodeExpandableState','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','call','null','current','serialize','readyState','[object\\x20BigInt]','_getOwnPropertySymbols','_isSet','1078085AFsroT','autoExpand','count','trace','valueOf','isExpressionToEvaluate','_allowedToConnectOnSend','time','toLowerCase','gateway.docker.internal','path','hits','resolve','_additionalMetadata','fromCharCode','stack',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'next.js','_addProperty','_getOwnPropertyDescriptor','versions','symbol','close','_quotedRegExp','map','Set','default','NEXT_RUNTIME','Number','_inNextEdge','args','_sortProps','_ninjaIgnoreNextError','send','onclose','push','unref','error','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','33847uocYVR','process','getWebSocketClass','autoExpandPropertyCount','iterator','reducePolicy','_inBrowser','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','7710dhZant','toString','rootExpression','array','expo','_maxConnectAttemptCount','charAt','elements','eventReceivedCallback','forEach','_disposeWebsocket','_objectToString','modules','1.0.0','\\x20browser','Boolean','function','_WebSocket','env','reduceOnAccumulatedProcessingTimeMs','endsWith','Error','_extendedWarning','match','_isUndefined','positiveInfinity','_setNodePermissions','...','url','resetOnProcessingTimeAverageMs','getter','negativeInfinity','_blacklistedProperty','_Symbol','name','osName','Buffer','emulator','perf_hooks','[object\\x20Array]','stackTraceLimit','Promise','_WebSocketClass','cappedElements','_isNegativeZero','global','catch','_dateToString','noFunctions','_reconnectTimeout','_connectToHostNow','test','_setNodeId','string','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_addLoadNode','_sendErrorMessage','location','_consoleNinjaAllowedToStart','4OBrhKf','props','_hasSymbolPropertyOnItsPath','level','_isPrimitiveType','_isArray','dockerizedApp','includes','_setNodeExpressionPath','react-native','concat','coverage','HTMLAllCollection','1','_attemptToReconnectShortly','message','split','timeStamp','_console_ninja_session','number','disabledTrace','_property','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_propertyName','_addObjectProperty','depth','String','_addFunctionsNode','data','_keyStrRegExp','getOwnPropertySymbols','autoExpandMaxDepth','ninjaSuppressConsole','_undefined','WebSocket','elapsed'];_0x5eb7=function(){return _0x5312cb;};return _0x5eb7();}var _0x548f0e=_0x49dd;(function(_0x3b8ea0,_0xb09101){var _0x276847=_0x49dd,_0x13198e=_0x3b8ea0();while(!![]){try{var _0xeebb23=-parseInt(_0x276847(0x130))/0x1*(parseInt(_0x276847(0x132))/0x2)+-parseInt(_0x276847(0x15c))/0x3+parseInt(_0x276847(0x20a))/0x4*(-parseInt(_0x276847(0x1a0))/0x5)+-parseInt(_0x276847(0x14e))/0x6+parseInt(_0x276847(0x145))/0x7+parseInt(_0x276847(0x128))/0x8*(-parseInt(_0x276847(0x13f))/0x9)+-parseInt(_0x276847(0x1cf))/0xa*(-parseInt(_0x276847(0x1c7))/0xb);if(_0xeebb23===_0xb09101)break;else _0x13198e['push'](_0x13198e['shift']());}catch(_0x3b433b){_0x13198e['push'](_0x13198e['shift']());}}}(_0x5eb7,0x68711));function z(_0x313b23,_0x229f6c,_0x11a6ff,_0x3283bf,_0x5f230b,_0x10232d){var _0xa85961=_0x49dd,_0x48df31,_0x291315,_0x559566,_0x37b425;this[_0xa85961(0x1fc)]=_0x313b23,this[_0xa85961(0x17c)]=_0x229f6c,this['port']=_0x11a6ff,this[_0xa85961(0x142)]=_0x3283bf,this[_0xa85961(0x10a)]=_0x5f230b,this[_0xa85961(0x1d7)]=_0x10232d,this['_allowedToSend']=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0xa85961(0x12f)]=!0x1,this[_0xa85961(0x135)]=!0x1,this[_0xa85961(0x1bd)]=((_0x291315=(_0x48df31=_0x313b23[_0xa85961(0x1c8)])==null?void 0x0:_0x48df31[_0xa85961(0x1e1)])==null?void 0x0:_0x291315[_0xa85961(0x1bb)])===_0xa85961(0x157),this[_0xa85961(0x1cd)]=!((_0x37b425=(_0x559566=this[_0xa85961(0x1fc)][_0xa85961(0x1c8)])==null?void 0x0:_0x559566[_0xa85961(0x1b4)])!=null&&_0x37b425['node'])&&!this[_0xa85961(0x1bd)],this[_0xa85961(0x1f9)]=null,this[_0xa85961(0x158)]=0x0,this['_maxConnectAttemptCount']=0x14,this['_webSocketErrorDocsLink']='https://tinyurl.com/37x8b79t',this['_sendErrorMessage']=(this[_0xa85961(0x1cd)]?'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20':_0xa85961(0x1ce))+this['_webSocketErrorDocsLink'];}z[_0x548f0e(0x188)][_0x548f0e(0x1c9)]=async function(){var _0x16d2fc=_0x548f0e,_0x31fecd,_0x1f5c70;if(this[_0x16d2fc(0x1f9)])return this[_0x16d2fc(0x1f9)];let _0xfb36cd;if(this[_0x16d2fc(0x1cd)]||this['_inNextEdge'])_0xfb36cd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x126)];else{if((_0x31fecd=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])!=null&&_0x31fecd[_0x16d2fc(0x1e0)])_0xfb36cd=(_0x1f5c70=this[_0x16d2fc(0x1fc)][_0x16d2fc(0x1c8)])==null?void 0x0:_0x1f5c70[_0x16d2fc(0x1e0)];else try{_0xfb36cd=(await new Function(_0x16d2fc(0x1aa),_0x16d2fc(0x1eb),'nodeModules',_0x16d2fc(0x170))(await(0x0,eval)(_0x16d2fc(0x18e)),await(0x0,eval)('import(\\x27url\\x27)'),this[_0x16d2fc(0x142)]))[_0x16d2fc(0x1ba)];}catch{try{_0xfb36cd=require(require(_0x16d2fc(0x1aa))['join'](this[_0x16d2fc(0x142)],'ws'));}catch{throw new Error(_0x16d2fc(0x205));}}}return this[_0x16d2fc(0x1f9)]=_0xfb36cd,_0xfb36cd;},z[_0x548f0e(0x188)]['_connectToHostNow']=function(){var _0x3932b3=_0x548f0e;this[_0x3932b3(0x135)]||this[_0x3932b3(0x12f)]||this[_0x3932b3(0x158)]>=this[_0x3932b3(0x1d4)]||(this[_0x3932b3(0x1a6)]=!0x1,this[_0x3932b3(0x135)]=!0x0,this['_connectAttemptCount']++,this['_ws']=new Promise((_0x239dde,_0x309d9a)=>{var _0x4a4aeb=_0x3932b3;this[_0x4a4aeb(0x1c9)]()[_0x4a4aeb(0x137)](_0x23579d=>{var _0x29a84d=_0x4a4aeb;let _0x4019f0=new _0x23579d('ws://'+(!this[_0x29a84d(0x1cd)]&&this['dockerizedApp']?_0x29a84d(0x1a9):this['host'])+':'+this[_0x29a84d(0x178)]);_0x4019f0[_0x29a84d(0x160)]=()=>{var _0x4d456f=_0x29a84d;this['_allowedToSend']=!0x1,this[_0x4d456f(0x1d9)](_0x4019f0),this['_attemptToReconnectShortly'](),_0x309d9a(new Error(_0x4d456f(0x15b)));},_0x4019f0['onopen']=()=>{var _0x338227=_0x29a84d;this[_0x338227(0x1cd)]||_0x4019f0[_0x338227(0x174)]&&_0x4019f0[_0x338227(0x174)]['unref']&&_0x4019f0[_0x338227(0x174)][_0x338227(0x1c4)](),_0x239dde(_0x4019f0);},_0x4019f0[_0x29a84d(0x1c2)]=()=>{var _0x494a4c=_0x29a84d;this[_0x494a4c(0x1a6)]=!0x0,this[_0x494a4c(0x1d9)](_0x4019f0),this[_0x494a4c(0x112)]();},_0x4019f0[_0x29a84d(0x180)]=_0x3160ad=>{var _0x2bd4b5=_0x29a84d;try{if(!(_0x3160ad!=null&&_0x3160ad[_0x2bd4b5(0x120)])||!this[_0x2bd4b5(0x1d7)])return;let _0xbd6af=JSON['parse'](_0x3160ad[_0x2bd4b5(0x120)]);this['eventReceivedCallback'](_0xbd6af['method'],_0xbd6af[_0x2bd4b5(0x1be)],this['global'],this[_0x2bd4b5(0x1cd)]);}catch{}};})[_0x4a4aeb(0x137)](_0x1e115d=>(this[_0x4a4aeb(0x12f)]=!0x0,this[_0x4a4aeb(0x135)]=!0x1,this[_0x4a4aeb(0x1a6)]=!0x1,this[_0x4a4aeb(0x18a)]=!0x0,this['_connectAttemptCount']=0x0,_0x1e115d))[_0x4a4aeb(0x1fd)](_0x307016=>(this[_0x4a4aeb(0x12f)]=!0x1,this[_0x4a4aeb(0x135)]=!0x1,console[_0x4a4aeb(0x141)](_0x4a4aeb(0x148)+this[_0x4a4aeb(0x153)]),_0x309d9a(new Error(_0x4a4aeb(0x1c6)+(_0x307016&&_0x307016[_0x4a4aeb(0x113)])))));}));},z['prototype'][_0x548f0e(0x1d9)]=function(_0x583632){var _0x13adc4=_0x548f0e;this[_0x13adc4(0x12f)]=!0x1,this['_connecting']=!0x1;try{_0x583632[_0x13adc4(0x1c2)]=null,_0x583632[_0x13adc4(0x160)]=null,_0x583632[_0x13adc4(0x189)]=null;}catch{}try{_0x583632[_0x13adc4(0x19c)]<0x2&&_0x583632[_0x13adc4(0x1b6)]();}catch{}},z[_0x548f0e(0x188)][_0x548f0e(0x112)]=function(){var _0x5036a5=_0x548f0e;clearTimeout(this[_0x5036a5(0x200)]),!(this[_0x5036a5(0x158)]>=this[_0x5036a5(0x1d4)])&&(this[_0x5036a5(0x200)]=setTimeout(()=>{var _0x3cf797=_0x5036a5,_0x15c27f;this[_0x3cf797(0x12f)]||this[_0x3cf797(0x135)]||(this[_0x3cf797(0x201)](),(_0x15c27f=this['_ws'])==null||_0x15c27f[_0x3cf797(0x1fd)](()=>this[_0x3cf797(0x112)]()));},0x1f4),this['_reconnectTimeout']['unref']&&this[_0x5036a5(0x200)][_0x5036a5(0x1c4)]());},z[_0x548f0e(0x188)][_0x548f0e(0x1c1)]=async function(_0x3246fb){var _0x3a41c5=_0x548f0e;try{if(!this[_0x3a41c5(0x18a)])return;this[_0x3a41c5(0x1a6)]&&this[_0x3a41c5(0x201)](),(await this[_0x3a41c5(0x159)])[_0x3a41c5(0x1c1)](JSON['stringify'](_0x3246fb));}catch(_0x2c0162){this[_0x3a41c5(0x1e5)]?console['warn'](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162[_0x3a41c5(0x113)])):(this[_0x3a41c5(0x1e5)]=!0x0,console[_0x3a41c5(0x141)](this[_0x3a41c5(0x207)]+':\\x20'+(_0x2c0162&&_0x2c0162['message']),_0x3246fb)),this[_0x3a41c5(0x18a)]=!0x1,this[_0x3a41c5(0x112)]();}};function H(_0x708fe1,_0x3ad9bb,_0x1f357c,_0x5c3d72,_0x57da2a,_0x8bfd1c,_0x547194,_0x427ae0=ne){var _0x35b9cb=_0x548f0e;let _0x1a1b39=_0x1f357c[_0x35b9cb(0x114)](',')['map'](_0x1779fe=>{var _0x75e4e5=_0x35b9cb,_0x1c1066,_0x27d331,_0x28e1f6,_0xbdba49,_0x48a083,_0x3e9b5c,_0x282392,_0x1fe787;try{if(!_0x708fe1[_0x75e4e5(0x116)]){let _0x786a32=((_0x27d331=(_0x1c1066=_0x708fe1[_0x75e4e5(0x1c8)])==null?void 0x0:_0x1c1066[_0x75e4e5(0x1b4)])==null?void 0x0:_0x27d331[_0x75e4e5(0x143)])||((_0xbdba49=(_0x28e1f6=_0x708fe1['process'])==null?void 0x0:_0x28e1f6[_0x75e4e5(0x1e1)])==null?void 0x0:_0xbdba49[_0x75e4e5(0x1bb)])===_0x75e4e5(0x157);(_0x57da2a===_0x75e4e5(0x1b1)||_0x57da2a==='remix'||_0x57da2a==='astro'||_0x57da2a==='angular')&&(_0x57da2a+=_0x786a32?_0x75e4e5(0x15a):_0x75e4e5(0x1dd));let _0x4af9b3='';_0x57da2a===_0x75e4e5(0x10d)&&(_0x4af9b3=(((_0x282392=(_0x3e9b5c=(_0x48a083=_0x708fe1[_0x75e4e5(0x1d3)])==null?void 0x0:_0x48a083[_0x75e4e5(0x1db)])==null?void 0x0:_0x3e9b5c['ExpoDevice'])==null?void 0x0:_0x282392[_0x75e4e5(0x1f2)])||_0x75e4e5(0x1f4))[_0x75e4e5(0x1a8)](),_0x4af9b3&&(_0x57da2a+='\\x20'+_0x4af9b3,(_0x4af9b3==='android'||_0x4af9b3==='emulator'&&((_0x1fe787=_0x708fe1[_0x75e4e5(0x208)])==null?void 0x0:_0x1fe787[_0x75e4e5(0x14b)])==='10.0.2.2')&&(_0x3ad9bb='10.0.2.2'))),_0x708fe1[_0x75e4e5(0x116)]={'id':+new Date(),'tool':_0x57da2a},_0x547194&&_0x57da2a&&!_0x786a32&&(_0x4af9b3?console[_0x75e4e5(0x177)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x4af9b3+',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'):console[_0x75e4e5(0x177)](_0x75e4e5(0x197)+(_0x57da2a[_0x75e4e5(0x1d5)](0x0)[_0x75e4e5(0x12b)]()+_0x57da2a['substr'](0x1))+',',_0x75e4e5(0x155),_0x75e4e5(0x11a)));}let _0x229d61=new z(_0x708fe1,_0x3ad9bb,_0x1779fe,_0x5c3d72,_0x8bfd1c,_0x427ae0);return _0x229d61[_0x75e4e5(0x1c1)][_0x75e4e5(0x190)](_0x229d61);}catch(_0x207f65){return console[_0x75e4e5(0x141)](_0x75e4e5(0x184),_0x207f65&&_0x207f65[_0x75e4e5(0x113)]),()=>{};}});return _0x3ca2fe=>_0x1a1b39['forEach'](_0x570669=>_0x570669(_0x3ca2fe));}function ne(_0xfba01b,_0x5795ac,_0x526e6d,_0x23f0bc){var _0x88e87e=_0x548f0e;_0x23f0bc&&_0xfba01b===_0x88e87e(0x166)&&_0x526e6d[_0x88e87e(0x208)][_0x88e87e(0x166)]();}function b(_0x1c035d){var _0x33fbbc=_0x548f0e,_0x38efc3,_0xd2aec9;let _0x2a75b9=function(_0x448dbf,_0x3bc12f){return _0x3bc12f-_0x448dbf;},_0x22bb27;if(_0x1c035d[_0x33fbbc(0x186)])_0x22bb27=function(){var _0x5310e0=_0x33fbbc;return _0x1c035d[_0x5310e0(0x186)][_0x5310e0(0x14a)]();};else{if(_0x1c035d[_0x33fbbc(0x1c8)]&&_0x1c035d['process'][_0x33fbbc(0x162)]&&((_0xd2aec9=(_0x38efc3=_0x1c035d['process'])==null?void 0x0:_0x38efc3[_0x33fbbc(0x1e1)])==null?void 0x0:_0xd2aec9[_0x33fbbc(0x1bb)])!==_0x33fbbc(0x157))_0x22bb27=function(){var _0x4e9093=_0x33fbbc;return _0x1c035d['process'][_0x4e9093(0x162)]();},_0x2a75b9=function(_0x3c76d8,_0x527272){return 0x3e8*(_0x527272[0x0]-_0x3c76d8[0x0])+(_0x527272[0x1]-_0x3c76d8[0x1])/0xf4240;};else try{let {performance:_0x3d6831}=require(_0x33fbbc(0x1f5));_0x22bb27=function(){return _0x3d6831['now']();};}catch{_0x22bb27=function(){return+new Date();};}}return{'elapsed':_0x2a75b9,'timeStamp':_0x22bb27,'now':()=>Date['now']()};}function X(_0x3759c2,_0x327f60,_0x4ef84f){var _0x3c31ac=_0x548f0e,_0xa92efe,_0x3de67f,_0x8ece1a,_0x16959d,_0x5c93bf,_0x3ba4cf,_0x41f351;if(_0x3759c2[_0x3c31ac(0x209)]!==void 0x0)return _0x3759c2[_0x3c31ac(0x209)];let _0x5474b8=((_0x3de67f=(_0xa92efe=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0xa92efe[_0x3c31ac(0x1b4)])==null?void 0x0:_0x3de67f[_0x3c31ac(0x143)])||((_0x16959d=(_0x8ece1a=_0x3759c2[_0x3c31ac(0x1c8)])==null?void 0x0:_0x8ece1a['env'])==null?void 0x0:_0x16959d[_0x3c31ac(0x1bb)])===_0x3c31ac(0x157),_0x2e5086=!!(_0x4ef84f===_0x3c31ac(0x10d)&&((_0x5c93bf=_0x3759c2[_0x3c31ac(0x1d3)])==null?void 0x0:_0x5c93bf['modules']));function _0x165bf6(_0x327d5a){var _0x2198ff=_0x3c31ac;if(_0x327d5a[_0x2198ff(0x12a)]('/')&&_0x327d5a[_0x2198ff(0x1e3)]('/')){let _0x4ee469=new RegExp(_0x327d5a[_0x2198ff(0x18f)](0x1,-0x1));return _0x1a743c=>_0x4ee469[_0x2198ff(0x202)](_0x1a743c);}else{if(_0x327d5a[_0x2198ff(0x10b)]('*')||_0x327d5a[_0x2198ff(0x10b)]('?')){let _0x3c6f9e=new RegExp('^'+_0x327d5a[_0x2198ff(0x161)](/\\./g,String[_0x2198ff(0x1ae)](0x5c)+'.')['replace'](/\\*/g,'.*')[_0x2198ff(0x161)](/\\?/g,'.')+String[_0x2198ff(0x1ae)](0x24));return _0x1ed757=>_0x3c6f9e[_0x2198ff(0x202)](_0x1ed757);}else return _0x934f30=>_0x934f30===_0x327d5a;}}let _0x276fbc=_0x327f60[_0x3c31ac(0x1b8)](_0x165bf6);return _0x3759c2['_consoleNinjaAllowedToStart']=_0x5474b8||!_0x327f60,!_0x3759c2['_consoleNinjaAllowedToStart']&&((_0x3ba4cf=_0x3759c2[_0x3c31ac(0x208)])==null?void 0x0:_0x3ba4cf[_0x3c31ac(0x14b)])&&(_0x3759c2['_consoleNinjaAllowedToStart']=_0x276fbc['some'](_0x593d63=>_0x593d63(_0x3759c2[_0x3c31ac(0x208)][_0x3c31ac(0x14b)]))),_0x2e5086&&!_0x3759c2[_0x3c31ac(0x209)]&&!((_0x41f351=_0x3759c2[_0x3c31ac(0x208)])!=null&&_0x41f351[_0x3c31ac(0x14b)])&&(_0x3759c2[_0x3c31ac(0x209)]=!0x0),_0x3759c2[_0x3c31ac(0x209)];}function J(_0x2011df,_0x5af1c4,_0x1caee6,_0x2bde9f,_0x3f83e7,_0x1e8675){var _0x19fb99=_0x548f0e;_0x2011df=_0x2011df,_0x5af1c4=_0x5af1c4,_0x1caee6=_0x1caee6,_0x2bde9f=_0x2bde9f,_0x3f83e7=_0x3f83e7,_0x3f83e7=_0x3f83e7||{},_0x3f83e7[_0x19fb99(0x12d)]=_0x3f83e7[_0x19fb99(0x12d)]||{},_0x3f83e7[_0x19fb99(0x17d)]=_0x3f83e7[_0x19fb99(0x17d)]||{},_0x3f83e7[_0x19fb99(0x1cc)]=_0x3f83e7['reducePolicy']||{},_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]=_0x3f83e7['reducePolicy'][_0x19fb99(0x194)]||{},_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]=_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)]||{};let _0x10a276={'perLogpoint':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x151)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7['reducePolicy']['perLogpoint'][_0x19fb99(0x1e2)]||0x64,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)]['perLogpoint'][_0x19fb99(0x13c)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x194)][_0x19fb99(0x1ec)]||0x64},'global':{'reduceOnCount':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x151)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x1e2)]||0x12c,'resetWhenQuietMs':_0x3f83e7[_0x19fb99(0x1cc)][_0x19fb99(0x1fc)][_0x19fb99(0x13c)]||0x32,'resetOnProcessingTimeAverageMs':_0x3f83e7['reducePolicy'][_0x19fb99(0x1fc)]['resetOnProcessingTimeAverageMs']||0x64}},_0x3528bb=b(_0x2011df),_0x5e742b=_0x3528bb[_0x19fb99(0x127)],_0x1e8773=_0x3528bb[_0x19fb99(0x115)];function _0x3b798c(){var _0xf88f94=_0x19fb99;this[_0xf88f94(0x121)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this['_numberRegExp']=/^(0|[1-9][0-9]*)$/,this[_0xf88f94(0x1b7)]=/'([^\\\\']|\\\\')*'/,this[_0xf88f94(0x125)]=_0x2011df[_0xf88f94(0x171)],this[_0xf88f94(0x163)]=_0x2011df[_0xf88f94(0x110)],this[_0xf88f94(0x1b3)]=Object['getOwnPropertyDescriptor'],this[_0xf88f94(0x18b)]=Object['getOwnPropertyNames'],this[_0xf88f94(0x1f0)]=_0x2011df[_0xf88f94(0x138)],this['_regExpToString']=RegExp[_0xf88f94(0x188)]['toString'],this[_0xf88f94(0x1fe)]=Date[_0xf88f94(0x188)][_0xf88f94(0x1d0)];}_0x3b798c[_0x19fb99(0x188)]['serialize']=function(_0x216611,_0x5eff3c,_0x98d4f7,_0x591bd8){var _0x17b51c=_0x19fb99,_0x5097e6=this,_0x4ddf1a=_0x98d4f7['autoExpand'];function _0x2cf396(_0xa9d4ec,_0x4b33f3,_0x5bb97d){var _0x3f82bf=_0x49dd;_0x4b33f3[_0x3f82bf(0x13e)]=_0x3f82bf(0x15f),_0x4b33f3[_0x3f82bf(0x1c5)]=_0xa9d4ec[_0x3f82bf(0x113)],_0x158ad2=_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)],_0x5bb97d[_0x3f82bf(0x143)][_0x3f82bf(0x19a)]=_0x4b33f3,_0x5097e6[_0x3f82bf(0x18c)](_0x4b33f3,_0x5bb97d);}let _0x4268a1,_0x4a8d20,_0xfbbae=_0x2011df[_0x17b51c(0x124)];_0x2011df[_0x17b51c(0x124)]=!0x0,_0x2011df[_0x17b51c(0x165)]&&(_0x4268a1=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)],_0x4a8d20=_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)],_0x4268a1&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x1c5)]=function(){}),_0x4a8d20&&(_0x2011df[_0x17b51c(0x165)][_0x17b51c(0x141)]=function(){}));try{try{_0x98d4f7[_0x17b51c(0x107)]++,_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7['autoExpandPreviousObjects'][_0x17b51c(0x1c3)](_0x5eff3c);var _0xaaa11d,_0x5c63f2,_0x231fa2,_0x3f03a6,_0x44c1a5=[],_0x7e4f4a=[],_0x348545,_0x4cc2e9=this[_0x17b51c(0x172)](_0x5eff3c),_0x133a1d=_0x4cc2e9==='array',_0x3478d3=!0x1,_0x459df2=_0x4cc2e9==='function',_0x454d51=this[_0x17b51c(0x108)](_0x4cc2e9),_0x563084=this['_isPrimitiveWrapperType'](_0x4cc2e9),_0x320d3c=_0x454d51||_0x563084,_0x5529b5={},_0x542ce0=0x0,_0x423abb=!0x1,_0x158ad2,_0x13010c=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x98d4f7[_0x17b51c(0x11d)]){if(_0x133a1d){if(_0x5c63f2=_0x5eff3c['length'],_0x5c63f2>_0x98d4f7[_0x17b51c(0x1d6)]){for(_0x231fa2=0x0,_0x3f03a6=_0x98d4f7['elements'],_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));_0x216611[_0x17b51c(0x1fa)]=!0x0;}else{for(_0x231fa2=0x0,_0x3f03a6=_0x5c63f2,_0xaaa11d=_0x231fa2;_0xaaa11d<_0x3f03a6;_0xaaa11d++)_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x1b2)](_0x44c1a5,_0x5eff3c,_0x4cc2e9,_0xaaa11d,_0x98d4f7));}_0x98d4f7[_0x17b51c(0x1ca)]+=_0x7e4f4a[_0x17b51c(0x12e)];}if(!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9===_0x17b51c(0x171))&&!_0x454d51&&_0x4cc2e9!==_0x17b51c(0x11e)&&_0x4cc2e9!==_0x17b51c(0x1f3)&&_0x4cc2e9!==_0x17b51c(0x134)){var _0x13bdc7=_0x591bd8[_0x17b51c(0x20b)]||_0x98d4f7[_0x17b51c(0x20b)];if(this['_isSet'](_0x5eff3c)?(_0xaaa11d=0x0,_0x5eff3c['forEach'](function(_0x4e268b){var _0x1aa76f=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x1aa76f(0x1a5)]&&_0x98d4f7[_0x1aa76f(0x1a1)]&&_0x98d4f7[_0x1aa76f(0x1ca)]>_0x98d4f7[_0x1aa76f(0x152)]){_0x423abb=!0x0;return;}_0x7e4f4a[_0x1aa76f(0x1c3)](_0x5097e6['_addProperty'](_0x44c1a5,_0x5eff3c,_0x1aa76f(0x1b9),_0xaaa11d++,_0x98d4f7,function(_0x56afe8){return function(){return _0x56afe8;};}(_0x4e268b)));})):this[_0x17b51c(0x13d)](_0x5eff3c)&&_0x5eff3c[_0x17b51c(0x1d8)](function(_0x4b4368,_0x4a5cce){var _0x3f9993=_0x17b51c;if(_0x542ce0++,_0x98d4f7['autoExpandPropertyCount']++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;return;}if(!_0x98d4f7[_0x3f9993(0x1a5)]&&_0x98d4f7[_0x3f9993(0x1a1)]&&_0x98d4f7['autoExpandPropertyCount']>_0x98d4f7[_0x3f9993(0x152)]){_0x423abb=!0x0;return;}var _0xab791b=_0x4a5cce['toString']();_0xab791b[_0x3f9993(0x12e)]>0x64&&(_0xab791b=_0xab791b['slice'](0x0,0x64)+_0x3f9993(0x1ea)),_0x7e4f4a[_0x3f9993(0x1c3)](_0x5097e6[_0x3f9993(0x1b2)](_0x44c1a5,_0x5eff3c,_0x3f9993(0x139),_0xab791b,_0x98d4f7,function(_0x2460ca){return function(){return _0x2460ca;};}(_0x4b4368)));}),!_0x3478d3){try{for(_0x348545 in _0x5eff3c)if(!(_0x133a1d&&_0x13010c['test'](_0x348545))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7[_0x17b51c(0x1a5)]&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}catch{}if(_0x5529b5['_p_length']=!0x0,_0x459df2&&(_0x5529b5[_0x17b51c(0x17b)]=!0x0),!_0x423abb){var _0x516950=[][_0x17b51c(0x10e)](this[_0x17b51c(0x18b)](_0x5eff3c))['concat'](this[_0x17b51c(0x19e)](_0x5eff3c));for(_0xaaa11d=0x0,_0x5c63f2=_0x516950[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)if(_0x348545=_0x516950[_0xaaa11d],!(_0x133a1d&&_0x13010c[_0x17b51c(0x202)](_0x348545['toString']()))&&!this[_0x17b51c(0x1ef)](_0x5eff3c,_0x348545,_0x98d4f7)&&!_0x5529b5[typeof _0x348545!=_0x17b51c(0x1b5)?_0x17b51c(0x173)+_0x348545['toString']():_0x348545]){if(_0x542ce0++,_0x98d4f7[_0x17b51c(0x1ca)]++,_0x542ce0>_0x13bdc7){_0x423abb=!0x0;break;}if(!_0x98d4f7['isExpressionToEvaluate']&&_0x98d4f7[_0x17b51c(0x1a1)]&&_0x98d4f7[_0x17b51c(0x1ca)]>_0x98d4f7[_0x17b51c(0x152)]){_0x423abb=!0x0;break;}_0x7e4f4a[_0x17b51c(0x1c3)](_0x5097e6[_0x17b51c(0x11c)](_0x44c1a5,_0x5529b5,_0x5eff3c,_0x4cc2e9,_0x348545,_0x98d4f7));}}}}}if(_0x216611['type']=_0x4cc2e9,_0x320d3c?(_0x216611[_0x17b51c(0x181)]=_0x5eff3c[_0x17b51c(0x1a4)](),this[_0x17b51c(0x16e)](_0x4cc2e9,_0x216611,_0x98d4f7,_0x591bd8)):_0x4cc2e9==='date'?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1fe)][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x134)?_0x216611['value']=_0x5eff3c[_0x17b51c(0x1d0)]():_0x4cc2e9==='RegExp'?_0x216611[_0x17b51c(0x181)]=this['_regExpToString'][_0x17b51c(0x198)](_0x5eff3c):_0x4cc2e9===_0x17b51c(0x1b5)&&this[_0x17b51c(0x1f0)]?_0x216611[_0x17b51c(0x181)]=this[_0x17b51c(0x1f0)][_0x17b51c(0x188)][_0x17b51c(0x1d0)][_0x17b51c(0x198)](_0x5eff3c):!_0x98d4f7[_0x17b51c(0x11d)]&&!(_0x4cc2e9===_0x17b51c(0x199)||_0x4cc2e9==='undefined')&&(delete _0x216611['value'],_0x216611[_0x17b51c(0x17a)]=!0x0),_0x423abb&&(_0x216611['cappedProps']=!0x0),_0x158ad2=_0x98d4f7[_0x17b51c(0x143)]['current'],_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x216611,this[_0x17b51c(0x18c)](_0x216611,_0x98d4f7),_0x7e4f4a[_0x17b51c(0x12e)]){for(_0xaaa11d=0x0,_0x5c63f2=_0x7e4f4a[_0x17b51c(0x12e)];_0xaaa11d<_0x5c63f2;_0xaaa11d++)_0x7e4f4a[_0xaaa11d](_0xaaa11d);}_0x44c1a5[_0x17b51c(0x12e)]&&(_0x216611['props']=_0x44c1a5);}catch(_0x584964){_0x2cf396(_0x584964,_0x216611,_0x98d4f7);}this['_additionalMetadata'](_0x5eff3c,_0x216611),this[_0x17b51c(0x191)](_0x216611,_0x98d4f7),_0x98d4f7[_0x17b51c(0x143)][_0x17b51c(0x19a)]=_0x158ad2,_0x98d4f7['level']--,_0x98d4f7[_0x17b51c(0x1a1)]=_0x4ddf1a,_0x98d4f7['autoExpand']&&_0x98d4f7[_0x17b51c(0x187)][_0x17b51c(0x195)]();}finally{_0x4268a1&&(_0x2011df[_0x17b51c(0x165)]['error']=_0x4268a1),_0x4a8d20&&(_0x2011df['console'][_0x17b51c(0x141)]=_0x4a8d20),_0x2011df[_0x17b51c(0x124)]=_0xfbbae;}return _0x216611;},_0x3b798c[_0x19fb99(0x188)]['_getOwnPropertySymbols']=function(_0x4c28a7){var _0xd2148d=_0x19fb99;return Object[_0xd2148d(0x122)]?Object[_0xd2148d(0x122)](_0x4c28a7):[];},_0x3b798c['prototype'][_0x19fb99(0x19f)]=function(_0x27432c){var _0x117f9a=_0x19fb99;return!!(_0x27432c&&_0x2011df['Set']&&this[_0x117f9a(0x1da)](_0x27432c)===_0x117f9a(0x17f)&&_0x27432c[_0x117f9a(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ef)]=function(_0x327172,_0x1bf02d,_0x68c506){var _0x42d895=_0x19fb99;if(!_0x68c506[_0x42d895(0x183)]){let _0x31f3c6=this[_0x42d895(0x1b3)](_0x327172,_0x1bf02d);if(_0x31f3c6&&_0x31f3c6[_0x42d895(0x136)])return!0x0;}return _0x68c506[_0x42d895(0x1ff)]?typeof _0x327172[_0x1bf02d]==_0x42d895(0x1df):!0x1;},_0x3b798c['prototype'][_0x19fb99(0x172)]=function(_0x4b4ff7){var _0x89a987=_0x19fb99,_0x2df42a='';return _0x2df42a=typeof _0x4b4ff7,_0x2df42a===_0x89a987(0x140)?this[_0x89a987(0x1da)](_0x4b4ff7)==='[object\\x20Array]'?_0x2df42a=_0x89a987(0x1d2):this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x193)?_0x2df42a='date':this[_0x89a987(0x1da)](_0x4b4ff7)===_0x89a987(0x19d)?_0x2df42a='bigint':_0x4b4ff7===null?_0x2df42a=_0x89a987(0x199):_0x4b4ff7[_0x89a987(0x192)]&&(_0x2df42a=_0x4b4ff7[_0x89a987(0x192)][_0x89a987(0x1f1)]||_0x2df42a):_0x2df42a==='undefined'&&this[_0x89a987(0x163)]&&_0x4b4ff7 instanceof this['_HTMLAllCollection']&&(_0x2df42a='HTMLAllCollection'),_0x2df42a;},_0x3b798c[_0x19fb99(0x188)]['_objectToString']=function(_0x4ea4a3){var _0xe65ac2=_0x19fb99;return Object[_0xe65ac2(0x188)][_0xe65ac2(0x1d0)]['call'](_0x4ea4a3);},_0x3b798c['prototype'][_0x19fb99(0x108)]=function(_0x486186){var _0x59de18=_0x19fb99;return _0x486186==='boolean'||_0x486186===_0x59de18(0x204)||_0x486186==='number';},_0x3b798c[_0x19fb99(0x188)]['_isPrimitiveWrapperType']=function(_0x57b53f){var _0x3d404c=_0x19fb99;return _0x57b53f===_0x3d404c(0x1de)||_0x57b53f==='String'||_0x57b53f===_0x3d404c(0x1bc);},_0x3b798c['prototype'][_0x19fb99(0x1b2)]=function(_0x51d7e9,_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116){var _0x327fee=this;return function(_0x5f212a){var _0x45776a=_0x49dd,_0x480d1e=_0x10ecad[_0x45776a(0x143)][_0x45776a(0x19a)],_0x2270b6=_0x10ecad['node']['index'],_0x3242a9=_0x10ecad['node']['parent'];_0x10ecad[_0x45776a(0x143)][_0x45776a(0x168)]=_0x480d1e,_0x10ecad[_0x45776a(0x143)][_0x45776a(0x13a)]=typeof _0x32ddbe=='number'?_0x32ddbe:_0x5f212a,_0x51d7e9[_0x45776a(0x1c3)](_0x327fee[_0x45776a(0x119)](_0x36fff9,_0x538d0c,_0x32ddbe,_0x10ecad,_0x6db116)),_0x10ecad['node'][_0x45776a(0x168)]=_0x3242a9,_0x10ecad['node'][_0x45776a(0x13a)]=_0x2270b6;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11c)]=function(_0x4fff24,_0xf060cd,_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d){var _0x11f0a7=_0x19fb99,_0x261b2c=this;return _0xf060cd[typeof _0x46c20e!=_0x11f0a7(0x1b5)?_0x11f0a7(0x173)+_0x46c20e[_0x11f0a7(0x1d0)]():_0x46c20e]=!0x0,function(_0x3a475e){var _0x2f5d31=_0x11f0a7,_0x2b9d6c=_0x2e08a7[_0x2f5d31(0x143)]['current'],_0x4b248b=_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)],_0xbed829=_0x2e08a7['node']['parent'];_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0x2b9d6c,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x3a475e,_0x4fff24[_0x2f5d31(0x1c3)](_0x261b2c[_0x2f5d31(0x119)](_0x35b969,_0x52eeb1,_0x46c20e,_0x2e08a7,_0x388c5d)),_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x168)]=_0xbed829,_0x2e08a7[_0x2f5d31(0x143)][_0x2f5d31(0x13a)]=_0x4b248b;};},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x119)]=function(_0x1bf49f,_0x10ac96,_0x57dfa6,_0xee7322,_0x598c3f){var _0x326486=_0x19fb99,_0x57fd55=this;_0x598c3f||(_0x598c3f=function(_0x46b469,_0x55c36d){return _0x46b469[_0x55c36d];});var _0x4331ba=_0x57dfa6[_0x326486(0x1d0)](),_0x58db2f=_0xee7322[_0x326486(0x14d)]||{},_0x56fbc0=_0xee7322[_0x326486(0x11d)],_0x28a895=_0xee7322['isExpressionToEvaluate'];try{var _0x4d3354=this[_0x326486(0x13d)](_0x1bf49f),_0x4f8709=_0x4331ba;_0x4d3354&&_0x4f8709[0x0]==='\\x27'&&(_0x4f8709=_0x4f8709[_0x326486(0x185)](0x1,_0x4f8709[_0x326486(0x12e)]-0x2));var _0x15481e=_0xee7322[_0x326486(0x14d)]=_0x58db2f[_0x326486(0x173)+_0x4f8709];_0x15481e&&(_0xee7322[_0x326486(0x11d)]=_0xee7322[_0x326486(0x11d)]+0x1),_0xee7322[_0x326486(0x1a5)]=!!_0x15481e;var _0x3a61d9=typeof _0x57dfa6==_0x326486(0x1b5),_0x1e1792={'name':_0x3a61d9||_0x4d3354?_0x4331ba:this[_0x326486(0x11b)](_0x4331ba)};if(_0x3a61d9&&(_0x1e1792['symbol']=!0x0),!(_0x10ac96==='array'||_0x10ac96===_0x326486(0x1e4))){var _0x4503a0=this[_0x326486(0x1b3)](_0x1bf49f,_0x57dfa6);if(_0x4503a0&&(_0x4503a0['set']&&(_0x1e1792[_0x326486(0x16b)]=!0x0),_0x4503a0[_0x326486(0x136)]&&!_0x15481e&&!_0xee7322[_0x326486(0x183)]))return _0x1e1792[_0x326486(0x1ed)]=!0x0,this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x32a36e;try{_0x32a36e=_0x598c3f(_0x1bf49f,_0x57dfa6);}catch(_0x44aaa6){return _0x1e1792={'name':_0x4331ba,'type':_0x326486(0x15f),'error':_0x44aaa6['message']},this[_0x326486(0x156)](_0x1e1792,_0xee7322),_0x1e1792;}var _0x27eaec=this[_0x326486(0x172)](_0x32a36e),_0x1dd8cf=this['_isPrimitiveType'](_0x27eaec);if(_0x1e1792[_0x326486(0x13e)]=_0x27eaec,_0x1dd8cf)this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x14aecf=_0x326486;_0x1e1792['value']=_0x32a36e[_0x14aecf(0x1a4)](),!_0x15481e&&_0x57fd55['_capIfString'](_0x27eaec,_0x1e1792,_0xee7322,{});});else{var _0x1fd626=_0xee7322[_0x326486(0x1a1)]&&_0xee7322[_0x326486(0x107)]<_0xee7322[_0x326486(0x123)]&&_0xee7322[_0x326486(0x187)][_0x326486(0x18d)](_0x32a36e)<0x0&&_0x27eaec!==_0x326486(0x1df)&&_0xee7322['autoExpandPropertyCount']<_0xee7322[_0x326486(0x152)];_0x1fd626||_0xee7322[_0x326486(0x107)]<_0x56fbc0||_0x15481e?this[_0x326486(0x19b)](_0x1e1792,_0x32a36e,_0xee7322,_0x15481e||{}):this[_0x326486(0x156)](_0x1e1792,_0xee7322,_0x32a36e,function(){var _0x187576=_0x326486;_0x27eaec==='null'||_0x27eaec==='undefined'||(delete _0x1e1792[_0x187576(0x181)],_0x1e1792[_0x187576(0x17a)]=!0x0);});}return _0x1e1792;}finally{_0xee7322[_0x326486(0x14d)]=_0x58db2f,_0xee7322[_0x326486(0x11d)]=_0x56fbc0,_0xee7322[_0x326486(0x1a5)]=_0x28a895;}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x16e)]=function(_0x56e4d4,_0x9663b4,_0x4ca9b4,_0x4f8a61){var _0x289244=_0x19fb99,_0x543170=_0x4f8a61['strLength']||_0x4ca9b4['strLength'];if((_0x56e4d4===_0x289244(0x204)||_0x56e4d4===_0x289244(0x11e))&&_0x9663b4[_0x289244(0x181)]){let _0x2b9781=_0x9663b4[_0x289244(0x181)][_0x289244(0x12e)];_0x4ca9b4[_0x289244(0x169)]+=_0x2b9781,_0x4ca9b4[_0x289244(0x169)]>_0x4ca9b4[_0x289244(0x14f)]?(_0x9663b4[_0x289244(0x17a)]='',delete _0x9663b4[_0x289244(0x181)]):_0x2b9781>_0x543170&&(_0x9663b4[_0x289244(0x17a)]=_0x9663b4[_0x289244(0x181)]['substr'](0x0,_0x543170),delete _0x9663b4[_0x289244(0x181)]);}},_0x3b798c['prototype'][_0x19fb99(0x13d)]=function(_0x20e242){var _0x22bc15=_0x19fb99;return!!(_0x20e242&&_0x2011df[_0x22bc15(0x139)]&&this[_0x22bc15(0x1da)](_0x20e242)==='[object\\x20Map]'&&_0x20e242[_0x22bc15(0x1d8)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x11b)]=function(_0x51405e){var _0x339753=_0x19fb99;if(_0x51405e[_0x339753(0x1e6)](/^\\d+$/))return _0x51405e;var _0xa32815;try{_0xa32815=JSON['stringify'](''+_0x51405e);}catch{_0xa32815='\\x22'+this[_0x339753(0x1da)](_0x51405e)+'\\x22';}return _0xa32815[_0x339753(0x1e6)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0xa32815=_0xa32815[_0x339753(0x185)](0x1,_0xa32815['length']-0x2):_0xa32815=_0xa32815[_0x339753(0x161)](/'/g,'\\x5c\\x27')[_0x339753(0x161)](/\\\\\"/g,'\\x22')[_0x339753(0x161)](/(^\"|\"$)/g,'\\x27'),_0xa32815;},_0x3b798c[_0x19fb99(0x188)]['_processTreeNodeResult']=function(_0x19aa6c,_0x15bfd6,_0x57de46,_0x17e0d5){var _0x5136d0=_0x19fb99;this['_treeNodePropertiesBeforeFullValue'](_0x19aa6c,_0x15bfd6),_0x17e0d5&&_0x17e0d5(),this[_0x5136d0(0x1ad)](_0x57de46,_0x19aa6c),this[_0x5136d0(0x191)](_0x19aa6c,_0x15bfd6);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x18c)]=function(_0x3d1ee7,_0x70e5ea){var _0x548bce=_0x19fb99;this['_setNodeId'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x175)](_0x3d1ee7,_0x70e5ea),this['_setNodeExpressionPath'](_0x3d1ee7,_0x70e5ea),this[_0x548bce(0x1e9)](_0x3d1ee7,_0x70e5ea);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x203)]=function(_0x39276,_0x2973e9){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x175)]=function(_0x3d5358,_0x1ce0bc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x149)]=function(_0x5460c7,_0x5726fc){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1e7)]=function(_0xb18247){var _0x5a9038=_0x19fb99;return _0xb18247===this[_0x5a9038(0x125)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x191)]=function(_0xb3362f,_0x257171){var _0x24e002=_0x19fb99;this[_0x24e002(0x149)](_0xb3362f,_0x257171),this[_0x24e002(0x196)](_0xb3362f),_0x257171[_0x24e002(0x147)]&&this[_0x24e002(0x1bf)](_0xb3362f),this[_0x24e002(0x11f)](_0xb3362f,_0x257171),this['_addLoadNode'](_0xb3362f,_0x257171),this[_0x24e002(0x182)](_0xb3362f);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1ad)]=function(_0x2dbd2f,_0x37c5b1){var _0x320ee5=_0x19fb99;try{_0x2dbd2f&&typeof _0x2dbd2f[_0x320ee5(0x12e)]==_0x320ee5(0x117)&&(_0x37c5b1[_0x320ee5(0x12e)]=_0x2dbd2f[_0x320ee5(0x12e)]);}catch{}if(_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x117)||_0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1bc)){if(isNaN(_0x37c5b1['value']))_0x37c5b1['nan']=!0x0,delete _0x37c5b1['value'];else switch(_0x37c5b1[_0x320ee5(0x181)]){case Number[_0x320ee5(0x14c)]:_0x37c5b1[_0x320ee5(0x1e8)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case Number[_0x320ee5(0x12c)]:_0x37c5b1[_0x320ee5(0x1ee)]=!0x0,delete _0x37c5b1[_0x320ee5(0x181)];break;case 0x0:this[_0x320ee5(0x1fb)](_0x37c5b1['value'])&&(_0x37c5b1[_0x320ee5(0x129)]=!0x0);break;}}else _0x37c5b1[_0x320ee5(0x13e)]===_0x320ee5(0x1df)&&typeof _0x2dbd2f[_0x320ee5(0x1f1)]==_0x320ee5(0x204)&&_0x2dbd2f[_0x320ee5(0x1f1)]&&_0x37c5b1['name']&&_0x2dbd2f['name']!==_0x37c5b1['name']&&(_0x37c5b1[_0x320ee5(0x13b)]=_0x2dbd2f[_0x320ee5(0x1f1)]);},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x1fb)]=function(_0x3fe3ce){var _0x5bd9dd=_0x19fb99;return 0x1/_0x3fe3ce===Number[_0x5bd9dd(0x12c)];},_0x3b798c[_0x19fb99(0x188)]['_sortProps']=function(_0x302641){var _0x20eea1=_0x19fb99;!_0x302641[_0x20eea1(0x20b)]||!_0x302641[_0x20eea1(0x20b)][_0x20eea1(0x12e)]||_0x302641[_0x20eea1(0x13e)]===_0x20eea1(0x1d2)||_0x302641['type']===_0x20eea1(0x139)||_0x302641['type']===_0x20eea1(0x1b9)||_0x302641['props'][_0x20eea1(0x16c)](function(_0x2e3c0f,_0x466671){var _0x2def12=_0x20eea1,_0x299cd3=_0x2e3c0f[_0x2def12(0x1f1)][_0x2def12(0x1a8)](),_0x569a8c=_0x466671[_0x2def12(0x1f1)]['toLowerCase']();return _0x299cd3<_0x569a8c?-0x1:_0x299cd3>_0x569a8c?0x1:0x0;});},_0x3b798c['prototype'][_0x19fb99(0x11f)]=function(_0x1fce5c,_0x59600b){var _0x272775=_0x19fb99;if(!(_0x59600b[_0x272775(0x1ff)]||!_0x1fce5c['props']||!_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)])){for(var _0x5b060d=[],_0x576482=[],_0x469b84=0x0,_0x1419a1=_0x1fce5c[_0x272775(0x20b)][_0x272775(0x12e)];_0x469b84<_0x1419a1;_0x469b84++){var _0x554dbc=_0x1fce5c[_0x272775(0x20b)][_0x469b84];_0x554dbc['type']===_0x272775(0x1df)?_0x5b060d[_0x272775(0x1c3)](_0x554dbc):_0x576482['push'](_0x554dbc);}if(!(!_0x576482['length']||_0x5b060d[_0x272775(0x12e)]<=0x1)){_0x1fce5c[_0x272775(0x20b)]=_0x576482;var _0x5ac4d9={'functionsNode':!0x0,'props':_0x5b060d};this['_setNodeId'](_0x5ac4d9,_0x59600b),this['_setNodeLabel'](_0x5ac4d9,_0x59600b),this['_setNodeExpandableState'](_0x5ac4d9),this['_setNodePermissions'](_0x5ac4d9,_0x59600b),_0x5ac4d9['id']+='\\x20f',_0x1fce5c[_0x272775(0x20b)][_0x272775(0x15e)](_0x5ac4d9);}}},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x206)]=function(_0x53bb34,_0x23ecf2){},_0x3b798c['prototype'][_0x19fb99(0x196)]=function(_0x59c87d){},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x109)]=function(_0x480385){var _0x3b79b1=_0x19fb99;return Array['isArray'](_0x480385)||typeof _0x480385=='object'&&this[_0x3b79b1(0x1da)](_0x480385)===_0x3b79b1(0x1f6);},_0x3b798c['prototype'][_0x19fb99(0x1e9)]=function(_0x3277e3,_0x15bc20){},_0x3b798c[_0x19fb99(0x188)]['_cleanNode']=function(_0x3d12db){var _0x1bb90c=_0x19fb99;delete _0x3d12db[_0x1bb90c(0x106)],delete _0x3d12db[_0x1bb90c(0x179)],delete _0x3d12db[_0x1bb90c(0x146)];},_0x3b798c[_0x19fb99(0x188)][_0x19fb99(0x10c)]=function(_0x804785,_0x46b090){};let _0x1ab812=new _0x3b798c(),_0x4253f5={'props':_0x3f83e7[_0x19fb99(0x12d)]['props']||0x64,'elements':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x1d6)]||0x64,'strLength':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x16a)]||0x400*0x32,'totalStrLength':_0x3f83e7['defaultLimits'][_0x19fb99(0x14f)]||0x400*0x32,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x152)]||0x1388,'autoExpandMaxDepth':_0x3f83e7[_0x19fb99(0x12d)][_0x19fb99(0x123)]||0xa},_0x5ccf32={'props':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x20b)]||0x5,'elements':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x1d6)]||0x5,'strLength':_0x3f83e7['reducedLimits'][_0x19fb99(0x16a)]||0x100,'totalStrLength':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x14f)]||0x100*0x3,'autoExpandLimit':_0x3f83e7[_0x19fb99(0x17d)][_0x19fb99(0x152)]||0x1e,'autoExpandMaxDepth':_0x3f83e7['reducedLimits']['autoExpandMaxDepth']||0x2};if(_0x1e8675){let _0x2f3a37=_0x1ab812['serialize']['bind'](_0x1ab812);_0x1ab812[_0x19fb99(0x19b)]=function(_0x4f58de,_0x29d7d0,_0x30b459,_0x1f5fdf){return _0x2f3a37(_0x4f58de,_0x1e8675(_0x29d7d0),_0x30b459,_0x1f5fdf);};}function _0xc68888(_0x535031,_0x3340fc,_0x337e66,_0x22242c,_0x124bfa,_0x5f1e1f){var _0x46fc5e=_0x19fb99;let _0x56fb0c,_0x26a7c9;try{_0x26a7c9=_0x1e8773(),_0x56fb0c=_0x1caee6[_0x3340fc],!_0x56fb0c||_0x26a7c9-_0x56fb0c['ts']>_0x10a276['perLogpoint'][_0x46fc5e(0x13c)]&&_0x56fb0c[_0x46fc5e(0x1a2)]&&_0x56fb0c[_0x46fc5e(0x1a7)]/_0x56fb0c[_0x46fc5e(0x1a2)]<_0x10a276[_0x46fc5e(0x194)]['resetOnProcessingTimeAverageMs']?(_0x1caee6[_0x3340fc]=_0x56fb0c={'count':0x0,'time':0x0,'ts':_0x26a7c9},_0x1caee6['hits']={}):_0x26a7c9-_0x1caee6[_0x46fc5e(0x1ab)]['ts']>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x13c)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]&&_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a7)]/_0x1caee6[_0x46fc5e(0x1ab)]['count']<_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x1ec)]&&(_0x1caee6[_0x46fc5e(0x1ab)]={});let _0x135eed=[],_0x4de057=_0x56fb0c[_0x46fc5e(0x15d)]||_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]?_0x5ccf32:_0x4253f5,_0x5ea472=_0x57de65=>{var _0x1e64a0=_0x46fc5e;let _0x2f1ff9={};return _0x2f1ff9[_0x1e64a0(0x20b)]=_0x57de65[_0x1e64a0(0x20b)],_0x2f1ff9[_0x1e64a0(0x1d6)]=_0x57de65['elements'],_0x2f1ff9[_0x1e64a0(0x16a)]=_0x57de65[_0x1e64a0(0x16a)],_0x2f1ff9['totalStrLength']=_0x57de65[_0x1e64a0(0x14f)],_0x2f1ff9[_0x1e64a0(0x152)]=_0x57de65[_0x1e64a0(0x152)],_0x2f1ff9['autoExpandMaxDepth']=_0x57de65[_0x1e64a0(0x123)],_0x2f1ff9[_0x1e64a0(0x147)]=!0x1,_0x2f1ff9['noFunctions']=!_0x5af1c4,_0x2f1ff9[_0x1e64a0(0x11d)]=0x1,_0x2f1ff9['level']=0x0,_0x2f1ff9[_0x1e64a0(0x164)]=_0x1e64a0(0x167),_0x2f1ff9[_0x1e64a0(0x1d1)]=_0x1e64a0(0x16f),_0x2f1ff9[_0x1e64a0(0x1a1)]=!0x0,_0x2f1ff9[_0x1e64a0(0x187)]=[],_0x2f1ff9[_0x1e64a0(0x1ca)]=0x0,_0x2f1ff9['resolveGetters']=_0x3f83e7['resolveGetters'],_0x2f1ff9[_0x1e64a0(0x169)]=0x0,_0x2f1ff9[_0x1e64a0(0x143)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x2f1ff9;};for(var _0x19c1cf=0x0;_0x19c1cf<_0x124bfa[_0x46fc5e(0x12e)];_0x19c1cf++)_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'timeNode':_0x535031==='time'||void 0x0},_0x124bfa[_0x19c1cf],_0x5ea472(_0x4de057),{}));if(_0x535031==='trace'||_0x535031===_0x46fc5e(0x1c5)){let _0x11d4f0=Error[_0x46fc5e(0x1f7)];try{Error[_0x46fc5e(0x1f7)]=0x1/0x0,_0x135eed[_0x46fc5e(0x1c3)](_0x1ab812[_0x46fc5e(0x19b)]({'stackNode':!0x0},new Error()[_0x46fc5e(0x1af)],_0x5ea472(_0x4de057),{'strLength':0x1/0x0}));}finally{Error[_0x46fc5e(0x1f7)]=_0x11d4f0;}}return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':_0x135eed,'id':_0x3340fc,'context':_0x5f1e1f}]};}catch(_0x29c306){return{'method':_0x46fc5e(0x177),'version':_0x2bde9f,'args':[{'ts':_0x337e66,'session':_0x22242c,'args':[{'type':_0x46fc5e(0x15f),'error':_0x29c306&&_0x29c306[_0x46fc5e(0x113)]}],'id':_0x3340fc,'context':_0x5f1e1f}]};}finally{try{if(_0x56fb0c&&_0x26a7c9){let _0x52a27e=_0x1e8773();_0x56fb0c[_0x46fc5e(0x1a2)]++,_0x56fb0c[_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x56fb0c['ts']=_0x52a27e,_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]++,_0x1caee6['hits'][_0x46fc5e(0x1a7)]+=_0x5e742b(_0x26a7c9,_0x52a27e),_0x1caee6[_0x46fc5e(0x1ab)]['ts']=_0x52a27e,(_0x56fb0c[_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x194)][_0x46fc5e(0x151)]||_0x56fb0c['time']>_0x10a276['perLogpoint']['reduceOnAccumulatedProcessingTimeMs'])&&(_0x56fb0c[_0x46fc5e(0x15d)]=!0x0),(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x1a2)]>_0x10a276[_0x46fc5e(0x1fc)][_0x46fc5e(0x151)]||_0x1caee6[_0x46fc5e(0x1ab)]['time']>_0x10a276['global'][_0x46fc5e(0x1e2)])&&(_0x1caee6[_0x46fc5e(0x1ab)][_0x46fc5e(0x15d)]=!0x0);}}catch{}}}return _0xc68888;}function G(_0x357a3e){var _0x1c1d5c=_0x548f0e;if(_0x357a3e&&typeof _0x357a3e==_0x1c1d5c(0x140)&&_0x357a3e[_0x1c1d5c(0x192)])switch(_0x357a3e['constructor'][_0x1c1d5c(0x1f1)]){case _0x1c1d5c(0x1f8):return _0x357a3e['hasOwnProperty'](Symbol[_0x1c1d5c(0x1cb)])?Promise[_0x1c1d5c(0x1ac)]():_0x357a3e;case'bound\\x20Promise':return Promise[_0x1c1d5c(0x1ac)]();}return _0x357a3e;}function _0x49dd(_0x48794b,_0x215201){var _0x5eb787=_0x5eb7();return _0x49dd=function(_0x49dd64,_0x5b9134){_0x49dd64=_0x49dd64-0x106;var _0x4735f0=_0x5eb787[_0x49dd64];return _0x4735f0;},_0x49dd(_0x48794b,_0x215201);}((_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x5bf3d1,_0xfe754b,_0x5a9d76,_0x1aab36,_0x3bc27c,_0x57f4e7,_0x4fa6c3)=>{var _0xf735ce=_0x548f0e;if(_0x4ab1c6['_console_ninja'])return _0x4ab1c6['_console_ninja'];let _0x313a8d={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x4ab1c6,_0x5a9d76,_0x478f2c))return _0x4ab1c6[_0xf735ce(0x16d)]=_0x313a8d,_0x4ab1c6['_console_ninja'];let _0x418c01=b(_0x4ab1c6),_0xd76728=_0x418c01[_0xf735ce(0x127)],_0x3e56d8=_0x418c01[_0xf735ce(0x115)],_0x3e2373=_0x418c01[_0xf735ce(0x14a)],_0x48f2ad={'hits':{},'ts':{}},_0x505066=J(_0x4ab1c6,_0x1aab36,_0x48f2ad,_0x5bf3d1,_0x4fa6c3,_0x478f2c==='next.js'?G:void 0x0),_0x48cb15=(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9)=>{var _0x27df57=_0xf735ce;let _0x1159ce=_0x4ab1c6['_console_ninja'];try{return _0x4ab1c6['_console_ninja']=_0x313a8d,_0x505066(_0x17b02e,_0x154ef3,_0x3a05a0,_0x463625,_0x51db52,_0x5042d9);}finally{_0x4ab1c6[_0x27df57(0x16d)]=_0x1159ce;}},_0xcc7412=_0xab4b0c=>{_0x48f2ad['ts'][_0xab4b0c]=_0x3e56d8();},_0x3aeb93=(_0xbe2a9d,_0x37862a)=>{var _0x30e3cb=_0xf735ce;let _0x37627d=_0x48f2ad['ts'][_0x37862a];if(delete _0x48f2ad['ts'][_0x37862a],_0x37627d){let _0x464639=_0xd76728(_0x37627d,_0x3e56d8());_0x45f648(_0x48cb15(_0x30e3cb(0x1a7),_0xbe2a9d,_0x3e2373(),_0x5efb7d,[_0x464639],_0x37862a));}},_0x5b170d=_0x4b3a1c=>{var _0x5a439b=_0xf735ce,_0x1bd0d3;return _0x478f2c===_0x5a439b(0x1b1)&&_0x4ab1c6['origin']&&((_0x1bd0d3=_0x4b3a1c==null?void 0x0:_0x4b3a1c['args'])==null?void 0x0:_0x1bd0d3[_0x5a439b(0x12e)])&&(_0x4b3a1c['args'][0x0]['origin']=_0x4ab1c6[_0x5a439b(0x133)]),_0x4b3a1c;};_0x4ab1c6[_0xf735ce(0x16d)]={'consoleLog':(_0x1f92a3,_0x3d1b32)=>{var _0x384ddc=_0xf735ce;_0x4ab1c6[_0x384ddc(0x165)][_0x384ddc(0x177)][_0x384ddc(0x1f1)]!=='disabledLog'&&_0x45f648(_0x48cb15(_0x384ddc(0x177),_0x1f92a3,_0x3e2373(),_0x5efb7d,_0x3d1b32));},'consoleTrace':(_0x16d5a,_0x223858)=>{var _0x616644=_0xf735ce,_0xdf7629,_0x7ea927;_0x4ab1c6[_0x616644(0x165)]['log'][_0x616644(0x1f1)]!==_0x616644(0x118)&&((_0x7ea927=(_0xdf7629=_0x4ab1c6[_0x616644(0x1c8)])==null?void 0x0:_0xdf7629['versions'])!=null&&_0x7ea927[_0x616644(0x143)]&&(_0x4ab1c6[_0x616644(0x1c0)]=!0x0),_0x45f648(_0x5b170d(_0x48cb15(_0x616644(0x1a3),_0x16d5a,_0x3e2373(),_0x5efb7d,_0x223858))));},'consoleError':(_0x38f47b,_0x35429f)=>{_0x4ab1c6['_ninjaIgnoreNextError']=!0x0,_0x45f648(_0x5b170d(_0x48cb15('error',_0x38f47b,_0x3e2373(),_0x5efb7d,_0x35429f)));},'consoleTime':_0x4cf735=>{_0xcc7412(_0x4cf735);},'consoleTimeEnd':(_0x566c48,_0x364eea)=>{_0x3aeb93(_0x364eea,_0x566c48);},'autoLog':(_0x1eb1b1,_0xa812f2)=>{var _0x1ace51=_0xf735ce;_0x45f648(_0x48cb15(_0x1ace51(0x177),_0xa812f2,_0x3e2373(),_0x5efb7d,[_0x1eb1b1]));},'autoLogMany':(_0x56ca86,_0x4bac87)=>{var _0x3394a4=_0xf735ce;_0x45f648(_0x48cb15(_0x3394a4(0x177),_0x56ca86,_0x3e2373(),_0x5efb7d,_0x4bac87));},'autoTrace':(_0x417845,_0x145484)=>{var _0x27ae88=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x27ae88(0x1a3),_0x145484,_0x3e2373(),_0x5efb7d,[_0x417845])));},'autoTraceMany':(_0xca37d7,_0x262246)=>{var _0x26f92c=_0xf735ce;_0x45f648(_0x5b170d(_0x48cb15(_0x26f92c(0x1a3),_0xca37d7,_0x3e2373(),_0x5efb7d,_0x262246)));},'autoTime':(_0x32789a,_0x59deba,_0xcc1c2c)=>{_0xcc7412(_0xcc1c2c);},'autoTimeEnd':(_0x58bdab,_0x21cfd7,_0x507017)=>{_0x3aeb93(_0x21cfd7,_0x507017);},'coverage':_0x237fb5=>{var _0x4ec628=_0xf735ce;_0x45f648({'method':_0x4ec628(0x10f),'version':_0x5bf3d1,'args':[{'id':_0x237fb5}]});}};let _0x45f648=H(_0x4ab1c6,_0x3770af,_0x3ce2fc,_0x3f6b32,_0x478f2c,_0x3bc27c,_0x57f4e7),_0x5efb7d=_0x4ab1c6[_0xf735ce(0x116)];return _0x4ab1c6['_console_ninja'];})(globalThis,_0x548f0e(0x17e),_0x548f0e(0x154),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.501\\\\node_modules\",_0x548f0e(0x131),_0x548f0e(0x1dc),_0x548f0e(0x144),_0x548f0e(0x1b0),_0x548f0e(0x150),_0x548f0e(0x176),_0x548f0e(0x111),{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}});");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
}),
];

//# sourceMappingURL=app_%28main%29_projects_097ac65b._.js.map