class Lexer {

    private getStringPrimeryCharsList (str: string): string[] {
        return Array.from(str);
    }

}