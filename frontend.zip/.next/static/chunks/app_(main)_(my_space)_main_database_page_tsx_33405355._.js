(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_a850c9a0._.js",
  "static/chunks/node_modules_d6de074a._.js"
],
    source: "dynamic"
});
