(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d6f0f8f4._.js",
  "static/chunks/node_modules_160e8129._.js"
],
    source: "dynamic"
});
