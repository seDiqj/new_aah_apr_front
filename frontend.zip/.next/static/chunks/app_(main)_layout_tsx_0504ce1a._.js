(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_(main)_globals_71f398b0.css",
  "static/chunks/_f305b1a6._.js",
  "static/chunks/node_modules_a337a931._.js"
],
    source: "dynamic"
});
