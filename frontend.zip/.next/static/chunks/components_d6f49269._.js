(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/ui/breadcrumb.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Breadcrumb",
    ()=>Breadcrumb,
    "BreadcrumbEllipsis",
    ()=>BreadcrumbEllipsis,
    "BreadcrumbItem",
    ()=>BreadcrumbItem,
    "BreadcrumbLink",
    ()=>BreadcrumbLink,
    "BreadcrumbList",
    ()=>BreadcrumbList,
    "BreadcrumbPage",
    ()=>BreadcrumbPage,
    "BreadcrumbSeparator",
    ()=>BreadcrumbSeparator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
function Breadcrumb(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        "aria-label": "breadcrumb",
        "data-slot": "breadcrumb",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 8,
        columnNumber: 10
    }, this);
}
_c = Breadcrumb;
function BreadcrumbList(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
        "data-slot": "breadcrumb-list",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground flex flex-wrap items-center gap-1.5 text-sm break-words sm:gap-2.5", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c1 = BreadcrumbList;
function BreadcrumbItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        "data-slot": "breadcrumb-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center gap-1.5", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_c2 = BreadcrumbItem;
function BreadcrumbLink(param) {
    let { asChild, className, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "a";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "breadcrumb-link",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("hover:text-foreground transition-colors", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c3 = BreadcrumbLink;
function BreadcrumbPage(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        "data-slot": "breadcrumb-page",
        role: "link",
        "aria-disabled": "true",
        "aria-current": "page",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-foreground font-normal", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_c4 = BreadcrumbPage;
function BreadcrumbSeparator(param) {
    let { children, className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        "data-slot": "breadcrumb-separator",
        role: "presentation",
        "aria-hidden": "true",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&>svg]:size-3.5", className),
        ...props,
        children: children !== null && children !== void 0 ? children : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {}, void 0, false, {
            fileName: "[project]/components/ui/breadcrumb.tsx",
            lineNumber: 78,
            columnNumber: 20
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
_c5 = BreadcrumbSeparator;
function BreadcrumbEllipsis(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        "data-slot": "breadcrumb-ellipsis",
        role: "presentation",
        "aria-hidden": "true",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex size-9 items-center justify-center", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__["MoreHorizontal"], {
                className: "size-4"
            }, void 0, false, {
                fileName: "[project]/components/ui/breadcrumb.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "sr-only",
                children: "More"
            }, void 0, false, {
                fileName: "[project]/components/ui/breadcrumb.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/breadcrumb.tsx",
        lineNumber: 88,
        columnNumber: 5
    }, this);
}
_c6 = BreadcrumbEllipsis;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6;
__turbopack_context__.k.register(_c, "Breadcrumb");
__turbopack_context__.k.register(_c1, "BreadcrumbList");
__turbopack_context__.k.register(_c2, "BreadcrumbItem");
__turbopack_context__.k.register(_c3, "BreadcrumbLink");
__turbopack_context__.k.register(_c4, "BreadcrumbPage");
__turbopack_context__.k.register(_c5, "BreadcrumbSeparator");
__turbopack_context__.k.register(_c6, "BreadcrumbEllipsis");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/BreadCrumb.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$breadcrumb$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/breadcrumb.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const BreadcrumbWithCustomSeparator = ()=>{
    _s();
    const currentPathName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const pathSegments = currentPathName.split("/").filter(Boolean);
    const breadcrumbs = pathSegments.map((segment, index)=>{
        const href = "/" + pathSegments.slice(0, index + 1).join("/");
        let label = segment.replace("_", " ");
        label = label.toUpperCase();
        return {
            href,
            label
        };
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$breadcrumb$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Breadcrumb"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$breadcrumb$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BreadcrumbList"], {
            children: breadcrumbs.map((crumb, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$breadcrumb$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BreadcrumbItem"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$breadcrumb$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BreadcrumbLink"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: crumb.href,
                            children: crumb.label
                        }, void 0, false, {
                            fileName: "[project]/components/global/BreadCrumb.tsx",
                            lineNumber: 32,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/global/BreadCrumb.tsx",
                        lineNumber: 31,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, i, false, {
                    fileName: "[project]/components/global/BreadCrumb.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/components/global/BreadCrumb.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/global/BreadCrumb.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(BreadcrumbWithCustomSeparator, "+n9emNYV8Ym9dd5J2j8B2GxjaiY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = BreadcrumbWithCustomSeparator;
const __TURBOPACK__default__export__ = BreadcrumbWithCustomSeparator;
var _c;
__turbopack_context__.k.register(_c, "BreadcrumbWithCustomSeparator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/SubHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const SubHeader = (param)=>{
    let { pageTitle, children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-wrap items-center justify-between px-4 py-3 rounded-md shadow-sm border border-gray-200 mb-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-base md:text-lg font-semibold",
                children: pageTitle
            }, void 0, false, {
                fileName: "[project]/components/global/SubHeader.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mt-2 md:mt-0",
                children: children
            }, void 0, false, {
                fileName: "[project]/components/global/SubHeader.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/global/SubHeader.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SubHeader;
const __TURBOPACK__default__export__ = SubHeader;
var _c;
__turbopack_context__.k.register(_c, "SubHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InfoMenu",
    ()=>InfoMenu,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InfoIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as InfoIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const InfoMenu = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { onItemClick } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    ref: ref,
                    size: "icon",
                    variant: "ghost",
                    className: "text-muted-foreground size-8 rounded-full shadow-none",
                    "aria-label": "Information menu",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InfoIcon$3e$__["InfoIcon"], {
                        size: 16,
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                align: "end",
                className: "w-56",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                        children: "Information"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('help'),
                        children: "Help & Support"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('documentation'),
                        children: "Documentation"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('tutorials'),
                        children: "Tutorials"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('feedback'),
                        children: "Send Feedback"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('about'),
                        children: "About"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = InfoMenu;
InfoMenu.displayName = 'InfoMenu';
const __TURBOPACK__default__export__ = InfoMenu;
var _c, _c1;
__turbopack_context__.k.register(_c, "InfoMenu$React.forwardRef");
__turbopack_context__.k.register(_c1, "InfoMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NotificationMenu",
    ()=>NotificationMenu,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-client] (ecmascript) <export default as BellIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const NotificationMenu = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { notifications, onNotificationClick } = param;
    var _notifications_filter_length;
    const unreadCount = (_notifications_filter_length = notifications === null || notifications === void 0 ? void 0 : notifications.filter((n)=>n.unread).length) !== null && _notifications_filter_length !== void 0 ? _notifications_filter_length : 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    ref: ref,
                    size: "icon",
                    variant: "ghost",
                    className: "text-muted-foreground relative size-8 rounded-full shadow-none",
                    "aria-label": "Notifications",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellIcon$3e$__["BellIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: "destructive",
                            className: "absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs",
                            children: unreadCount
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                            lineNumber: 52,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                align: "end",
                className: "w-80",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                        children: "Notifications"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    notifications === null || notifications === void 0 ? void 0 : notifications.map((notification)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                            className: "flex flex-col items-start p-3 cursor-pointer",
                            onClick: ()=>{
                                if (onNotificationClick) {
                                    onNotificationClick(notification);
                                }
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-start justify-between w-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-medium leading-none",
                                                    children: notification.title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                                    lineNumber: 77,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                notification.unread && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-2 w-2 rounded-full bg-blue-600 shrink-0"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                                    lineNumber: 81,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                            lineNumber: 76,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-muted-foreground mt-1 line-clamp-2",
                                            children: notification.message
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                            lineNumber: 84,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-muted-foreground mt-1",
                                            children: notification.time
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                            lineNumber: 87,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                    lineNumber: 75,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                                lineNumber: 74,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, notification.id, false, {
                            fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        className: "text-center justify-center",
                        children: "View all notifications"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = NotificationMenu;
NotificationMenu.displayName = 'NotificationMenu';
const __TURBOPACK__default__export__ = NotificationMenu;
var _c, _c1;
__turbopack_context__.k.register(_c, "NotificationMenu$React.forwardRef");
__turbopack_context__.k.register(_c1, "NotificationMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SettingsMenu",
    ()=>SettingsMenu,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingsIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-client] (ecmascript) <export default as SettingsIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const SettingsMenu = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { onItemClick } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    ref: ref,
                    size: "icon",
                    variant: "ghost",
                    className: "text-muted-foreground size-8 rounded-full shadow-none",
                    "aria-label": "Settings menu",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingsIcon$3e$__["SettingsIcon"], {
                        size: 16,
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                align: "end",
                className: "w-56",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                        children: "Settings"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('preferences'),
                        children: "Preferences"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('appearance'),
                        children: "Appearance"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('privacy'),
                        children: "Privacy & Security"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('integrations'),
                        children: "Integrations"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('api-keys'),
                        children: "API Keys"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                        onClick: ()=>onItemClick === null || onItemClick === void 0 ? void 0 : onItemClick('billing'),
                        children: "Billing"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SettingsMenu;
SettingsMenu.displayName = 'SettingsMenu';
const __TURBOPACK__default__export__ = SettingsMenu;
var _c, _c1;
__turbopack_context__.k.register(_c, "SettingsMenu$React.forwardRef");
__turbopack_context__.k.register(_c1, "SettingsMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/switch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Switch",
    ()=>Switch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-switch/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
function Switch(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "switch",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$switch$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Thumb"], {
            "data-slot": "switch-thumb",
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block size-4 rounded-full ring-0 transition-transform data-[state=checked]:translate-x-[calc(100%-2px)] data-[state=unchecked]:translate-x-0")
        }, void 0, false, {
            fileName: "[project]/components/ui/switch.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/switch.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Switch;
;
var _c;
__turbopack_context__.k.register(_c, "Switch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Table",
    ()=>Table,
    "TableBody",
    ()=>TableBody,
    "TableCaption",
    ()=>TableCaption,
    "TableCell",
    ()=>TableCell,
    "TableFooter",
    ()=>TableFooter,
    "TableHead",
    ()=>TableHead,
    "TableHeader",
    ()=>TableHeader,
    "TableRow",
    ()=>TableRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
function Table(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "table-container",
        className: "relative w-full overflow-x-auto",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
            "data-slot": "table",
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full caption-bottom text-sm", className),
            ...props
        }, void 0, false, {
            fileName: "[project]/components/ui/table.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Table;
function TableHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
        "data-slot": "table-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&_tr]:border-b", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_c1 = TableHeader;
function TableBody(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
        "data-slot": "table-body",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("[&_tr:last-child]:border-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_c2 = TableBody;
function TableFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tfoot", {
        "data-slot": "table-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-muted/50 border-t font-medium [&>tr]:last:border-b-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c3 = TableFooter;
function TableRow(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        "data-slot": "table-row",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("hover:bg-muted/50 data-[state=selected]:bg-muted border-b transition-colors", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
_c4 = TableRow;
function TableHead(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
        "data-slot": "table-head",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-foreground h-10 px-2 text-left align-middle font-medium whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 70,
        columnNumber: 5
    }, this);
}
_c5 = TableHead;
function TableCell(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
        "data-slot": "table-cell",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
}
_c6 = TableCell;
function TableCaption(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("caption", {
        "data-slot": "table-caption",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground mt-4 text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 99,
        columnNumber: 5
    }, this);
}
_c7 = TableCaption;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7;
__turbopack_context__.k.register(_c, "Table");
__turbopack_context__.k.register(_c1, "TableHeader");
__turbopack_context__.k.register(_c2, "TableBody");
__turbopack_context__.k.register(_c3, "TableFooter");
__turbopack_context__.k.register(_c4, "TableRow");
__turbopack_context__.k.register(_c5, "TableHead");
__turbopack_context__.k.register(_c6, "TableCell");
__turbopack_context__.k.register(_c7, "TableCaption");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Can.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Can",
    ()=>Can
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/PermissionContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const Can = (param)=>{
    let { permission, children } = param;
    _s();
    const { permissions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePermissions"])();
    if (!permissions.includes(permission)) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
};
_s(Can, "TEzR9gQK/cojaWJZ3eebiPG/FZA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePermissions"]
    ];
});
_c = Can;
var _c;
__turbopack_context__.k.register(_c, "Can");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/MulitSelectTable.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-table/build/lib/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/table-core/build/lib/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-client] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-client] (ecmascript) <export default as Trash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Can$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Can.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ConfirmationModelsTexts.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
const DataTableDemo = (param)=>{
    let { columns, indexUrl, filterUrl, deleteUrl, searchableColumn, idFeildForEditStateSetter, editModelOpenerStateSetter, idFeildForShowStateSetter, showModelOpenerStateSetter, selectedRowsIdsStateSetter, injectedElement, filtersList, deleteBtnPermission, editBtnPermission, viewPermission } = param;
    var _table_getColumn;
    _s();
    const { reqForToastAndSetMessage, axiosInstance, reloadFlag, reqForConfirmationModelFunc, setGloabalLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    const [loading, setLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](true);
    const [sorting, setSorting] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [columnFilters, setColumnFilters] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [columnVisibility, setColumnVisibility] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    const [rowSelection, setRowSelection] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    const [data, setData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const [filters, setFilters] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    const handleFilterChange = (field, value)=>{
        const newFilters = {
            ...filters,
            [field]: value
        };
        setFilters(newFilters);
    };
    const applyFilters = ()=>{
        setLoading(true);
        axiosInstance.post(filterUrl, filters).then((response)=>{
            setData(response.data.data);
            setLoading(false);
        }).catch((error)=>{
            reqForToastAndSetMessage(error.response.data.message);
            setData([]);
            setLoading(false);
        });
    };
    // Fetch table data
    const fetchTableData = ()=>{
        setLoading(true);
        setGloabalLoading(true);
        axiosInstance.get(indexUrl).then((response)=>{
            setData(response.data.data);
        }).catch((err)=>{
            var _err_response_data, _err_response;
            reqForToastAndSetMessage(((_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || "Failed to fetch data");
            if (err.response.data.data) setData(err.response.data.data);
        }).finally(()=>{
            setLoading(false);
            setGloabalLoading(false);
        });
    };
    // Delete selected rows
    const handleDelete = ()=>{
        const ids = Object.keys(rowSelection).map(Number);
        axiosInstance.post(deleteUrl, {
            ids
        }).then((res)=>{
            reqForToastAndSetMessage(res.data.message);
            fetchTableData();
        }).catch((err)=>{
            var _err_response_data, _err_response;
            return reqForToastAndSetMessage(((_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || "Delete failed");
        });
        setRowSelection({});
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "DataTableDemo.useEffect": ()=>{
            fetchTableData();
        }
    }["DataTableDemo.useEffect"], [
        reloadFlag
    ]);
    // Sync selected row id for edit
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "DataTableDemo.useEffect": ()=>{
            if (idFeildForEditStateSetter) {
                const selectedIds = Object.keys(rowSelection);
                selectedIds.length === 1 ? idFeildForEditStateSetter(Number(selectedIds[0])) : idFeildForEditStateSetter(null);
            }
            if (selectedRowsIdsStateSetter) selectedRowsIdsStateSetter(rowSelection);
        }
    }["DataTableDemo.useEffect"], [
        rowSelection
    ]);
    const table = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactTable"])({
        data,
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCoreRowModel"])(),
        getPaginationRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPaginationRowModel"])(),
        getSortedRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSortedRowModel"])(),
        getFilteredRowModel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$table$2d$core$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilteredRowModel"])(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        getRowId: {
            "DataTableDemo.useReactTable[table]": (row)=>row.id.toString()
        }["DataTableDemo.useReactTable[table]"],
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection
        }
    });
    var _ref;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center py-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                        placeholder: "Search By ".concat(searchableColumn),
                        value: (_ref = (_table_getColumn = table.getColumn(searchableColumn)) === null || _table_getColumn === void 0 ? void 0 : _table_getColumn.getFilterValue()) !== null && _ref !== void 0 ? _ref : "",
                        onChange: (e)=>{
                            var _table_getColumn;
                            return (_table_getColumn = table.getColumn(searchableColumn)) === null || _table_getColumn === void 0 ? void 0 : _table_getColumn.setFilterValue(e.target.value);
                        },
                        className: "max-w-sm"
                    }, void 0, false, {
                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                        lineNumber: 217,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row items-center gap-2",
                        children: [
                            injectedElement && Object.keys(rowSelection).length == 1 && injectedElement,
                            Object.keys(rowSelection).length === 1 && editModelOpenerStateSetter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Can$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Can"], {
                                permission: editBtnPermission !== null && editBtnPermission !== void 0 ? editBtnPermission : "ok",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>editModelOpenerStateSetter(true),
                                    variant: "outline",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {}, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 241,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                    lineNumber: 237,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 236,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            deleteUrl && Object.keys(rowSelection).length >= 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Can$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Can"], {
                                permission: deleteBtnPermission !== null && deleteBtnPermission !== void 0 ? deleteBtnPermission : "ok",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        reqForConfirmationModelFunc(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DeleteButtonMessage"], handleDelete);
                                    },
                                    variant: "outline",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__["Trash"], {
                                        color: "red"
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 257,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                    lineNumber: 248,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 247,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "outline",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {}, void 0, false, {
                                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                lineNumber: 266,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 265,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 264,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                                        className: "w-80 max-h-[350px] overflow-auto",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                            className: "leading-none font-medium",
                                                            children: "Dimensions"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                            lineNumber: 272,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-muted-foreground text-sm",
                                                            children: "Filter Projects."
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                            lineNumber: 273,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                    lineNumber: 271,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid gap-2",
                                                    children: [
                                                        filtersList === null || filtersList === void 0 ? void 0 : filtersList.map((filter, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "grid grid-cols-3 items-center gap-4",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                        htmlFor: filter,
                                                                        children: filter
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                                        lineNumber: 283,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                        id: filter,
                                                                        name: filter,
                                                                        className: "col-span-2 h-8",
                                                                        onChange: (e)=>handleFilterChange(e.target.name, e.target.value)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                                        lineNumber: 284,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, i, true, {
                                                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                                lineNumber: 279,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "grid grid-cols-3 items-center gap-4",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                onClick: applyFilters,
                                                                children: "Apply"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                                lineNumber: 295,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                            lineNumber: 294,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                    lineNumber: 277,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 270,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 269,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 263,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "outline",
                                            children: [
                                                "Columns ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {}, void 0, false, {
                                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                    lineNumber: 306,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 305,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 304,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                                        align: "end",
                                        children: table.getAllColumns().filter((col)=>col.getCanHide()).map((col)=>{
                                            const visibleColumns = table.getAllColumns().filter((c)=>c.getCanHide() && c.getIsVisible());
                                            const maxVisible = 8;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuCheckboxItem"], {
                                                className: "capitalize",
                                                checked: col.getIsVisible(),
                                                onCheckedChange: (value)=>{
                                                    if (value && visibleColumns.length >= maxVisible) {
                                                        return;
                                                    }
                                                    col.toggleVisibility(!!value);
                                                },
                                                children: col.id
                                            }, col.id, false, {
                                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                lineNumber: 320,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0));
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                                        lineNumber: 309,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 303,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                        lineNumber: 229,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/global/MulitSelectTable.tsx",
                lineNumber: 216,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-hidden rounded-md border",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Table"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHeader"], {
                            children: table.getHeaderGroups().map((headerGroup)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                    children: headerGroup.headers.slice(0, 8).map((header)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                            children: header.isPlaceholder ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flexRender"])(header.column.columnDef.header, header.getContext())
                                        }, header.id, false, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 347,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, headerGroup.id, false, {
                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                    lineNumber: 345,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                            lineNumber: 343,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableBody"], {
                            children: loading ? Array.from({
                                length: 10
                            }).map((_, rowIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                    children: columns.slice(0, 8).map((col, colIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                                                className: "h-4 w-full"
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                                lineNumber: 367,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, colIndex, false, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 366,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, rowIndex, false, {
                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                    lineNumber: 364,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))) : table.getRowModel().rows.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                    className: "cursor-pointer",
                                    onClick: (e)=>{
                                        const target = e.target;
                                        if (target.closest("input[type='checkbox']") || target.closest("button") || target.closest("label") || target.closest("svg")) return;
                                        if (idFeildForShowStateSetter) idFeildForShowStateSetter(Number(row.id));
                                        if (showModelOpenerStateSetter) showModelOpenerStateSetter(true);
                                    },
                                    children: row.getVisibleCells().slice(0, 8).map((cell)=>{
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flexRender"])(cell.column.columnDef.cell, cell.getContext())
                                        }, cell.id, false, {
                                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                                            lineNumber: 397,
                                            columnNumber: 27
                                        }, ("TURBOPACK compile-time value", void 0));
                                    })
                                }, row.id, false, {
                                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                                    lineNumber: 373,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/components/global/MulitSelectTable.tsx",
                            lineNumber: 360,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/MulitSelectTable.tsx",
                    lineNumber: 342,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/global/MulitSelectTable.tsx",
                lineNumber: 341,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-end space-x-2 py-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-muted-foreground flex-1 text-sm",
                        children: [
                            table.getFilteredSelectedRowModel().rows.length,
                            " of",
                            " ",
                            table.getFilteredRowModel().rows.length,
                            " row(s) selected."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                        lineNumber: 413,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>table.previousPage(),
                                disabled: !table.getCanPreviousPage(),
                                children: "Previous"
                            }, void 0, false, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 418,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>table.nextPage(),
                                disabled: !table.getCanNextPage(),
                                children: "Next"
                            }, void 0, false, {
                                fileName: "[project]/components/global/MulitSelectTable.tsx",
                                lineNumber: 426,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/MulitSelectTable.tsx",
                        lineNumber: 417,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/global/MulitSelectTable.tsx",
                lineNumber: 412,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/global/MulitSelectTable.tsx",
        lineNumber: 214,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DataTableDemo, "z0y4AnXV/HVmrzMEsn53+xdFWgA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$table$2f$build$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useReactTable"]
    ];
});
_c = DataTableDemo;
const __TURBOPACK__default__export__ = DataTableDemo;
var _c;
__turbopack_context__.k.register(_c, "DataTableDemo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/shadcn-io/submitSummary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$MulitSelectTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/global/MulitSelectTable.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$definitions$2f$DataTableColumnsDefinitions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/definitions/DataTableColumnsDefinitions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const SubmitSummary = (param)=>{
    let { open, onOpenChange, databaseId } = param;
    var _databaseDetails_find;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    let [reqForPermissionUpdateForm, setReqForPermissionUpdateForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let [idFeildForEditStateSetter, setIdFeildForEditStateSetter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const status = "Pending Approval";
    const [databaseDetails, setDatabaseDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [projectDetails, setProjectDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SubmitSummary.useEffect": ()=>{
            if (databaseId) axiosInstance.get("/db_management/show_database/".concat(databaseId)).then({
                "SubmitSummary.useEffect": (response)=>{
                    setDatabaseDetails([
                        {
                            label: "Database",
                            value: response.data.data.database
                        },
                        {
                            label: "Province",
                            value: "".concat(response.data.data.province)
                        },
                        {
                            label: "Date",
                            value: "".concat(response.data.data.fromDate, " → ").concat(response.data.data.toDate)
                        },
                        {
                            label: "Submitted by",
                            value: "Mosa Baregzay"
                        }
                    ]);
                    setProjectDetails([
                        {
                            label: "Project",
                            value: "".concat(response.data.data.project.projectCode)
                        },
                        {
                            label: "Outcome",
                            value: response.data.data.numOfOutcomes
                        },
                        {
                            label: "Output",
                            value: response.data.data.numOfOutputs
                        },
                        {
                            label: "Indicator",
                            value: response.data.data.numOfIndicators
                        }
                    ]);
                }
            }["SubmitSummary.useEffect"]).catch({
                "SubmitSummary.useEffect": (error)=>reqForToastAndSetMessage(error.response.data.message)
            }["SubmitSummary.useEffect"]);
        }
    }["SubmitSummary.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: open,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "sm:max-w-4xl border border-gray-300 dark:border-gray-600 rounded-lg ml-16 overflow-y-auto",
            style: {
                maxHeight: "80vh",
                paddingTop: "10px",
                paddingBottom: "10px",
                paddingLeft: "16px",
                paddingRight: "16px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify- mb-2 relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                className: "text-lg",
                                children: "Database Summary"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 absolute left-1/2 transform -translate-x-1/2 w-1/2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                placeholder: "Search...",
                                className: "h-8 w-60 ml-auto mr-auto"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                    lineNumber: 75,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-sm text-muted-foreground mb-4",
                    children: "Summary of selected database"
                }, void 0, false, {
                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                    lineNumber: 89,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-3 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex w-full gap-3",
                            children: databaseDetails && databaseDetails.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 dark:from-gray-700 dark:via-gray-800 dark:to-gray-700 rounded-lg px-4 py-3 text-sm shadow-sm flex flex-col items-center justify-center text-center transition hover:shadow-md",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold",
                                            children: item.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                            lineNumber: 102,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        (()=>{
                                            if (item.label == "project" && typeof item.value == "object") {
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mt-1",
                                                    children: "item.value.name"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 30
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mt-1",
                                                children: item.value
                                            }, void 0, false, {
                                                fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                                lineNumber: 108,
                                                columnNumber: 28
                                            }, ("TURBOPACK compile-time value", void 0));
                                        })()
                                    ]
                                }, item.label, true, {
                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                    lineNumber: 98,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex w-full gap-3",
                            children: projectDetails && projectDetails.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "flex-1 bg-gradient-to-r from-gray-50 via-gray-100 to-gray-50 dark:from-gray-800 dark:via-gray-700 dark:to-gray-800 rounded-lg px-4 py-3 text-sm flex flex-col items-center justify-center text-center transition",
                                    type: "button",
                                    title: item.label == "project" || item.label == "Submitted By" ? "Click for more details" : undefined,
                                    onClick: (()=>{
                                        if (item.label == "project" && typeof item.value == "object") return ()=>router.push("/projects/show_project/".concat(item.value));
                                        return undefined;
                                    })(),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold",
                                            children: item.label
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                            lineNumber: 132,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        (()=>{
                                            if (item.label == "project" && typeof item.value == "object") {
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: item.value.projectCode
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                                    lineNumber: 135,
                                                    columnNumber: 28
                                                }, ("TURBOPACK compile-time value", void 0));
                                            }
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mt-1",
                                                children: item.value
                                            }, void 0, false, {
                                                fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                                lineNumber: 138,
                                                columnNumber: 26
                                            }, ("TURBOPACK compile-time value", void 0));
                                        })()
                                    ]
                                }, item.label, true, {
                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                    lineNumber: 118,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 116,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                databaseDetails && ((_databaseDetails_find = databaseDetails.find((item)=>item.label == "Database")) === null || _databaseDetails_find === void 0 ? void 0 : _databaseDetails_find.value) != "psychoeducation_database" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-3 w-full rounded-md bg-muted/50 px-4 py-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold",
                                    children: "List of Beneficiaries"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                    lineNumber: 149,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs font-medium px-2 py-1 rounded-md bg-gray-200 dark:bg-gray-700",
                                    children: status
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                    lineNumber: 150,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 148,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$global$2f$MulitSelectTable$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                columns: __TURBOPACK__imported__module__$5b$project$5d2f$definitions$2f$DataTableColumnsDefinitions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["permissionColumns"],
                                indexUrl: "user_mng/permissions",
                                deleteUrl: "user_mng/delete_permissions",
                                searchableColumn: "name",
                                idFeildForEditStateSetter: setIdFeildForEditStateSetter,
                                editModelOpenerStateSetter: setReqForPermissionUpdateForm
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                                lineNumber: 157,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
                            lineNumber: 156,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
            lineNumber: 64,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ui/shadcn-io/submitSummary.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SubmitSummary, "BBS8AVaORgrHHwgC8/UVwq0yVjo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"]
    ];
});
_c = SubmitSummary;
const __TURBOPACK__default__export__ = SubmitSummary;
var _c;
__turbopack_context__.k.register(_c, "SubmitSummary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/shadcn-io/navbar-14/index.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Navbar14",
    ()=>Navbar14
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGridIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-grid.js [app-client] (ecmascript) <export default as LayoutGridIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$InfoMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/InfoMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$NotificationMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/NotificationMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$SettingsMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/navbar-14/SettingsMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/switch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/sidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$submitSummary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/shadcn-io/submitSummary.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const Navbar14 = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = _s((param, ref)=>{
    let { className, searchPlaceholder = "Search...", searchValue, showTestMode = true, onSearchChange, onLayoutClick, onInfoItemClick, ...props } = param;
    _s();
    const { notifications, setNotifications, axiosInstance, reqForToastAndSetMessage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const { theme, setTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const isDark = theme === "dark";
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(searchValue || "");
    const [searchResults, setSearchResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [reqForSubmittedDatabaseSummary, setReqForSubmittedDatabaseSummary] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [databaseId, setDatabaseId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar14.useEffect": ()=>{
            setMounted(true);
        }
    }["Navbar14.useEffect"], []);
    if (!mounted) return null;
    const webSiteContentList = [
        {
            contentTitle: "Dashboard",
            contentUrl: "/"
        },
        {
            contentTitle: "Projects",
            contentUrl: "/projects"
        },
        {
            contentTitle: "Create New Project",
            contentUrl: "/create_new_project"
        },
        {
            contentTitle: "Main Database",
            contentUrl: "/main_db"
        },
        {
            contentTitle: "Kit Distribution",
            contentUrl: "/kit"
        },
        {
            contentTitle: "Psychoeducation",
            contentUrl: "/psychoeducation"
        },
        {
            contentTitle: "Community Dialogue",
            contentUrl: "/community_dialogue"
        },
        {
            contentTitle: "Training",
            contentUrl: "/training"
        },
        {
            contentTitle: "Referral",
            contentUrl: "/referral"
        },
        {
            contentTitle: "Settings",
            contentUrl: "/settings"
        },
        {
            contentTitle: "Notifications",
            contentUrl: "/notifications"
        }
    ];
    const handleGlobalSearch = (e)=>{
        const value = e.target.value;
        setSearchQuery(value);
        if (!value) {
            setSearchResults([]);
            return;
        }
        const filtered = webSiteContentList.filter((item)=>item.contentTitle.toLowerCase().includes(value.toLowerCase()));
        setSearchResults(filtered);
        onSearchChange === null || onSearchChange === void 0 ? void 0 : onSearchChange(value);
    };
    const onNotificationClick = (notification)=>{
        axiosInstance.post("/notification/mark_as_read/".concat(notification.id)).then((response)=>setNotifications((prev)=>prev.map((n)=>n.id == notification.id ? {
                        ...n,
                        unread: !n.unread
                    } : {}))).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
        switch(notification.type){
            case "project":
                if (notification.project_id) router.push("/projects/project_show/".concat(notification.project_id));
                break;
            case "submittedDatabase":
                if (notification.apr_id) {
                    setDatabaseId(notification.apr_id);
                    setReqForSubmittedDatabaseSummary(true);
                }
                break;
            case "approvedDatabase":
                if (notification.apr_id) setDatabaseId(notification.apr_id);
                setReqForSubmittedDatabaseSummary(true);
                break;
            case "reviewdApr":
                if (notification.apr_id) setDatabaseId(notification.apr_id);
                setReqForSubmittedDatabaseSummary(true);
                break;
            case "approvedApr":
                if (notification.apr_id) setDatabaseId(notification.apr_id);
                setReqForSubmittedDatabaseSummary(true);
                break;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-b px-4 md:px-2 [&_*]:no-underline", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-16 items-center w-full justify-between gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative flex-1",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-row relative w-full max-w-xs",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SidebarTrigger"], {}, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                lineNumber: 171,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "input-".concat(id),
                                className: "peer h-8 w-full ps-8 pe-2",
                                placeholder: searchPlaceholder,
                                type: "search",
                                value: searchQuery,
                                onChange: handleGlobalSearch
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                lineNumber: 172,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            searchResults.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                                className: "absolute top-full left-0 mt-1 w-full max-h-64 overflow-auto z-50 shadow",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                    className: "p-0",
                                    children: searchResults.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "px-4 py-2 hover:bg-gray-100 cursor-pointer",
                                            onClick: ()=>{
                                                setSearchQuery("");
                                                setSearchResults([]);
                                                router.push(item.contentUrl);
                                            },
                                            children: item.contentTitle
                                        }, idx, false, {
                                            fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                            lineNumber: 184,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 182,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                lineNumber: 181,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                        lineNumber: 170,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                    lineNumber: 168,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        showTestMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-flex items-center gap-2 max-md:hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "switch-".concat(id),
                                    className: "text-sm font-medium",
                                    children: "Dark Mode"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 206,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Switch"], {
                                    id: "switch-".concat(id),
                                    defaultChecked: isDark,
                                    onCheckedChange: ()=>setTheme(isDark ? "light" : "dark"),
                                    className: "h-5 w-8 [&_span]:size-4 data-[state=checked]:[&_span]:translate-x-3 data-[state=checked]:[&_span]:rtl:-translate-x-3",
                                    "aria-label": "Toggle dark mode"
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 209,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                            lineNumber: 205,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    size: "icon",
                                    variant: "ghost",
                                    className: "text-muted-foreground size-8 rounded-full shadow-none",
                                    "aria-label": "Open layout menu",
                                    onClick: (e)=>{
                                        e.preventDefault();
                                        onLayoutClick === null || onLayoutClick === void 0 ? void 0 : onLayoutClick();
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGridIcon$3e$__["LayoutGridIcon"], {
                                        size: 16,
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                        lineNumber: 229,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 219,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$InfoMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onItemClick: onInfoItemClick
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 231,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$navbar$2d$14$2f$NotificationMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    notifications: notifications,
                                    onNotificationClick: onNotificationClick
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                                    lineNumber: 232,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                            lineNumber: 218,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                    lineNumber: 203,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                reqForSubmittedDatabaseSummary && databaseId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$shadcn$2d$io$2f$submitSummary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    open: reqForSubmittedDatabaseSummary,
                    onOpenChange: setReqForSubmittedDatabaseSummary,
                    databaseId: databaseId
                }, void 0, false, {
                    fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
                    lineNumber: 239,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
            lineNumber: 166,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ui/shadcn-io/navbar-14/index.tsx",
        lineNumber: 161,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
}, "XG5wm+/F3o4z6avBitmpNwQMb/A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
})), "XG5wm+/F3o4z6avBitmpNwQMb/A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c1 = Navbar14;
Navbar14.displayName = "Navbar14";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Navbar14$React.forwardRef");
__turbopack_context__.k.register(_c1, "Navbar14");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/tabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
function Tabs(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "tabs",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Tabs;
function TabsList(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"], {
        "data-slot": "tabs-list",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_c1 = TabsList;
function TabsTrigger(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "tabs-trigger",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_c2 = TabsTrigger;
function TabsContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        "data-slot": "tabs-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex-1 outline-none", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/tabs.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_c3 = TabsContent;
;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "Tabs");
__turbopack_context__.k.register(_c1, "TabsList");
__turbopack_context__.k.register(_c2, "TabsTrigger");
__turbopack_context__.k.register(_c3, "TabsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Textarea",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
;
;
function Textarea(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        "data-slot": "textarea",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/textarea.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Textarea;
;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/multi-select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MultiSelect",
    ()=>MultiSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$up$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsUpDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevrons-up-down.js [app-client] (ecmascript) <export default as ChevronsUpDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/command.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/badge.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function MultiSelect(param) {
    let { options, value, onValueChange, placeholder = "Select...", disabled = false, error } = param;
    _s();
    const [open, setOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const selectedOptions = options.filter((opt)=>value === null || value === void 0 ? void 0 : value.includes(opt.value));
    const toggleOption = (val)=>{
        if (disabled) return;
        if (!onValueChange) return;
        if (value.includes(val)) {
            onValueChange(value.filter((v)=>v !== val));
        } else {
            onValueChange([
                ...value,
                val
            ]);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
        open: open,
        onOpenChange: setOpen,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "outline",
                    role: "combobox",
                    "aria-expanded": open,
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(// use strong overrides to beat global css
                    "w-full justify-between text-left", // if there's an error, force a visible red border and ring
                    error ? "!border-2 !border-red-500 focus:!ring-red-200 focus:!ring-4" : "!border !border-[var(--border)]", disabled && "opacity-60 cursor-not-allowed"),
                    title: error ? error : undefined,
                    disabled: disabled,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-1 max-h-16 overflow-auto",
                            children: selectedOptions.length > 0 ? selectedOptions.map((opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                    variant: "secondary",
                                    children: opt.label
                                }, opt.value, false, {
                                    fileName: "[project]/components/multi-select.tsx",
                                    lineNumber: 81,
                                    columnNumber: 17
                                }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-muted-foreground",
                                children: placeholder
                            }, void 0, false, {
                                fileName: "[project]/components/multi-select.tsx",
                                lineNumber: 86,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/multi-select.tsx",
                            lineNumber: 78,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$up$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsUpDown$3e$__["ChevronsUpDown"], {
                            className: "ml-2 h-4 w-4 shrink-0 opacity-50"
                        }, void 0, false, {
                            fileName: "[project]/components/multi-select.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/multi-select.tsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/multi-select.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            !disabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                className: "w-[300px] p-0 max-h-64 overflow-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandInput"], {
                            placeholder: "Search..."
                        }, void 0, false, {
                            fileName: "[project]/components/multi-select.tsx",
                            lineNumber: 95,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandEmpty"], {
                            children: "No results found."
                        }, void 0, false, {
                            fileName: "[project]/components/multi-select.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
                            children: options.map((opt)=>{
                                const isSelected = value === null || value === void 0 ? void 0 : value.includes(opt.value);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$command$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                    onSelect: ()=>toggleOption(opt.value),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary", isSelected ? "bg-primary text-primary-foreground" : ""),
                                            children: isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                className: "h-3 w-3"
                                            }, void 0, false, {
                                                fileName: "[project]/components/multi-select.tsx",
                                                lineNumber: 111,
                                                columnNumber: 38
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/multi-select.tsx",
                                            lineNumber: 105,
                                            columnNumber: 21
                                        }, this),
                                        opt.label
                                    ]
                                }, opt.value, true, {
                                    fileName: "[project]/components/multi-select.tsx",
                                    lineNumber: 101,
                                    columnNumber: 19
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/components/multi-select.tsx",
                            lineNumber: 97,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/multi-select.tsx",
                    lineNumber: 94,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/multi-select.tsx",
                lineNumber: 93,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/multi-select.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(MultiSelect, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = MultiSelect;
var _c;
__turbopack_context__.k.register(_c, "MultiSelect");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/OutcomeEditModel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/FormsSchema.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ConfirmationModelsTexts.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/FormsDefaultValues.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const OutcomeModel = (param)=>{
    let { isOpen, onOpenChange, outcomeId, mode, pageIdentifier } = param;
    _s();
    const { reqForToastAndSetMessage, reqForConfirmationModelFunc, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { outcomes, setOutcomes, projectId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreatePage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditPage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutcomeDefault"])());
    const [formErrors, setFormErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleFormChange = (e)=>{
        const name = e.target.name;
        const value = e.target.value;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = ()=>{
        const result = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutcomeFormSchema"].safeParse(formData);
        if (!result.success) {
            const errors = {};
            result.error.issues.forEach((issue)=>{
                const field = issue.path[0];
                if (field) errors[field] = issue.message;
            });
            setFormErrors(errors);
            reqForToastAndSetMessage("Please fix validation errors before submitting.");
            return;
        }
        setFormErrors({});
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsThereAnyOutcomeWithEnteredReferance"])(outcomes, formData)) {
            reqForToastAndSetMessage("A project can not have two outcomes with same referance !");
            return;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsThereAnyOutcomeWithEnteredReferanceAndDefferentId"])(outcomes, formData)) {
            reqForToastAndSetMessage("A project can not have two outcomes with same referance !");
            return;
        }
        setIsLoading(true);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode)) {
            axiosInstance.post("/projects/o/outcome", {
                project_id: projectId,
                outcome: formData.outcome,
                outcomeRef: formData.outcomeRef
            }).then((response)=>{
                reqForToastAndSetMessage(response.data.message);
                setOutcomes((prev)=>[
                        ...prev,
                        response.data.data
                    ]);
            }).catch((error)=>{
                reqForToastAndSetMessage(error.response.data.message);
            });
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode)) axiosInstance.put("projects/outcome/".concat(outcomeId), {
            outcome: formData.outcome,
            outcomeRef: formData.outcomeRef
        }).then((response)=>{
            reqForToastAndSetMessage(response.data.message);
            setOutcomes((prev)=>prev.map((o)=>o.outcomeRef == formData.outcomeRef ? {
                        ...o,
                        outcome: formData.outcome,
                        outcomeRef: formData.outcomeRef
                    } : o));
        }).catch((error)=>reqForToastAndSetMessage(error.response.data.message)).finally(()=>setIsLoading(false));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutcomeModel.useEffect": ()=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditOrShowMode"])(mode) && outcomeId) {
                setIsLoading(true);
                axiosInstance.get("/projects/outcome/".concat(outcomeId)).then({
                    "OutcomeModel.useEffect": (response)=>setFormData(response.data.data)
                }["OutcomeModel.useEffect"]).catch({
                    "OutcomeModel.useEffect": (error)=>reqForToastAndSetMessage(error.response.data.message)
                }["OutcomeModel.useEffect"]).finally({
                    "OutcomeModel.useEffect": ()=>setIsLoading(false)
                }["OutcomeModel.useEffect"]);
            }
        }
    }["OutcomeModel.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: isOpen,
        onOpenChange: ()=>onOpenChange(false),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-w-lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                        children: mode == "create" ? "Create New Outcome" : mode == "edit" ? "Edit Outcome" : "Show Outcome"
                    }, void 0, false, {
                        fileName: "[project]/components/global/OutcomeEditModel.tsx",
                        lineNumber: 121,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                    lineNumber: 120,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "outcome",
                                    children: "Outcome"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                    lineNumber: 126,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                                    id: "outcome",
                                    name: "outcome",
                                    value: formData.outcome,
                                    onChange: handleFormChange,
                                    disabled: mode == "show",
                                    className: "border p-2 rounded ".concat(formErrors.outcome ? "!border-red-500" : ""),
                                    title: formErrors.projectCode
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                    lineNumber: 127,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/OutcomeEditModel.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "outcomeRef",
                                    children: "Outcome Reference"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                    lineNumber: 139,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                    id: "outcomeRef",
                                    name: "outcomeRef",
                                    value: formData.outcomeRef,
                                    onChange: handleFormChange,
                                    disabled: mode == "show",
                                    className: "border p-2 rounded ".concat(formErrors.outcomeRef ? "!border-red-500" : ""),
                                    title: formErrors.projectCode
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                    lineNumber: 140,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/OutcomeEditModel.tsx",
                            lineNumber: 138,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                    lineNumber: 124,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                mode != "show" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogFooter"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 w-full justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                onClick: ()=>onOpenChange(false),
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                lineNumber: 155,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>reqForConfirmationModelFunc(mode == "create" ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutcomeCreationMessage"] : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutcomeEditionMessage"], handleSubmit),
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/components/global/OutcomeEditModel.tsx",
                                lineNumber: 161,
                                columnNumber: 21
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/OutcomeEditModel.tsx",
                        lineNumber: 154,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/OutcomeEditModel.tsx",
                    lineNumber: 153,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/global/OutcomeEditModel.tsx",
            lineNumber: 119,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/global/OutcomeEditModel.tsx",
        lineNumber: 118,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_s(OutcomeModel, "uU5Ne1OqyCuW7aCssbPSeQYD1Uw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"]
    ];
});
_c = OutcomeModel;
const __TURBOPACK__default__export__ = OutcomeModel;
var _c;
__turbopack_context__.k.register(_c, "OutcomeModel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/accordion.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Accordion",
    ()=>Accordion,
    "AccordionContent",
    ()=>AccordionContent,
    "AccordionItem",
    ()=>AccordionItem,
    "AccordionTrigger",
    ()=>AccordionTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-accordion/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
function Accordion(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "accordion",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/accordion.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
_c = Accordion;
function AccordionItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"], {
        "data-slot": "accordion-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-b last:border-b-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/accordion.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c1 = AccordionItem;
function AccordionTrigger(param) {
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"], {
        className: "flex",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
            "data-slot": "accordion-trigger",
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("focus-visible:border-ring focus-visible:ring-ring/50 flex flex-1 items-start justify-between gap-4 rounded-md py-4 text-left text-sm font-medium transition-all outline-none hover:underline focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&[data-state=open]>svg]:rotate-180", className),
            ...props,
            children: [
                children,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
                    className: "text-muted-foreground pointer-events-none size-4 shrink-0 translate-y-0.5 transition-transform duration-200"
                }, void 0, false, {
                    fileName: "[project]/components/ui/accordion.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ui/accordion.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/accordion.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_c2 = AccordionTrigger;
function AccordionContent(param) {
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$accordion$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        "data-slot": "accordion-content",
        className: "data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down overflow-hidden text-sm",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pt-0 pb-4", className),
            children: children
        }, void 0, false, {
            fileName: "[project]/components/ui/accordion.tsx",
            lineNumber: 61,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/accordion.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_c3 = AccordionContent;
;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "Accordion");
__turbopack_context__.k.register(_c1, "AccordionItem");
__turbopack_context__.k.register(_c2, "AccordionTrigger");
__turbopack_context__.k.register(_c3, "AccordionContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/OutputEditModel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ConfirmationModelsTexts.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/FormsDefaultValues.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/single-select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/schemas/FormsSchema.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const OutputModel = (param)=>{
    let { isOpen, onOpenChange, mode, pageIdentifier, outputId } = param;
    _s();
    const { reqForConfirmationModelFunc, reqForToastAndSetMessage, axiosInstance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { outcomes, outputs, setOutputs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreatePage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditPage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"])();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutputDefault"])());
    const [formErrors, setFormErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const handleFormChange = (e)=>{
        const name = e.target.name;
        const value = e.target.value;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = ()=>{
        const result = __TURBOPACK__imported__module__$5b$project$5d2f$schemas$2f$FormsSchema$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutputFormSchema"].safeParse(formData);
        if (!result.success) {
            const errors = {};
            result.error.issues.forEach((issue)=>{
                const field = issue.path[0];
                if (field) errors[field] = issue.message;
            });
            setFormErrors(errors);
            reqForToastAndSetMessage("Please fix validation errors before submitting.");
            return;
        }
        setFormErrors({});
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsThereAnyOutputWithEnteredReferance"])(outputs, formData.outputRef)) {
            reqForToastAndSetMessage("A project can not have two output with same referance !");
            return;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsThereAnyOutputWithEnteredReferanceAndDefferentId"])(outputs, formData)) {
            reqForToastAndSetMessage("A project can not have two output with same referance !");
            return;
        }
        setIsLoading(true);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode)) axiosInstance.post("/projects/o/output", formData).then((response)=>{
            reqForToastAndSetMessage(response.data.message);
            setOutputs((prev)=>[
                    ...prev,
                    {
                        ...formData,
                        id: response.data.data.id
                    }
                ]);
        }).catch((error)=>{
            reqForToastAndSetMessage(error.response.data.message);
        }).finally(()=>setIsLoading(false));
        else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode)) axiosInstance.put("/projects/output/".concat(outputId), formData).then((response)=>{
            reqForToastAndSetMessage(response.data.message);
            setOutputs((prev)=>prev.map((output)=>output.id == formData.id ? formData : output));
        }).catch((error)=>reqForToastAndSetMessage(error.response.data.message)).finally(()=>setIsLoading(false));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutputModel.useEffect": ()=>{
            if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)) && outputId) {
                setIsLoading(true);
                axiosInstance.get("projects/output/".concat(outputId)).then({
                    "OutputModel.useEffect": (response)=>{
                        /* eslint-disable */ console.log(...oo_oo("3591013253_152_10_152_41_4", response.data.data));
                        setFormData(response.data.data);
                    }
                }["OutputModel.useEffect"]).catch({
                    "OutputModel.useEffect": (error)=>reqForToastAndSetMessage(error.response.data.message)
                }["OutputModel.useEffect"]).finally({
                    "OutputModel.useEffect": ()=>setIsLoading(false)
                }["OutputModel.useEffect"]);
            }
        }
    }["OutputModel.useEffect"], []);
    var _formData_outcomeId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: isOpen,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-w-lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? "Create New Output" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) ? "Edit Output" : "Show Output"
                    }, void 0, false, {
                        fileName: "[project]/components/global/OutputEditModel.tsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/OutputEditModel.tsx",
                    lineNumber: 165,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "outputRef",
                                    children: "Outcome Reference"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 177,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                    options: outcomes.filter((outcome)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsOutcomeSaved"])(outcome)).map((outcome)=>({
                                            value: outcome.id,
                                            label: outcome.outcomeRef
                                        })),
                                    value: (_formData_outcomeId = formData.outcomeId) !== null && _formData_outcomeId !== void 0 ? _formData_outcomeId : "Unknown value",
                                    onValueChange: (value)=>setFormData((prev)=>({
                                                ...prev,
                                                outcomeId: value
                                            })),
                                    error: formErrors.outcomeId
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/OutputEditModel.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "output",
                                    children: "Output"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 197,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                                    id: "output",
                                    name: "output",
                                    value: formData.output,
                                    onChange: handleFormChange,
                                    disabled: mode == "show",
                                    className: "border p-2 rounded ".concat(formErrors.output ? "!border-red-500" : ""),
                                    title: formErrors.output
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 198,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/OutputEditModel.tsx",
                            lineNumber: 196,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "outputRef",
                                    children: "Output Reference"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 212,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                    id: "outputRef",
                                    name: "outputRef",
                                    value: formData.outputRef,
                                    onChange: handleFormChange,
                                    disabled: mode == "show",
                                    className: "border p-2 rounded ".concat(formErrors.outputRef ? "!border-red-500" : ""),
                                    title: formErrors.outputRef
                                }, void 0, false, {
                                    fileName: "[project]/components/global/OutputEditModel.tsx",
                                    lineNumber: 213,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/OutputEditModel.tsx",
                            lineNumber: 211,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/OutputEditModel.tsx",
                    lineNumber: 175,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogFooter"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 w-full justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                onClick: ()=>onOpenChange(false),
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/components/global/OutputEditModel.tsx",
                                lineNumber: 230,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>reqForConfirmationModelFunc((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutputCreationMessage"] : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OutputEditionMessage"], handleSubmit),
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/components/global/OutputEditModel.tsx",
                                lineNumber: 233,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/OutputEditModel.tsx",
                        lineNumber: 229,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/OutputEditModel.tsx",
                    lineNumber: 228,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/global/OutputEditModel.tsx",
            lineNumber: 164,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/global/OutputEditModel.tsx",
        lineNumber: 163,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(OutputModel, "7qHcY1ypGxPuw1arz6oPSk570uk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"]
    ];
});
_c = OutputModel;
const __TURBOPACK__default__export__ = OutputModel;
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5a41(_0xa94ba2,_0x20bcf7){var _0x46c9d4=_0x46c9();return _0x5a41=function(_0x5a41b7,_0x432119){_0x5a41b7=_0x5a41b7-0xc2;var _0x4ff83e=_0x46c9d4[_0x5a41b7];return _0x4ff83e;},_0x5a41(_0xa94ba2,_0x20bcf7);}var _0x1fc135=_0x5a41;(function(_0x12841d,_0x45ce02){var _0x463f09=_0x5a41,_0x3aed6f=_0x12841d();while(!![]){try{var _0xfbec5f=parseInt(_0x463f09(0x164))/0x1+-parseInt(_0x463f09(0x1c3))/0x2*(parseInt(_0x463f09(0x1ae))/0x3)+parseInt(_0x463f09(0xed))/0x4+-parseInt(_0x463f09(0x10e))/0x5+-parseInt(_0x463f09(0x132))/0x6*(-parseInt(_0x463f09(0xf4))/0x7)+-parseInt(_0x463f09(0x1bf))/0x8*(parseInt(_0x463f09(0x149))/0x9)+-parseInt(_0x463f09(0x158))/0xa*(-parseInt(_0x463f09(0x181))/0xb);if(_0xfbec5f===_0x45ce02)break;else _0x3aed6f['push'](_0x3aed6f['shift']());}catch(_0x1ddfc0){_0x3aed6f['push'](_0x3aed6f['shift']());}}}(_0x46c9,0xc9a1b));function z(_0x76ea34,_0x41accc,_0x305778,_0x1e8a8e,_0x35d5ea,_0x22fb9e){var _0x203dfc=_0x5a41,_0x53bb71,_0x56de44,_0x41daae,_0x4e3bb8;this[_0x203dfc(0x17b)]=_0x76ea34,this[_0x203dfc(0x133)]=_0x41accc,this[_0x203dfc(0xf0)]=_0x305778,this['nodeModules']=_0x1e8a8e,this[_0x203dfc(0x19d)]=_0x35d5ea,this[_0x203dfc(0x1a9)]=_0x22fb9e,this[_0x203dfc(0xdc)]=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0x203dfc(0xe9)]=!0x1,this['_connecting']=!0x1,this[_0x203dfc(0x19e)]=((_0x56de44=(_0x53bb71=_0x76ea34[_0x203dfc(0x139)])==null?void 0x0:_0x53bb71[_0x203dfc(0x11f)])==null?void 0x0:_0x56de44[_0x203dfc(0x1b3)])==='edge',this[_0x203dfc(0xcd)]=!((_0x4e3bb8=(_0x41daae=this[_0x203dfc(0x17b)]['process'])==null?void 0x0:_0x41daae[_0x203dfc(0xe2)])!=null&&_0x4e3bb8[_0x203dfc(0x145)])&&!this[_0x203dfc(0x19e)],this[_0x203dfc(0x129)]=null,this['_connectAttemptCount']=0x0,this[_0x203dfc(0x1bd)]=0x14,this[_0x203dfc(0x156)]=_0x203dfc(0xca),this[_0x203dfc(0x165)]=(this[_0x203dfc(0xcd)]?_0x203dfc(0x1b1):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this[_0x203dfc(0x156)];}function _0x46c9(){var _0x4ae90f=['autoExpandPreviousObjects','bind','resetOnProcessingTimeAverageMs','function','Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','autoExpandMaxDepth','defaultLimits','some','[object\\x20Array]','_cleanNode','_getOwnPropertyDescriptor',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'8096830gPNSKo','length','_isSet','log','reducePolicy','forEach','rootExpression','perf_hooks','isExpressionToEvaluate','resolveGetters','_ws','push','nan','_setNodeExpressionPath','readyState','_hasMapOnItsPath','','env','hrtime','resetWhenQuietMs','toString','_setNodeId',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','pop','strLength','positiveInfinity','modules','_WebSocketClass','_type','capped','127.0.0.1','object','call','POSITIVE_INFINITY','next.js','coverage','102LwRJSG','host','index','_setNodeQueryPath','HTMLAllCollection','_addLoadNode','_attemptToReconnectShortly','process','type','logger\\x20websocket\\x20error','_reconnectTimeout','getOwnPropertyNames','String','_console_ninja','gateway.docker.internal','3810','_treeNodePropertiesAfterFullValue','parse','1','node','value','_isMap','reduceOnCount','315SmJdle','close','timeStamp','time','_Symbol','_hasSymbolPropertyOnItsPath','angular','perLogpoint','default','endsWith','\\x20server','bigint','startsWith','_webSocketErrorDocsLink','_setNodeExpandableState','2976160OPTOtp','nodeModules','onopen','reduceLimits','serialize','_addProperty','concat','_getOwnPropertyNames','[object\\x20Set]','stringify','ExpoDevice','elapsed','261278GYbHMc','_sendErrorMessage','_additionalMetadata','expressionsToEvaluate','message','toLowerCase','getWebSocketClass','_setNodePermissions','WebSocket','getOwnPropertySymbols','_extendedWarning','_blacklistedProperty','warn','autoExpandPropertyCount','null','string','_addFunctionsNode','ws://','Buffer','hasOwnProperty','prototype','edge','_isArray','global','catch','slice','_undefined','then','array','66JgkQaA','includes','remix','url','disabledTrace','_allowedToConnectOnSend','_treeNodePropertiesBeforeFullValue','reload','NEGATIVE_INFINITY','stackTraceLimit','_regExpToString','...','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','reducedLimits','resolve','\\x20browser','_hasSetOnItsPath','charAt','substr','1763893057747','_socket','onmessage','_property','[object\\x20Map]','isArray','_isPrimitiveWrapperType','_getOwnPropertySymbols','dockerizedApp','_inNextEdge','noFunctions','error','iterator','onclose','_processTreeNodeResult',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'constructor','_isUndefined','elements','expId','eventReceivedCallback','import(\\x27path\\x27)','_numberRegExp','_dateToString','next.js','149349QSQLvQ','level','data','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','hostname','NEXT_RUNTIME','Map','_console_ninja_session','android','args','props','count','match','_isNegativeZero','root_exp_id','_maxConnectAttemptCount','name','196280wOXbpo','trace','Set','symbol','46iTUtwv','_keyStrRegExp','funcName','react-native','send','setter','autoExpandLimit','stack','valueOf','sortProps','_capIfString','date','set','unknown','_connectAttemptCount','_setNodeLabel','parent','https://tinyurl.com/37x8b79t','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','console','_inBrowser','number','current','depth','_objectToString','map','Promise','1.0.0','_propertyName','boolean','','_consoleNinjaAllowedToStart','_connecting','_WebSocket','path','_allowedToSend','_addObjectProperty','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','_sortProps','toUpperCase','unref','versions','ninjaSuppressConsole','hits','getOwnPropertyDescriptor','cappedElements','Number','undefined','_connected','now','getter','[object\\x20Date]','4532040FLHqEh','onerror','_ninjaIgnoreNextError','port','_disposeWebsocket','totalStrLength','location','522529oHclbe','test','replace','reduceOnAccumulatedProcessingTimeMs','fromCharCode','_p_name','allStrLength','expo','method','_HTMLAllCollection','autoExpand','bound\\x20Promise','performance','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());'];_0x46c9=function(){return _0x4ae90f;};return _0x46c9();}z[_0x1fc135(0x178)][_0x1fc135(0x16a)]=async function(){var _0x4ae121=_0x1fc135,_0x18a19c,_0x241a90;if(this['_WebSocketClass'])return this[_0x4ae121(0x129)];let _0x45de09;if(this[_0x4ae121(0xcd)]||this['_inNextEdge'])_0x45de09=this[_0x4ae121(0x17b)][_0x4ae121(0x16c)];else{if((_0x18a19c=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])!=null&&_0x18a19c[_0x4ae121(0xda)])_0x45de09=(_0x241a90=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])==null?void 0x0:_0x241a90[_0x4ae121(0xda)];else try{_0x45de09=(await new Function(_0x4ae121(0xdb),_0x4ae121(0x184),_0x4ae121(0x159),_0x4ae121(0x101))(await(0x0,eval)(_0x4ae121(0x1aa)),await(0x0,eval)('import(\\x27url\\x27)'),this['nodeModules']))[_0x4ae121(0x151)];}catch{try{_0x45de09=require(require(_0x4ae121(0xdb))['join'](this[_0x4ae121(0x159)],'ws'));}catch{throw new Error(_0x4ae121(0x18d));}}}return this['_WebSocketClass']=_0x45de09,_0x45de09;},z['prototype']['_connectToHostNow']=function(){var _0x3e8739=_0x1fc135;this[_0x3e8739(0xd9)]||this[_0x3e8739(0xe9)]||this[_0x3e8739(0xc7)]>=this['_maxConnectAttemptCount']||(this['_allowedToConnectOnSend']=!0x1,this[_0x3e8739(0xd9)]=!0x0,this[_0x3e8739(0xc7)]++,this[_0x3e8739(0x118)]=new Promise((_0x3fa28f,_0x5e9cd5)=>{var _0x21d44e=_0x3e8739;this[_0x21d44e(0x16a)]()[_0x21d44e(0x17f)](_0x3e4660=>{var _0x4002c9=_0x21d44e;let _0x265cb8=new _0x3e4660(_0x4002c9(0x175)+(!this[_0x4002c9(0xcd)]&&this[_0x4002c9(0x19d)]?_0x4002c9(0x140):this[_0x4002c9(0x133)])+':'+this[_0x4002c9(0xf0)]);_0x265cb8[_0x4002c9(0xee)]=()=>{var _0x30e6ef=_0x4002c9;this['_allowedToSend']=!0x1,this['_disposeWebsocket'](_0x265cb8),this[_0x30e6ef(0x138)](),_0x5e9cd5(new Error(_0x30e6ef(0x13b)));},_0x265cb8[_0x4002c9(0x15a)]=()=>{var _0x453b8c=_0x4002c9;this[_0x453b8c(0xcd)]||_0x265cb8[_0x453b8c(0x196)]&&_0x265cb8[_0x453b8c(0x196)][_0x453b8c(0xe1)]&&_0x265cb8['_socket'][_0x453b8c(0xe1)](),_0x3fa28f(_0x265cb8);},_0x265cb8[_0x4002c9(0x1a2)]=()=>{var _0x140e5d=_0x4002c9;this[_0x140e5d(0x186)]=!0x0,this['_disposeWebsocket'](_0x265cb8),this['_attemptToReconnectShortly']();},_0x265cb8[_0x4002c9(0x197)]=_0x45b578=>{var _0x561e4f=_0x4002c9;try{if(!(_0x45b578!=null&&_0x45b578[_0x561e4f(0x1b0)])||!this['eventReceivedCallback'])return;let _0x5c0f52=JSON[_0x561e4f(0x143)](_0x45b578[_0x561e4f(0x1b0)]);this[_0x561e4f(0x1a9)](_0x5c0f52[_0x561e4f(0xfc)],_0x5c0f52[_0x561e4f(0x1b7)],this[_0x561e4f(0x17b)],this[_0x561e4f(0xcd)]);}catch{}};})[_0x21d44e(0x17f)](_0x3522f8=>(this[_0x21d44e(0xe9)]=!0x0,this[_0x21d44e(0xd9)]=!0x1,this[_0x21d44e(0x186)]=!0x1,this[_0x21d44e(0xdc)]=!0x0,this[_0x21d44e(0xc7)]=0x0,_0x3522f8))['catch'](_0x5498dc=>(this[_0x21d44e(0xe9)]=!0x1,this[_0x21d44e(0xd9)]=!0x1,console[_0x21d44e(0x170)](_0x21d44e(0x18e)+this[_0x21d44e(0x156)]),_0x5e9cd5(new Error(_0x21d44e(0xde)+(_0x5498dc&&_0x5498dc['message'])))));}));},z[_0x1fc135(0x178)][_0x1fc135(0xf1)]=function(_0x39064e){var _0x62e767=_0x1fc135;this[_0x62e767(0xe9)]=!0x1,this[_0x62e767(0xd9)]=!0x1;try{_0x39064e[_0x62e767(0x1a2)]=null,_0x39064e['onerror']=null,_0x39064e[_0x62e767(0x15a)]=null;}catch{}try{_0x39064e[_0x62e767(0x11c)]<0x2&&_0x39064e[_0x62e767(0x14a)]();}catch{}},z[_0x1fc135(0x178)][_0x1fc135(0x138)]=function(){var _0x5da3df=_0x1fc135;clearTimeout(this[_0x5da3df(0x13c)]),!(this[_0x5da3df(0xc7)]>=this['_maxConnectAttemptCount'])&&(this['_reconnectTimeout']=setTimeout(()=>{var _0x21baad=_0x5da3df,_0x34fb09;this['_connected']||this[_0x21baad(0xd9)]||(this['_connectToHostNow'](),(_0x34fb09=this[_0x21baad(0x118)])==null||_0x34fb09[_0x21baad(0x17c)](()=>this['_attemptToReconnectShortly']()));},0x1f4),this[_0x5da3df(0x13c)]['unref']&&this['_reconnectTimeout'][_0x5da3df(0xe1)]());},z[_0x1fc135(0x178)][_0x1fc135(0x1c7)]=async function(_0x2aa022){var _0x44ea14=_0x1fc135;try{if(!this['_allowedToSend'])return;this[_0x44ea14(0x186)]&&this['_connectToHostNow'](),(await this['_ws'])['send'](JSON[_0x44ea14(0x161)](_0x2aa022));}catch(_0x516430){this[_0x44ea14(0x16e)]?console['warn'](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430['message'])):(this[_0x44ea14(0x16e)]=!0x0,console[_0x44ea14(0x170)](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430[_0x44ea14(0x168)]),_0x2aa022)),this[_0x44ea14(0xdc)]=!0x1,this[_0x44ea14(0x138)]();}};function H(_0xbed09e,_0x3de44a,_0x566e47,_0x54b39d,_0x39164d,_0x409fce,_0xbcb120,_0x4ae046=ne){var _0x51bc8b=_0x1fc135;let _0x2f5944=_0x566e47['split'](',')[_0x51bc8b(0xd2)](_0x4d018a=>{var _0x4f1217=_0x51bc8b,_0x3ff168,_0x2d1ad9,_0x57b744,_0xeff5a4,_0x7643dd,_0xd13b57,_0x3dac27;try{if(!_0xbed09e['_console_ninja_session']){let _0x4a47b6=((_0x2d1ad9=(_0x3ff168=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x3ff168[_0x4f1217(0xe2)])==null?void 0x0:_0x2d1ad9[_0x4f1217(0x145)])||((_0xeff5a4=(_0x57b744=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x57b744[_0x4f1217(0x11f)])==null?void 0x0:_0xeff5a4[_0x4f1217(0x1b3)])===_0x4f1217(0x179);(_0x39164d===_0x4f1217(0x130)||_0x39164d===_0x4f1217(0x183)||_0x39164d==='astro'||_0x39164d===_0x4f1217(0x14f))&&(_0x39164d+=_0x4a47b6?_0x4f1217(0x153):_0x4f1217(0x191));let _0x3e173e='';_0x39164d===_0x4f1217(0x1c6)&&(_0x3e173e=(((_0x3dac27=(_0xd13b57=(_0x7643dd=_0xbed09e['expo'])==null?void 0x0:_0x7643dd[_0x4f1217(0x128)])==null?void 0x0:_0xd13b57[_0x4f1217(0x162)])==null?void 0x0:_0x3dac27['osName'])||'')[_0x4f1217(0x169)](),_0x3e173e&&(_0x39164d+='\\x20'+_0x3e173e,_0x3e173e===_0x4f1217(0x1b6)&&(_0x3de44a='10.0.2.2'))),_0xbed09e['_console_ninja_session']={'id':+new Date(),'tool':_0x39164d},_0xbcb120&&_0x39164d&&!_0x4a47b6&&(_0x3e173e?console[_0x4f1217(0x111)](_0x4f1217(0x106)+_0x3e173e+_0x4f1217(0x124)):console[_0x4f1217(0x111)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0x39164d[_0x4f1217(0x193)](0x0)[_0x4f1217(0xe0)]()+_0x39164d[_0x4f1217(0x194)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'));}let _0x199336=new z(_0xbed09e,_0x3de44a,_0x4d018a,_0x54b39d,_0x409fce,_0x4ae046);return _0x199336[_0x4f1217(0x1c7)][_0x4f1217(0x103)](_0x199336);}catch(_0x33e9da){return console['warn'](_0x4f1217(0xcb),_0x33e9da&&_0x33e9da[_0x4f1217(0x168)]),()=>{};}});return _0x1956ea=>_0x2f5944[_0x51bc8b(0x113)](_0x4e6927=>_0x4e6927(_0x1956ea));}function ne(_0x116e80,_0x40cfba,_0x3b4452,_0x30cd66){var _0x890e43=_0x1fc135;_0x30cd66&&_0x116e80==='reload'&&_0x3b4452[_0x890e43(0xf3)][_0x890e43(0x188)]();}function b(_0x2601c7){var _0x326d90=_0x1fc135,_0x1a4170,_0x23ee95;let _0x531900=function(_0x27480e,_0x188dcd){return _0x188dcd-_0x27480e;},_0x2639ae;if(_0x2601c7[_0x326d90(0x100)])_0x2639ae=function(){var _0x2a5205=_0x326d90;return _0x2601c7['performance'][_0x2a5205(0xea)]();};else{if(_0x2601c7[_0x326d90(0x139)]&&_0x2601c7[_0x326d90(0x139)][_0x326d90(0x120)]&&((_0x23ee95=(_0x1a4170=_0x2601c7['process'])==null?void 0x0:_0x1a4170['env'])==null?void 0x0:_0x23ee95[_0x326d90(0x1b3)])!==_0x326d90(0x179))_0x2639ae=function(){var _0x3a41db=_0x326d90;return _0x2601c7[_0x3a41db(0x139)]['hrtime']();},_0x531900=function(_0x282f28,_0xc6af32){return 0x3e8*(_0xc6af32[0x0]-_0x282f28[0x0])+(_0xc6af32[0x1]-_0x282f28[0x1])/0xf4240;};else try{let {performance:_0x3f1ea6}=require(_0x326d90(0x115));_0x2639ae=function(){var _0x440cae=_0x326d90;return _0x3f1ea6[_0x440cae(0xea)]();};}catch{_0x2639ae=function(){return+new Date();};}}return{'elapsed':_0x531900,'timeStamp':_0x2639ae,'now':()=>Date['now']()};}function X(_0x23d2d9,_0x30bba7,_0x37042b){var _0x5f50f2=_0x1fc135,_0x142aeb,_0x43891d,_0x2c7083,_0x1efb74,_0x3655da,_0x2f04a6,_0x122ade,_0x31dc28,_0x472369;if(_0x23d2d9[_0x5f50f2(0xd8)]!==void 0x0)return _0x23d2d9[_0x5f50f2(0xd8)];let _0x45b226=((_0x43891d=(_0x142aeb=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x142aeb[_0x5f50f2(0xe2)])==null?void 0x0:_0x43891d[_0x5f50f2(0x145)])||((_0x1efb74=(_0x2c7083=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x2c7083[_0x5f50f2(0x11f)])==null?void 0x0:_0x1efb74[_0x5f50f2(0x1b3)])===_0x5f50f2(0x179),_0x36082e=!!(_0x37042b===_0x5f50f2(0x1c6)&&((_0x122ade=(_0x2f04a6=(_0x3655da=_0x23d2d9[_0x5f50f2(0xfb)])==null?void 0x0:_0x3655da[_0x5f50f2(0x128)])==null?void 0x0:_0x2f04a6[_0x5f50f2(0x162)])==null?void 0x0:_0x122ade['osName']));function _0x21c350(_0x2bf556){var _0x2c5e4b=_0x5f50f2;if(_0x2bf556[_0x2c5e4b(0x155)]('/')&&_0x2bf556[_0x2c5e4b(0x152)]('/')){let _0x267dc2=new RegExp(_0x2bf556[_0x2c5e4b(0x17d)](0x1,-0x1));return _0x4e19cc=>_0x267dc2[_0x2c5e4b(0xf5)](_0x4e19cc);}else{if(_0x2bf556[_0x2c5e4b(0x182)]('*')||_0x2bf556[_0x2c5e4b(0x182)]('?')){let _0x234e74=new RegExp('^'+_0x2bf556['replace'](/\\./g,String[_0x2c5e4b(0xf8)](0x5c)+'.')[_0x2c5e4b(0xf6)](/\\*/g,'.*')[_0x2c5e4b(0xf6)](/\\?/g,'.')+String[_0x2c5e4b(0xf8)](0x24));return _0x35cfab=>_0x234e74[_0x2c5e4b(0xf5)](_0x35cfab);}else return _0x16c4db=>_0x16c4db===_0x2bf556;}}let _0x725fc=_0x30bba7[_0x5f50f2(0xd2)](_0x21c350);return _0x23d2d9[_0x5f50f2(0xd8)]=_0x45b226||!_0x30bba7,!_0x23d2d9[_0x5f50f2(0xd8)]&&((_0x31dc28=_0x23d2d9[_0x5f50f2(0xf3)])==null?void 0x0:_0x31dc28['hostname'])&&(_0x23d2d9['_consoleNinjaAllowedToStart']=_0x725fc[_0x5f50f2(0x109)](_0x367574=>_0x367574(_0x23d2d9[_0x5f50f2(0xf3)]['hostname']))),_0x36082e&&!_0x23d2d9['_consoleNinjaAllowedToStart']&&!((_0x472369=_0x23d2d9[_0x5f50f2(0xf3)])!=null&&_0x472369[_0x5f50f2(0x1b2)])&&(_0x23d2d9[_0x5f50f2(0xd8)]=!0x0),_0x23d2d9[_0x5f50f2(0xd8)];}function J(_0x5873aa,_0x5b995d,_0x45642a,_0x5b3c4b,_0xad4d21,_0x413cb2){var _0x2cb272=_0x1fc135;_0x5873aa=_0x5873aa,_0x5b995d=_0x5b995d,_0x45642a=_0x45642a,_0x5b3c4b=_0x5b3c4b,_0xad4d21=_0xad4d21,_0xad4d21=_0xad4d21||{},_0xad4d21[_0x2cb272(0x108)]=_0xad4d21[_0x2cb272(0x108)]||{},_0xad4d21[_0x2cb272(0x18f)]=_0xad4d21[_0x2cb272(0x18f)]||{},_0xad4d21[_0x2cb272(0x112)]=_0xad4d21['reducePolicy']||{},_0xad4d21['reducePolicy'][_0x2cb272(0x150)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)]||{},_0xad4d21['reducePolicy'][_0x2cb272(0x17b)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]||{};let _0x1ec146={'perLogpoint':{'reduceOnCount':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x148)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21['reducePolicy']['perLogpoint'][_0x2cb272(0xf7)]||0x64,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)][_0x2cb272(0x121)]||0x1f4,'resetOnProcessingTimeAverageMs':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x104)]||0x64},'global':{'reduceOnCount':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0x148)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0xf7)]||0x12c,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetWhenQuietMs']||0x32,'resetOnProcessingTimeAverageMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetOnProcessingTimeAverageMs']||0x64}},_0x40a3a3=b(_0x5873aa),_0x48338=_0x40a3a3[_0x2cb272(0x163)],_0x21a97a=_0x40a3a3[_0x2cb272(0x14b)];function _0x4de4d2(){var _0x3d3e0d=_0x2cb272;this[_0x3d3e0d(0x1c4)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x3d3e0d(0x1ab)]=/^(0|[1-9][0-9]*)$/,this['_quotedRegExp']=/'([^\\\\']|\\\\')*'/,this[_0x3d3e0d(0x17e)]=_0x5873aa['undefined'],this[_0x3d3e0d(0xfd)]=_0x5873aa['HTMLAllCollection'],this[_0x3d3e0d(0x10c)]=Object[_0x3d3e0d(0xe5)],this[_0x3d3e0d(0x15f)]=Object[_0x3d3e0d(0x13d)],this[_0x3d3e0d(0x14d)]=_0x5873aa['Symbol'],this['_regExpToString']=RegExp[_0x3d3e0d(0x178)][_0x3d3e0d(0x122)],this[_0x3d3e0d(0x1ac)]=Date['prototype'][_0x3d3e0d(0x122)];}_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15c)]=function(_0x27724c,_0xe7c38a,_0x3efad1,_0x4054fc){var _0x23455e=_0x2cb272,_0x47d7be=this,_0x252550=_0x3efad1['autoExpand'];function _0x58ac21(_0x3aa5ed,_0x5c0803,_0x52ecd3){var _0x9a2757=_0x5a41;_0x5c0803['type']='unknown',_0x5c0803[_0x9a2757(0x1a0)]=_0x3aa5ed[_0x9a2757(0x168)],_0x3e44c3=_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)],_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)]=_0x5c0803,_0x47d7be[_0x9a2757(0x187)](_0x5c0803,_0x52ecd3);}let _0xbd937b,_0x4a2288,_0x241cc=_0x5873aa['ninjaSuppressConsole'];_0x5873aa['ninjaSuppressConsole']=!0x0,_0x5873aa[_0x23455e(0xcc)]&&(_0xbd937b=_0x5873aa[_0x23455e(0xcc)]['error'],_0x4a2288=_0x5873aa['console'][_0x23455e(0x170)],_0xbd937b&&(_0x5873aa['console']['error']=function(){}),_0x4a2288&&(_0x5873aa['console'][_0x23455e(0x170)]=function(){}));try{try{_0x3efad1[_0x23455e(0x1af)]++,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x102)][_0x23455e(0x119)](_0xe7c38a);var _0x6cd2d3,_0x2b585b,_0x2a5db7,_0x3c44b3,_0x496c9e=[],_0x333092=[],_0x4329e3,_0x5c61c1=this['_type'](_0xe7c38a),_0x2cfc15=_0x5c61c1===_0x23455e(0x180),_0x17237c=!0x1,_0x27360a=_0x5c61c1==='function',_0x4d346e=this['_isPrimitiveType'](_0x5c61c1),_0x249206=this[_0x23455e(0x19b)](_0x5c61c1),_0x3c5b1d=_0x4d346e||_0x249206,_0x16b4fc={},_0x368b87=0x0,_0x46e586=!0x1,_0x3e44c3,_0x4deeb0=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x3efad1['depth']){if(_0x2cfc15){if(_0x2b585b=_0xe7c38a[_0x23455e(0x10f)],_0x2b585b>_0x3efad1[_0x23455e(0x1a7)]){for(_0x2a5db7=0x0,_0x3c44b3=_0x3efad1[_0x23455e(0x1a7)],_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0x15d)](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));_0x27724c[_0x23455e(0xe6)]=!0x0;}else{for(_0x2a5db7=0x0,_0x3c44b3=_0x2b585b,_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));}_0x3efad1[_0x23455e(0x171)]+=_0x333092['length'];}if(!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&!_0x4d346e&&_0x5c61c1!==_0x23455e(0x13e)&&_0x5c61c1!==_0x23455e(0x176)&&_0x5c61c1!==_0x23455e(0x154)){var _0x504faa=_0x4054fc['props']||_0x3efad1['props'];if(this['_isSet'](_0xe7c38a)?(_0x6cd2d3=0x0,_0xe7c38a[_0x23455e(0x113)](function(_0x116948){var _0x29bff9=_0x23455e;if(_0x368b87++,_0x3efad1[_0x29bff9(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1['isExpressionToEvaluate']&&_0x3efad1['autoExpand']&&_0x3efad1['autoExpandPropertyCount']>_0x3efad1['autoExpandLimit']){_0x46e586=!0x0;return;}_0x333092['push'](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x29bff9(0x1c1),_0x6cd2d3++,_0x3efad1,function(_0x5b68ce){return function(){return _0x5b68ce;};}(_0x116948)));})):this['_isMap'](_0xe7c38a)&&_0xe7c38a[_0x23455e(0x113)](function(_0x32011f,_0x2c19ff){var _0x585ade=_0x23455e;if(_0x368b87++,_0x3efad1[_0x585ade(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1[_0x585ade(0x116)]&&_0x3efad1[_0x585ade(0xfe)]&&_0x3efad1[_0x585ade(0x171)]>_0x3efad1[_0x585ade(0x1c9)]){_0x46e586=!0x0;return;}var _0x34b418=_0x2c19ff[_0x585ade(0x122)]();_0x34b418[_0x585ade(0x10f)]>0x64&&(_0x34b418=_0x34b418[_0x585ade(0x17d)](0x0,0x64)+_0x585ade(0x18c)),_0x333092[_0x585ade(0x119)](_0x47d7be[_0x585ade(0x15d)](_0x496c9e,_0xe7c38a,'Map',_0x34b418,_0x3efad1,function(_0x3df5a8){return function(){return _0x3df5a8;};}(_0x32011f)));}),!_0x17237c){try{for(_0x4329e3 in _0xe7c38a)if(!(_0x2cfc15&&_0x4deeb0['test'](_0x4329e3))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0xdd)](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}catch{}if(_0x16b4fc['_p_length']=!0x0,_0x27360a&&(_0x16b4fc[_0x23455e(0xf9)]=!0x0),!_0x46e586){var _0x1a196c=[][_0x23455e(0x15e)](this['_getOwnPropertyNames'](_0xe7c38a))[_0x23455e(0x15e)](this[_0x23455e(0x19c)](_0xe7c38a));for(_0x6cd2d3=0x0,_0x2b585b=_0x1a196c[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)if(_0x4329e3=_0x1a196c[_0x6cd2d3],!(_0x2cfc15&&_0x4deeb0[_0x23455e(0xf5)](_0x4329e3[_0x23455e(0x122)]()))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)&&!_0x16b4fc[typeof _0x4329e3!=_0x23455e(0x1c2)?'_p_'+_0x4329e3[_0x23455e(0x122)]():_0x4329e3]){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be['_addObjectProperty'](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}}}}if(_0x27724c[_0x23455e(0x13a)]=_0x5c61c1,_0x3c5b1d?(_0x27724c[_0x23455e(0x146)]=_0xe7c38a[_0x23455e(0x1cb)](),this['_capIfString'](_0x5c61c1,_0x27724c,_0x3efad1,_0x4054fc)):_0x5c61c1===_0x23455e(0xc4)?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x1ac)]['call'](_0xe7c38a):_0x5c61c1===_0x23455e(0x154)?_0x27724c['value']=_0xe7c38a[_0x23455e(0x122)]():_0x5c61c1==='RegExp'?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x18b)][_0x23455e(0x12e)](_0xe7c38a):_0x5c61c1===_0x23455e(0x1c2)&&this[_0x23455e(0x14d)]?_0x27724c[_0x23455e(0x146)]=this['_Symbol'][_0x23455e(0x178)][_0x23455e(0x122)]['call'](_0xe7c38a):!_0x3efad1[_0x23455e(0xd0)]&&!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&(delete _0x27724c[_0x23455e(0x146)],_0x27724c[_0x23455e(0x12b)]=!0x0),_0x46e586&&(_0x27724c['cappedProps']=!0x0),_0x3e44c3=_0x3efad1[_0x23455e(0x145)][_0x23455e(0xcf)],_0x3efad1['node'][_0x23455e(0xcf)]=_0x27724c,this['_treeNodePropertiesBeforeFullValue'](_0x27724c,_0x3efad1),_0x333092[_0x23455e(0x10f)]){for(_0x6cd2d3=0x0,_0x2b585b=_0x333092[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)_0x333092[_0x6cd2d3](_0x6cd2d3);}_0x496c9e['length']&&(_0x27724c['props']=_0x496c9e);}catch(_0x4444a){_0x58ac21(_0x4444a,_0x27724c,_0x3efad1);}this['_additionalMetadata'](_0xe7c38a,_0x27724c),this['_treeNodePropertiesAfterFullValue'](_0x27724c,_0x3efad1),_0x3efad1['node'][_0x23455e(0xcf)]=_0x3e44c3,_0x3efad1[_0x23455e(0x1af)]--,_0x3efad1[_0x23455e(0xfe)]=_0x252550,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1['autoExpandPreviousObjects'][_0x23455e(0x125)]();}finally{_0xbd937b&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x1a0)]=_0xbd937b),_0x4a2288&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x170)]=_0x4a2288),_0x5873aa[_0x23455e(0xe3)]=_0x241cc;}return _0x27724c;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x19c)]=function(_0x4e35d2){var _0x1be40a=_0x2cb272;return Object[_0x1be40a(0x16d)]?Object['getOwnPropertySymbols'](_0x4e35d2):[];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x110)]=function(_0x2fe3c7){var _0x1bfa34=_0x2cb272;return!!(_0x2fe3c7&&_0x5873aa[_0x1bfa34(0x1c1)]&&this[_0x1bfa34(0xd1)](_0x2fe3c7)===_0x1bfa34(0x160)&&_0x2fe3c7[_0x1bfa34(0x113)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16f)]=function(_0x1247ea,_0x4ab5f4,_0x3e79c9){var _0x5f57fc=_0x2cb272;if(!_0x3e79c9[_0x5f57fc(0x117)]){let _0x5b1ca2=this[_0x5f57fc(0x10c)](_0x1247ea,_0x4ab5f4);if(_0x5b1ca2&&_0x5b1ca2['get'])return!0x0;}return _0x3e79c9[_0x5f57fc(0x19f)]?typeof _0x1247ea[_0x4ab5f4]==_0x5f57fc(0x105):!0x1;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x12a)]=function(_0x855594){var _0x4849c4=_0x2cb272,_0x2b6119='';return _0x2b6119=typeof _0x855594,_0x2b6119===_0x4849c4(0x12d)?this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0x10a)?_0x2b6119=_0x4849c4(0x180):this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0xec)?_0x2b6119=_0x4849c4(0xc4):this[_0x4849c4(0xd1)](_0x855594)==='[object\\x20BigInt]'?_0x2b6119=_0x4849c4(0x154):_0x855594===null?_0x2b6119=_0x4849c4(0x172):_0x855594['constructor']&&(_0x2b6119=_0x855594['constructor'][_0x4849c4(0x1be)]||_0x2b6119):_0x2b6119==='undefined'&&this['_HTMLAllCollection']&&_0x855594 instanceof this['_HTMLAllCollection']&&(_0x2b6119=_0x4849c4(0x136)),_0x2b6119;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xd1)]=function(_0x2d378a){var _0x42e9e1=_0x2cb272;return Object[_0x42e9e1(0x178)]['toString'][_0x42e9e1(0x12e)](_0x2d378a);},_0x4de4d2['prototype']['_isPrimitiveType']=function(_0x49489e){var _0x4d59c8=_0x2cb272;return _0x49489e===_0x4d59c8(0xd6)||_0x49489e==='string'||_0x49489e==='number';},_0x4de4d2[_0x2cb272(0x178)]['_isPrimitiveWrapperType']=function(_0x5ad54d){var _0x362e66=_0x2cb272;return _0x5ad54d==='Boolean'||_0x5ad54d===_0x362e66(0x13e)||_0x5ad54d===_0x362e66(0xe7);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15d)]=function(_0x4fe9b7,_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91){var _0x502d7d=this;return function(_0x1e15bc){var _0x3c5173=_0x5a41,_0x49048b=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xcf)],_0x381145=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)],_0x563aae=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)];_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)]=_0x49048b,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=typeof _0x511187==_0x3c5173(0xce)?_0x511187:_0x1e15bc,_0x4fe9b7['push'](_0x502d7d[_0x3c5173(0x198)](_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91)),_0x76c4bc['node'][_0x3c5173(0xc9)]=_0x563aae,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=_0x381145;};},_0x4de4d2['prototype']['_addObjectProperty']=function(_0x178345,_0x303198,_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38){var _0x562f19=_0x2cb272,_0x1bbfd2=this;return _0x303198[typeof _0x1945f8!=_0x562f19(0x1c2)?'_p_'+_0x1945f8[_0x562f19(0x122)]():_0x1945f8]=!0x0,function(_0x3b9835){var _0x5c127c=_0x562f19,_0x561160=_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xcf)],_0x3fc84f=_0x586d1c['node'][_0x5c127c(0x134)],_0x43d53f=_0x586d1c['node'][_0x5c127c(0xc9)];_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xc9)]=_0x561160,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3b9835,_0x178345[_0x5c127c(0x119)](_0x1bbfd2[_0x5c127c(0x198)](_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38)),_0x586d1c[_0x5c127c(0x145)]['parent']=_0x43d53f,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3fc84f;};},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x198)]=function(_0x67eb30,_0x29f374,_0x5d83f7,_0x29b358,_0x30cd4d){var _0x1a4c0e=_0x2cb272,_0x2885fe=this;_0x30cd4d||(_0x30cd4d=function(_0x196fec,_0x2c514e){return _0x196fec[_0x2c514e];});var _0x4369db=_0x5d83f7[_0x1a4c0e(0x122)](),_0x9761b4=_0x29b358[_0x1a4c0e(0x167)]||{},_0x586f06=_0x29b358[_0x1a4c0e(0xd0)],_0x3a48b1=_0x29b358['isExpressionToEvaluate'];try{var _0x52f87b=this[_0x1a4c0e(0x147)](_0x67eb30),_0x4741cd=_0x4369db;_0x52f87b&&_0x4741cd[0x0]==='\\x27'&&(_0x4741cd=_0x4741cd[_0x1a4c0e(0x194)](0x1,_0x4741cd[_0x1a4c0e(0x10f)]-0x2));var _0x5d5769=_0x29b358['expressionsToEvaluate']=_0x9761b4['_p_'+_0x4741cd];_0x5d5769&&(_0x29b358['depth']=_0x29b358[_0x1a4c0e(0xd0)]+0x1),_0x29b358['isExpressionToEvaluate']=!!_0x5d5769;var _0x10cb78=typeof _0x5d83f7=='symbol',_0x330f9d={'name':_0x10cb78||_0x52f87b?_0x4369db:this[_0x1a4c0e(0xd5)](_0x4369db)};if(_0x10cb78&&(_0x330f9d[_0x1a4c0e(0x1c2)]=!0x0),!(_0x29f374===_0x1a4c0e(0x180)||_0x29f374==='Error')){var _0x14f906=this['_getOwnPropertyDescriptor'](_0x67eb30,_0x5d83f7);if(_0x14f906&&(_0x14f906[_0x1a4c0e(0xc5)]&&(_0x330f9d[_0x1a4c0e(0x1c8)]=!0x0),_0x14f906['get']&&!_0x5d5769&&!_0x29b358[_0x1a4c0e(0x117)]))return _0x330f9d[_0x1a4c0e(0xeb)]=!0x0,this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x58877c;try{_0x58877c=_0x30cd4d(_0x67eb30,_0x5d83f7);}catch(_0x14f629){return _0x330f9d={'name':_0x4369db,'type':_0x1a4c0e(0xc6),'error':_0x14f629[_0x1a4c0e(0x168)]},this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x102988=this['_type'](_0x58877c),_0x49a64d=this['_isPrimitiveType'](_0x102988);if(_0x330f9d['type']=_0x102988,_0x49a64d)this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x42b519=_0x1a4c0e;_0x330f9d['value']=_0x58877c[_0x42b519(0x1cb)](),!_0x5d5769&&_0x2885fe[_0x42b519(0xc3)](_0x102988,_0x330f9d,_0x29b358,{});});else{var _0x580aa0=_0x29b358[_0x1a4c0e(0xfe)]&&_0x29b358[_0x1a4c0e(0x1af)]<_0x29b358[_0x1a4c0e(0x107)]&&_0x29b358[_0x1a4c0e(0x102)]['indexOf'](_0x58877c)<0x0&&_0x102988!==_0x1a4c0e(0x105)&&_0x29b358['autoExpandPropertyCount']<_0x29b358[_0x1a4c0e(0x1c9)];_0x580aa0||_0x29b358[_0x1a4c0e(0x1af)]<_0x586f06||_0x5d5769?this['serialize'](_0x330f9d,_0x58877c,_0x29b358,_0x5d5769||{}):this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x492fd5=_0x1a4c0e;_0x102988===_0x492fd5(0x172)||_0x102988==='undefined'||(delete _0x330f9d[_0x492fd5(0x146)],_0x330f9d[_0x492fd5(0x12b)]=!0x0);});}return _0x330f9d;}finally{_0x29b358[_0x1a4c0e(0x167)]=_0x9761b4,_0x29b358['depth']=_0x586f06,_0x29b358[_0x1a4c0e(0x116)]=_0x3a48b1;}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc3)]=function(_0x52cb19,_0x54c144,_0x3e334e,_0x532699){var _0x3f3b07=_0x2cb272,_0x2ca270=_0x532699[_0x3f3b07(0x126)]||_0x3e334e['strLength'];if((_0x52cb19==='string'||_0x52cb19===_0x3f3b07(0x13e))&&_0x54c144[_0x3f3b07(0x146)]){let _0x160821=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x10f)];_0x3e334e[_0x3f3b07(0xfa)]+=_0x160821,_0x3e334e[_0x3f3b07(0xfa)]>_0x3e334e['totalStrLength']?(_0x54c144['capped']='',delete _0x54c144[_0x3f3b07(0x146)]):_0x160821>_0x2ca270&&(_0x54c144['capped']=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x194)](0x0,_0x2ca270),delete _0x54c144[_0x3f3b07(0x146)]);}},_0x4de4d2['prototype']['_isMap']=function(_0x18d6a6){var _0x3c7fd5=_0x2cb272;return!!(_0x18d6a6&&_0x5873aa['Map']&&this[_0x3c7fd5(0xd1)](_0x18d6a6)===_0x3c7fd5(0x199)&&_0x18d6a6[_0x3c7fd5(0x113)]);},_0x4de4d2[_0x2cb272(0x178)]['_propertyName']=function(_0x947ebf){var _0x531112=_0x2cb272;if(_0x947ebf[_0x531112(0x1ba)](/^\\d+$/))return _0x947ebf;var _0x9a15b4;try{_0x9a15b4=JSON['stringify'](''+_0x947ebf);}catch{_0x9a15b4='\\x22'+this['_objectToString'](_0x947ebf)+'\\x22';}return _0x9a15b4[_0x531112(0x1ba)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x9a15b4=_0x9a15b4[_0x531112(0x194)](0x1,_0x9a15b4[_0x531112(0x10f)]-0x2):_0x9a15b4=_0x9a15b4['replace'](/'/g,'\\x5c\\x27')[_0x531112(0xf6)](/\\\\\"/g,'\\x22')[_0x531112(0xf6)](/(^\"|\"$)/g,'\\x27'),_0x9a15b4;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1a3)]=function(_0x35e665,_0x2101c2,_0xab9652,_0x1c446e){var _0x3971dc=_0x2cb272;this[_0x3971dc(0x187)](_0x35e665,_0x2101c2),_0x1c446e&&_0x1c446e(),this[_0x3971dc(0x166)](_0xab9652,_0x35e665),this[_0x3971dc(0x142)](_0x35e665,_0x2101c2);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x187)]=function(_0x44b450,_0x34a33b){var _0x25ebc5=_0x2cb272;this[_0x25ebc5(0x123)](_0x44b450,_0x34a33b),this[_0x25ebc5(0x135)](_0x44b450,_0x34a33b),this['_setNodeExpressionPath'](_0x44b450,_0x34a33b),this[_0x25ebc5(0x16b)](_0x44b450,_0x34a33b);},_0x4de4d2['prototype'][_0x2cb272(0x123)]=function(_0x533ba7,_0x208597){},_0x4de4d2['prototype'][_0x2cb272(0x135)]=function(_0x1c215c,_0x404f13){},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc8)]=function(_0x4fbee4,_0x4ecb21){},_0x4de4d2['prototype'][_0x2cb272(0x1a6)]=function(_0x41a1f1){var _0x327560=_0x2cb272;return _0x41a1f1===this[_0x327560(0x17e)];},_0x4de4d2[_0x2cb272(0x178)]['_treeNodePropertiesAfterFullValue']=function(_0x48ca53,_0x268d68){var _0x2e622c=_0x2cb272;this[_0x2e622c(0xc8)](_0x48ca53,_0x268d68),this[_0x2e622c(0x157)](_0x48ca53),_0x268d68[_0x2e622c(0xc2)]&&this[_0x2e622c(0xdf)](_0x48ca53),this['_addFunctionsNode'](_0x48ca53,_0x268d68),this[_0x2e622c(0x137)](_0x48ca53,_0x268d68),this[_0x2e622c(0x10b)](_0x48ca53);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x166)]=function(_0x2678a0,_0x259c0d){var _0x36fdc4=_0x2cb272;try{_0x2678a0&&typeof _0x2678a0[_0x36fdc4(0x10f)]==_0x36fdc4(0xce)&&(_0x259c0d[_0x36fdc4(0x10f)]=_0x2678a0[_0x36fdc4(0x10f)]);}catch{}if(_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xce)||_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xe7)){if(isNaN(_0x259c0d['value']))_0x259c0d[_0x36fdc4(0x11a)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];else switch(_0x259c0d['value']){case Number[_0x36fdc4(0x12f)]:_0x259c0d[_0x36fdc4(0x127)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case Number[_0x36fdc4(0x189)]:_0x259c0d['negativeInfinity']=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case 0x0:this['_isNegativeZero'](_0x259c0d['value'])&&(_0x259c0d['negativeZero']=!0x0);break;}}else _0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0x105)&&typeof _0x2678a0[_0x36fdc4(0x1be)]==_0x36fdc4(0x173)&&_0x2678a0['name']&&_0x259c0d[_0x36fdc4(0x1be)]&&_0x2678a0[_0x36fdc4(0x1be)]!==_0x259c0d['name']&&(_0x259c0d[_0x36fdc4(0x1c5)]=_0x2678a0[_0x36fdc4(0x1be)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1bb)]=function(_0x31e8d6){return 0x1/_0x31e8d6===Number['NEGATIVE_INFINITY'];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xdf)]=function(_0x5387a1){var _0xf6510d=_0x2cb272;!_0x5387a1[_0xf6510d(0x1b8)]||!_0x5387a1['props'][_0xf6510d(0x10f)]||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x180)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1b4)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1c1)||_0x5387a1['props']['sort'](function(_0x47dd16,_0x585d58){var _0x14b330=_0xf6510d,_0x13e486=_0x47dd16[_0x14b330(0x1be)][_0x14b330(0x169)](),_0x486976=_0x585d58[_0x14b330(0x1be)]['toLowerCase']();return _0x13e486<_0x486976?-0x1:_0x13e486>_0x486976?0x1:0x0;});},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x174)]=function(_0x222b24,_0x769935){var _0x84e84d=_0x2cb272;if(!(_0x769935['noFunctions']||!_0x222b24['props']||!_0x222b24['props'][_0x84e84d(0x10f)])){for(var _0x730840=[],_0x3e54f2=[],_0x12e05b=0x0,_0x14c80d=_0x222b24['props'][_0x84e84d(0x10f)];_0x12e05b<_0x14c80d;_0x12e05b++){var _0x227177=_0x222b24['props'][_0x12e05b];_0x227177[_0x84e84d(0x13a)]===_0x84e84d(0x105)?_0x730840[_0x84e84d(0x119)](_0x227177):_0x3e54f2['push'](_0x227177);}if(!(!_0x3e54f2[_0x84e84d(0x10f)]||_0x730840[_0x84e84d(0x10f)]<=0x1)){_0x222b24[_0x84e84d(0x1b8)]=_0x3e54f2;var _0x4768f5={'functionsNode':!0x0,'props':_0x730840};this['_setNodeId'](_0x4768f5,_0x769935),this[_0x84e84d(0xc8)](_0x4768f5,_0x769935),this[_0x84e84d(0x157)](_0x4768f5),this[_0x84e84d(0x16b)](_0x4768f5,_0x769935),_0x4768f5['id']+='\\x20f',_0x222b24['props']['unshift'](_0x4768f5);}}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x137)]=function(_0x563c3f,_0x4419b7){},_0x4de4d2['prototype'][_0x2cb272(0x157)]=function(_0x497fff){},_0x4de4d2['prototype'][_0x2cb272(0x17a)]=function(_0x1b9882){var _0x3294c4=_0x2cb272;return Array[_0x3294c4(0x19a)](_0x1b9882)||typeof _0x1b9882==_0x3294c4(0x12d)&&this[_0x3294c4(0xd1)](_0x1b9882)===_0x3294c4(0x10a);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16b)]=function(_0x9d1c25,_0x314f15){},_0x4de4d2['prototype']['_cleanNode']=function(_0x1d1f32){var _0x54d4ff=_0x2cb272;delete _0x1d1f32[_0x54d4ff(0x14e)],delete _0x1d1f32[_0x54d4ff(0x192)],delete _0x1d1f32[_0x54d4ff(0x11d)];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x11b)]=function(_0x263d9a,_0x3e2e45){};let _0xaaf654=new _0x4de4d2(),_0x1c9af4={'props':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x1b8)]||0x64,'elements':_0xad4d21['defaultLimits'][_0x2cb272(0x1a7)]||0x64,'strLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x126)]||0x400*0x32,'totalStrLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0xf2)]||0x400*0x32,'autoExpandLimit':_0xad4d21['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0xad4d21['defaultLimits'][_0x2cb272(0x107)]||0xa},_0xf3a84={'props':_0xad4d21[_0x2cb272(0x18f)]['props']||0x5,'elements':_0xad4d21['reducedLimits'][_0x2cb272(0x1a7)]||0x5,'strLength':_0xad4d21['reducedLimits'][_0x2cb272(0x126)]||0x100,'totalStrLength':_0xad4d21[_0x2cb272(0x18f)][_0x2cb272(0xf2)]||0x100*0x3,'autoExpandLimit':_0xad4d21['reducedLimits'][_0x2cb272(0x1c9)]||0x1e,'autoExpandMaxDepth':_0xad4d21['reducedLimits'][_0x2cb272(0x107)]||0x2};if(_0x413cb2){let _0x4ae918=_0xaaf654[_0x2cb272(0x15c)]['bind'](_0xaaf654);_0xaaf654[_0x2cb272(0x15c)]=function(_0x40ecf2,_0x500c15,_0x2ec994,_0x14464a){return _0x4ae918(_0x40ecf2,_0x413cb2(_0x500c15),_0x2ec994,_0x14464a);};}function _0x204baa(_0x5e4db5,_0x4cbe7b,_0x269521,_0x27d5cf,_0x167817,_0x172f23){var _0x3043e4=_0x2cb272;let _0x547422,_0x3647de;try{_0x3647de=_0x21a97a(),_0x547422=_0x45642a[_0x4cbe7b],!_0x547422||_0x3647de-_0x547422['ts']>_0x1ec146[_0x3043e4(0x150)]['resetWhenQuietMs']&&_0x547422[_0x3043e4(0x1b9)]&&_0x547422['time']/_0x547422[_0x3043e4(0x1b9)]<_0x1ec146['perLogpoint']['resetOnProcessingTimeAverageMs']?(_0x45642a[_0x4cbe7b]=_0x547422={'count':0x0,'time':0x0,'ts':_0x3647de},_0x45642a[_0x3043e4(0xe4)]={}):_0x3647de-_0x45642a[_0x3043e4(0xe4)]['ts']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x121)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]/_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]<_0x1ec146[_0x3043e4(0x17b)]['resetOnProcessingTimeAverageMs']&&(_0x45642a[_0x3043e4(0xe4)]={});let _0x4ef115=[],_0xe809ad=_0x547422[_0x3043e4(0x15b)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]?_0xf3a84:_0x1c9af4,_0xb619d5=_0xa8c3fb=>{var _0x237ccb=_0x3043e4;let _0x4e7b95={};return _0x4e7b95['props']=_0xa8c3fb[_0x237ccb(0x1b8)],_0x4e7b95[_0x237ccb(0x1a7)]=_0xa8c3fb['elements'],_0x4e7b95[_0x237ccb(0x126)]=_0xa8c3fb[_0x237ccb(0x126)],_0x4e7b95[_0x237ccb(0xf2)]=_0xa8c3fb[_0x237ccb(0xf2)],_0x4e7b95[_0x237ccb(0x1c9)]=_0xa8c3fb[_0x237ccb(0x1c9)],_0x4e7b95['autoExpandMaxDepth']=_0xa8c3fb['autoExpandMaxDepth'],_0x4e7b95[_0x237ccb(0xc2)]=!0x1,_0x4e7b95[_0x237ccb(0x19f)]=!_0x5b995d,_0x4e7b95[_0x237ccb(0xd0)]=0x1,_0x4e7b95[_0x237ccb(0x1af)]=0x0,_0x4e7b95[_0x237ccb(0x1a8)]=_0x237ccb(0x1bc),_0x4e7b95[_0x237ccb(0x114)]='root_exp',_0x4e7b95[_0x237ccb(0xfe)]=!0x0,_0x4e7b95[_0x237ccb(0x102)]=[],_0x4e7b95[_0x237ccb(0x171)]=0x0,_0x4e7b95['resolveGetters']=_0xad4d21[_0x237ccb(0x117)],_0x4e7b95['allStrLength']=0x0,_0x4e7b95[_0x237ccb(0x145)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x4e7b95;};for(var _0x544924=0x0;_0x544924<_0x167817[_0x3043e4(0x10f)];_0x544924++)_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'timeNode':_0x5e4db5==='time'||void 0x0},_0x167817[_0x544924],_0xb619d5(_0xe809ad),{}));if(_0x5e4db5===_0x3043e4(0x1c0)||_0x5e4db5===_0x3043e4(0x1a0)){let _0xb54963=Error['stackTraceLimit'];try{Error[_0x3043e4(0x18a)]=0x1/0x0,_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'stackNode':!0x0},new Error()[_0x3043e4(0x1ca)],_0xb619d5(_0xe809ad),{'strLength':0x1/0x0}));}finally{Error[_0x3043e4(0x18a)]=_0xb54963;}}return{'method':'log','version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':_0x4ef115,'id':_0x4cbe7b,'context':_0x172f23}]};}catch(_0x4cace3){return{'method':_0x3043e4(0x111),'version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':[{'type':'unknown','error':_0x4cace3&&_0x4cace3['message']}],'id':_0x4cbe7b,'context':_0x172f23}]};}finally{try{if(_0x547422&&_0x3647de){let _0x54611d=_0x21a97a();_0x547422[_0x3043e4(0x1b9)]++,_0x547422[_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x547422['ts']=_0x54611d,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]++,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x45642a[_0x3043e4(0xe4)]['ts']=_0x54611d,(_0x547422[_0x3043e4(0x1b9)]>_0x1ec146[_0x3043e4(0x150)][_0x3043e4(0x148)]||_0x547422['time']>_0x1ec146[_0x3043e4(0x150)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x547422[_0x3043e4(0x15b)]=!0x0),(_0x45642a[_0x3043e4(0xe4)]['count']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x148)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0xf7)])&&(_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]=!0x0);}}catch{}}}return _0x204baa;}function G(_0x13f625){var _0x54528b=_0x1fc135;if(_0x13f625&&typeof _0x13f625==_0x54528b(0x12d)&&_0x13f625[_0x54528b(0x1a5)])switch(_0x13f625[_0x54528b(0x1a5)][_0x54528b(0x1be)]){case _0x54528b(0xd3):return _0x13f625[_0x54528b(0x177)](Symbol[_0x54528b(0x1a1)])?Promise[_0x54528b(0x190)]():_0x13f625;case _0x54528b(0xff):return Promise[_0x54528b(0x190)]();}return _0x13f625;}((_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x1665bd,_0x18cf9b,_0x28f3bf,_0x34d492,_0x102ada,_0x2185be,_0x56bcb6)=>{var _0x30ea7a=_0x1fc135;if(_0x47130b[_0x30ea7a(0x13f)])return _0x47130b[_0x30ea7a(0x13f)];let _0x20c7ea={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x47130b,_0x28f3bf,_0x5dc278))return _0x47130b[_0x30ea7a(0x13f)]=_0x20c7ea,_0x47130b[_0x30ea7a(0x13f)];let _0x48c72d=b(_0x47130b),_0x1bb7cb=_0x48c72d['elapsed'],_0x6f8a3d=_0x48c72d[_0x30ea7a(0x14b)],_0x22b15a=_0x48c72d['now'],_0x43827b={'hits':{},'ts':{}},_0x46d74=J(_0x47130b,_0x34d492,_0x43827b,_0x1665bd,_0x56bcb6,_0x5dc278===_0x30ea7a(0x130)?G:void 0x0),_0x1b94d4=(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa)=>{var _0x52c0bf=_0x30ea7a;let _0x4de224=_0x47130b[_0x52c0bf(0x13f)];try{return _0x47130b[_0x52c0bf(0x13f)]=_0x20c7ea,_0x46d74(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa);}finally{_0x47130b[_0x52c0bf(0x13f)]=_0x4de224;}},_0x4fe773=_0x2394ff=>{_0x43827b['ts'][_0x2394ff]=_0x6f8a3d();},_0x561b11=(_0x1151c5,_0x153ab7)=>{var _0x577f8a=_0x30ea7a;let _0x438ac0=_0x43827b['ts'][_0x153ab7];if(delete _0x43827b['ts'][_0x153ab7],_0x438ac0){let _0x5d6465=_0x1bb7cb(_0x438ac0,_0x6f8a3d());_0x2ba420(_0x1b94d4(_0x577f8a(0x14c),_0x1151c5,_0x22b15a(),_0x163cab,[_0x5d6465],_0x153ab7));}},_0x6d0288=_0x2be048=>{var _0x100044=_0x30ea7a,_0x2e51d9;return _0x5dc278===_0x100044(0x130)&&_0x47130b['origin']&&((_0x2e51d9=_0x2be048==null?void 0x0:_0x2be048[_0x100044(0x1b7)])==null?void 0x0:_0x2e51d9['length'])&&(_0x2be048[_0x100044(0x1b7)][0x0]['origin']=_0x47130b['origin']),_0x2be048;};_0x47130b['_console_ninja']={'consoleLog':(_0x2d5415,_0x31db20)=>{var _0x16b37d=_0x30ea7a;_0x47130b[_0x16b37d(0xcc)][_0x16b37d(0x111)]['name']!=='disabledLog'&&_0x2ba420(_0x1b94d4(_0x16b37d(0x111),_0x2d5415,_0x22b15a(),_0x163cab,_0x31db20));},'consoleTrace':(_0x3d9758,_0x4a9151)=>{var _0xb77f30=_0x30ea7a,_0x206ebc,_0x1fc11c;_0x47130b['console']['log']['name']!==_0xb77f30(0x185)&&((_0x1fc11c=(_0x206ebc=_0x47130b[_0xb77f30(0x139)])==null?void 0x0:_0x206ebc[_0xb77f30(0xe2)])!=null&&_0x1fc11c[_0xb77f30(0x145)]&&(_0x47130b[_0xb77f30(0xef)]=!0x0),_0x2ba420(_0x6d0288(_0x1b94d4(_0xb77f30(0x1c0),_0x3d9758,_0x22b15a(),_0x163cab,_0x4a9151))));},'consoleError':(_0x2167f3,_0x3018cf)=>{var _0x543849=_0x30ea7a;_0x47130b[_0x543849(0xef)]=!0x0,_0x2ba420(_0x6d0288(_0x1b94d4(_0x543849(0x1a0),_0x2167f3,_0x22b15a(),_0x163cab,_0x3018cf)));},'consoleTime':_0x585cab=>{_0x4fe773(_0x585cab);},'consoleTimeEnd':(_0x53dd91,_0x4b8a93)=>{_0x561b11(_0x4b8a93,_0x53dd91);},'autoLog':(_0x1c4fc8,_0x255231)=>{var _0x51dc3c=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x51dc3c(0x111),_0x255231,_0x22b15a(),_0x163cab,[_0x1c4fc8]));},'autoLogMany':(_0x3c95d1,_0x46977c)=>{var _0x155059=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x155059(0x111),_0x3c95d1,_0x22b15a(),_0x163cab,_0x46977c));},'autoTrace':(_0x37a9be,_0x5eb70a)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0x5eb70a,_0x22b15a(),_0x163cab,[_0x37a9be])));},'autoTraceMany':(_0xd793f3,_0x23b1c2)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0xd793f3,_0x22b15a(),_0x163cab,_0x23b1c2)));},'autoTime':(_0x391512,_0x226127,_0x4957a2)=>{_0x4fe773(_0x4957a2);},'autoTimeEnd':(_0x485f48,_0x47647b,_0x7fb4a8)=>{_0x561b11(_0x47647b,_0x7fb4a8);},'coverage':_0x5098b3=>{var _0x2c3696=_0x30ea7a;_0x2ba420({'method':_0x2c3696(0x131),'version':_0x1665bd,'args':[{'id':_0x5098b3}]});}};let _0x2ba420=H(_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x102ada,_0x2185be),_0x163cab=_0x47130b[_0x30ea7a(0x1b5)];return _0x47130b[_0x30ea7a(0x13f)];})(globalThis,_0x1fc135(0x12c),_0x1fc135(0x141),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.492\\\\node_modules\",_0x1fc135(0x1ad),_0x1fc135(0xd4),_0x1fc135(0x195),_0x1fc135(0x1a4),_0x1fc135(0xd7),_0x1fc135(0x11e),_0x1fc135(0x144),_0x1fc135(0x10d));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "OutputModel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/radio-group.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadioGroup",
    ()=>RadioGroup,
    "RadioGroupItem",
    ()=>RadioGroupItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-radio-group/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle.js [app-client] (ecmascript) <export default as CircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
function RadioGroup(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "radio-group",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("grid gap-3", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/radio-group.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = RadioGroup;
function RadioGroupItem(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"], {
        "data-slot": "radio-group-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-input text-primary focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 aspect-square size-4 shrink-0 rounded-full border shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Indicator"], {
            "data-slot": "radio-group-indicator",
            className: "relative flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__["CircleIcon"], {
                className: "fill-primary absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2"
            }, void 0, false, {
                fileName: "[project]/components/ui/radio-group.tsx",
                lineNumber: 39,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/radio-group.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ui/radio-group.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c1 = RadioGroupItem;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "RadioGroup");
__turbopack_context__.k.register(_c1, "RadioGroupItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/IndicatorEditModel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IndicatorModel",
    ()=>IndicatorModel,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/single-select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/separator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$IndicatorProvincesTargetCalculator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/IndicatorProvincesTargetCalculator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/radio-group.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ParentContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/multi-select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/FormsDefaultValues.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ConfirmationModelsTexts.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$SingleAndMultiSelectOptionsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/SingleAndMultiSelectOptionsList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/StringToCapital.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$IndicatorFormHelpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/IndicatorFormHelpers.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/GlobalHelpers.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const IndicatorModel = (param)=>{
    let { isOpen, onClose, mode, pageIdentifier, indicatorId } = param;
    var _local_subIndicator;
    _s();
    const { reqForToastAndSetMessage, axiosInstance, reqForConfirmationModelFunc } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"])();
    const { indicators, setIndicators, outputs, projectProvinces } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreatePage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditPage"])(pageIdentifier) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"])();
    const [local, setLocal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndicatorDefault"])());
    const [indicatorBeforeEdit, setIndicatorBeforeEdit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$FormsDefaultValues$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndicatorDefault"])());
    const [reqForSubIndicator, setReqForSubIndicator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleChange = (e)=>{
        const { name, value } = e.target;
        if (name == "subIndicatorName" && local.subIndicator) {
            setLocal((prev)=>({
                    ...prev,
                    subIndicator: {
                        ...prev.subIndicator,
                        name: value
                    }
                }));
            return;
        } else if (name == "subIndicatorTarget" && local.subIndicator) {
            setLocal((prev)=>({
                    ...prev,
                    subIndicator: {
                        ...prev.subIndicator,
                        target: Number(value)
                    }
                }));
            return;
        }
        setLocal((prev)=>({
                ...prev,
                [name]: name === "target" ? Number(value) : name === "type" ? value || null : value
            }));
    };
    const hundleIndicatorFormChange = (e)=>{
        const { province, name, value } = e.target;
        if (!local.subIndicator) return;
        const updatedProvinces = local.subIndicator.provinces.map((p)=>p.province === province.province ? {
                ...p,
                councilorCount: name === "subIndicatorProvinceCouncilorCount" ? Number(value) : p.councilorCount,
                target: name === "subIndicatorProvinceTarget" ? Number(value) : p.target
            } : p);
        setLocal((prev)=>({
                ...prev,
                subIndicator: {
                    ...prev.subIndicator,
                    provinces: updatedProvinces
                }
            }));
    };
    const handleAddSubIndicator = ()=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotMainDatabase"])(local.database)) {
            reqForToastAndSetMessage("Only main database can have a sub indicator.");
            return;
        }
        if (!reqForSubIndicator) {
            setLocal((prev)=>({
                    ...prev,
                    subIndicator: {
                        id: null,
                        indicatorRef: "sub-".concat(prev.indicatorRef),
                        name: "",
                        target: 0,
                        type: null,
                        dessaggregationType: prev.dessaggregationType === "session" ? "indevidual" : "session",
                        provinces: prev.provinces.map((province)=>({
                                province: province.province,
                                target: 0,
                                councilorCount: 0
                            }))
                    }
                }));
            setReqForSubIndicator(true);
        } else {
            setLocal((prev)=>({
                    ...prev,
                    subIndicator: null
                }));
            setReqForSubIndicator(false);
        }
    };
    const hundleSubmit = ()=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode)) {
            axiosInstance.post("projects/i/indicator", {
                indicator: local
            }).then((response)=>{
                setIndicators((prev)=>[
                        ...prev,
                        {
                            ...local,
                            id: response.data.data.find((indicator)=>indicator.indicatorRef == local.indicatorRef).id,
                            subIndicator: local.subIndicator ? {
                                ...local.subIndicator,
                                id: response.data.data.find((indicator)=>{
                                    var _local_subIndicator;
                                    return indicator.indicatorRef == ((_local_subIndicator = local.subIndicator) === null || _local_subIndicator === void 0 ? void 0 : _local_subIndicator.indicatorRef);
                                }).id
                            } : null
                        }
                    ]);
                setLocal((prev)=>{
                    return {
                        ...prev,
                        id: response.data.data.find((indicator)=>indicator.indicatorRef == local.indicatorRef).id,
                        subIndicator: prev.subIndicator ? {
                            ...prev.subIndicator,
                            id: response.data.data.find((indicator)=>{
                                var _local_subIndicator;
                                return indicator.indicatorRef == ((_local_subIndicator = local.subIndicator) === null || _local_subIndicator === void 0 ? void 0 : _local_subIndicator.indicatorRef);
                            }).id
                        } : null
                    };
                });
                reqForToastAndSetMessage(response.data.message);
            }).catch((error)=>{
                reqForToastAndSetMessage(error.response.data.message);
            });
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode)) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsThereAndIndicatorWithEnteredReferanceAndDefferentId"])(indicators, local)) {
                reqForToastAndSetMessage("A project can not have two indicators with same referance !");
                return;
            }
            setIndicators((prev)=>prev.map((ind)=>ind.indicatorRef == local.indicatorRef ? local : ind));
            axiosInstance.put("/projects/indicator/".concat(local.id), local).then((response)=>{
                reqForToastAndSetMessage(response.data.message);
            }).catch((error)=>reqForToastAndSetMessage(error.response.data.message));
        }
    };
    const availableDatabasesForSelection = ()=>{
        return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$SingleAndMultiSelectOptionsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["databases"].filter((opt)=>{
            if (opt.value == "main_database") {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsMainDatabaseNotAvailableForSelection"])(indicators)) return false;
            }
            return true;
        });
    };
    const availableTypes = ()=>{
        return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$SingleAndMultiSelectOptionsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indicatorTypes"].filter((opt)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCurrentTypeOptionAvailable"])(indicators, opt, local));
    };
    const savedOuputs = ()=>{
        return outputs.filter((output)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsOutputSaved"])(output)).map((output)=>({
                value: output.id,
                label: output.outputRef
            }));
    };
    const handleIndicatorProvincesChange = (provinces)=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HasSubIndicator"])(local)) {
            setLocal((prev)=>{
                return {
                    ...prev,
                    provinces: provinces.map((v)=>({
                            province: v,
                            target: 0,
                            councilorCount: 0
                        }))
                };
            });
        } else {
            setLocal((prev)=>{
                return {
                    ...prev,
                    provinces: provinces.map((v)=>({
                            province: v,
                            target: 0,
                            councilorCount: 0
                        })),
                    subIndicator: {
                        ...prev.subIndicator,
                        id: prev.subIndicator.id,
                        indicatorRef: prev.subIndicator.indicatorRef,
                        name: prev.subIndicator.name,
                        target: prev.subIndicator.target,
                        type: prev.subIndicator.type,
                        dessaggregationType: prev.subIndicator.dessaggregationType,
                        provinces: provinces.map((v)=>({
                                province: v,
                                target: 0,
                                councilorCount: 0
                            }))
                    }
                };
            });
        }
    };
    const handleCouncilorCountInputChange = (councilorCount, province)=>{
        setLocal((prev)=>{
            const updatedProvinces = prev.provinces.map((p)=>p.province === province ? {
                    ...p,
                    councilorCount: councilorCount
                } : p);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$IndicatorProvincesTargetCalculator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                ...prev,
                provinces: updatedProvinces
            }, setLocal);
            return {
                ...prev,
                provinces: updatedProvinces
            };
        });
    };
    const handleSubIndicatorCouncilorCountInputChange = (councilorCount, province)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotASubIndicator"])(local.subIndicator)) return;
        setLocal((prev)=>{
            const updatedProvinces = prev.subIndicator.provinces.map((p)=>p.province == province ? {
                    ...p,
                    councilorCount: councilorCount
                } : p);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$IndicatorProvincesTargetCalculator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateEachSubIndicatorProvinceTargetAccordingTONumberOFCouncilorCount"])({
                ...prev,
                subIndicator: {
                    ...prev.subIndicator,
                    provinces: updatedProvinces
                }
            }, setLocal);
            return {
                ...prev,
                subIndicator: {
                    ...prev.subIndicator,
                    provinces: updatedProvinces
                }
            };
        });
    };
    const handleProvinceTargetChange = (newTarget, province)=>{
        setLocal((prev)=>({
                ...prev,
                provinces: prev.provinces.map((p)=>p.province === province ? {
                        ...p,
                        target: newTarget
                    } : p)
            }));
    };
    const handleCancel = ()=>{
        const newObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$GlobalHelpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoveIdFielsFromObj"])(indicatorBeforeEdit);
        /* eslint-disable */ console.log(...oo_oo("1873544508_406_4_406_23_4", newObj));
        return;
        //TURBOPACK unreachable
        ;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "IndicatorModel.useEffect": ()=>{
            if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotANullOrUndefinedValue"])(indicatorId)) {
                axiosInstance.get("projects/indicator/".concat(indicatorId)).then({
                    "IndicatorModel.useEffect": (response)=>{
                        setLocal(response.data.data);
                        setIndicatorBeforeEdit(response.data.data);
                    }
                }["IndicatorModel.useEffect"]).catch({
                    "IndicatorModel.useEffect": (error)=>{
                        var _error_response;
                        return reqForToastAndSetMessage((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data.message);
                    }
                }["IndicatorModel.useEffect"]);
            }
        }
    }["IndicatorModel.useEffect"], [
        indicatorId,
        isOpen
    ]);
    var _local_target, _local_outputId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: isOpen,
        onOpenChange: (open)=>!open && onClose(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "sm:max-w-4xl border border-gray-300 dark:border-gray-600 rounded-lg ml-16 overflow-hidden",
            style: {
                minHeight: "85vh",
                paddingTop: "10px",
                paddingBottom: "10px",
                paddingLeft: "16px",
                paddingRight: "16px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsEditMode"])(mode) ? "Edit Indicator" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? "Create New Indicator" : "Show Indicator"
                    }, void 0, false, {
                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                        lineNumber: 444,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                    lineNumber: 443,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid gap-4 overflow-auto h-[400px]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "indicator",
                                    children: "Indicator"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 455,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                                    id: "indicator",
                                    name: "indicator",
                                    value: local.indicator || "",
                                    onChange: handleChange,
                                    placeholder: "Indicator name",
                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 456,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 454,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "indicatorRef",
                                    children: "Indicator Reference"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 467,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                    id: "indicatorRef",
                                    name: "indicatorRef",
                                    value: local.indicatorRef || "",
                                    onChange: handleChange,
                                    placeholder: "Indicator reference",
                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 468,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 466,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 flex flex-col gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                            htmlFor: "target",
                                            children: "Target"
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 480,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                            id: "target",
                                            name: "target",
                                            type: "number",
                                            value: (_local_target = local.target) !== null && _local_target !== void 0 ? _local_target : 0,
                                            onChange: handleChange,
                                            placeholder: "Target",
                                            disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 481,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 479,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 flex flex-col gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                            htmlFor: "status",
                                            children: "Status"
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 493,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                            value: local.status,
                                            onValueChange: (v)=>setLocal((prev)=>({
                                                        ...prev,
                                                        status: v
                                                    })),
                                            options: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$SingleAndMultiSelectOptionsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indicatorStatus"],
                                            placeholder: "Select status",
                                            disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 494,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 492,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 478,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-4 flex-col",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 flex flex-col gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        children: "Database"
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                        lineNumber: 508,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                        options: availableDatabasesForSelection(),
                                        value: local.database,
                                        onValueChange: (value)=>setLocal((prev)=>({
                                                    ...prev,
                                                    database: value
                                                })),
                                        disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                        lineNumber: 509,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsMainDatabase"])(local) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col gap-1 col-span-full",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                children: "Type"
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 523,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                                options: availableTypes(),
                                                value: local.type,
                                                onValueChange: (value)=>setLocal((prev)=>({
                                                            ...prev,
                                                            type: value
                                                        })),
                                                disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 524,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                        lineNumber: 522,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                lineNumber: 507,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 506,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    children: "Output"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 542,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$single$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SingleSelect"], {
                                    options: savedOuputs(),
                                    value: (_local_outputId = local.outputId) !== null && _local_outputId !== void 0 ? _local_outputId : "Unknown output",
                                    onValueChange: (value)=>setLocal((prev)=>({
                                                ...prev,
                                                outputId: value
                                            })),
                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 543,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 541,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1 col-span-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "province",
                                    children: "Indicator Provinces"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 558,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$multi$2d$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MultiSelect"], {
                                    options: (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$IndicatorFormHelpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStructuredProvinces"])(projectProvinces),
                                    value: local.provinces.map((province)=>province.province),
                                    onValueChange: (value)=>handleIndicatorProvincesChange(value),
                                    // error={indicatorFormErrors.provinces}
                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 559,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 557,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1 col-span-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "dessaggregationType",
                                    children: "Dessagreggation Type"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 572,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroup"], {
                                    name: "dessaggregationType",
                                    value: local.dessaggregationType,
                                    onValueChange: (value)=>{
                                        const e = {
                                            target: {
                                                name: "dessaggregationType",
                                                value: value
                                            }
                                        };
                                        handleChange(e);
                                    },
                                    className: "flex gap-6",
                                    children: [
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsIndicatorDatabaseMainDatabase"])(local) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroupItem"], {
                                                    value: "session",
                                                    id: "session",
                                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 586,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "session",
                                                    children: "Session"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 591,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 585,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotIndicatorDatabaseEnactDatabase"])(local) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroupItem"], {
                                                    value: "indevidual",
                                                    id: "indevidual",
                                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 597,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "individual",
                                                    children: "Indevidual"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 602,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 596,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsIndicatorDatabaseEnactDatabase"])(local) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroupItem"], {
                                                    value: "enact",
                                                    id: "enact",
                                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 608,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "enact",
                                                    children: "Enact"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 613,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 607,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 573,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 571,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        local.provinces && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-4 mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
                                    className: "my-2"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 621,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                local.provinces.map((province, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-3 gap-4 items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: province.province
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                    lineNumber: 628,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 627,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col gap-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                        htmlFor: "".concat(province.province, "-count"),
                                                        children: "Councular Count"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 631,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        id: "".concat(province.province, "-count"),
                                                        type: "number",
                                                        value: province.councilorCount,
                                                        onChange: (e)=>handleCouncilorCountInputChange(Number(e.target.value), province.province),
                                                        placeholder: "".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringToCapital"])(province.province), " Councular Count ..."),
                                                        disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 634,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 630,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col gap-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                        htmlFor: "".concat(province.province, "-target"),
                                                        children: "Target"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 651,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        id: "".concat(province.province, "-target"),
                                                        type: "number",
                                                        value: province.target || 0,
                                                        onChange: (e)=>{
                                                            handleProvinceTargetChange(Number(e.target.value), province.province);
                                                        },
                                                        placeholder: "".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringToCapital"])(province.province), " Target ..."),
                                                        disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 654,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 650,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, idx, true, {
                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                        lineNumber: 623,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 620,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "description",
                                    children: "Description"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 676,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                                    id: "description",
                                    name: "description",
                                    value: local.description || "",
                                    onChange: handleChange,
                                    placeholder: "Optional description",
                                    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 677,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 675,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        local.subIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    children: "Sub Indicator"
                                }, void 0, false, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 690,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                            name: "subIndicatorName",
                                            value: local.subIndicator.name,
                                            onChange: handleChange,
                                            placeholder: "Sub Indicator Name",
                                            disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 692,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                            name: "subIndicatorTarget",
                                            type: "number",
                                            value: local.subIndicator.target,
                                            onChange: handleChange,
                                            placeholder: "Sub Indicator Target",
                                            disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                            lineNumber: 699,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        (_local_subIndicator = local.subIndicator) === null || _local_subIndicator === void 0 ? void 0 : _local_subIndicator.provinces.map((province, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-1 md:grid-cols-3 gap-4 items-center",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringToCapital"])(province.province)
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                            lineNumber: 714,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 713,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex flex-col gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                htmlFor: "".concat(province.province, "-count"),
                                                                children: "Councular Count"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                                lineNumber: 717,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                id: "".concat(province.province, "-count"),
                                                                type: "number",
                                                                name: "subIndicatorProvinceCouncilorCount",
                                                                value: province.councilorCount || 0,
                                                                onChange: (e)=>handleSubIndicatorCouncilorCountInputChange(Number(e.target.value), province.province),
                                                                disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                                lineNumber: 720,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 716,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex flex-col gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                                htmlFor: "".concat(province.province, "-target"),
                                                                children: "Target"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                                lineNumber: 735,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                                id: "".concat(province.province, "-target"),
                                                                type: "number",
                                                                name: "subIndicatorProvinceTarget",
                                                                value: province.target || 0,
                                                                onChange: (e)=>{
                                                                    hundleIndicatorFormChange({
                                                                        target: {
                                                                            province: province,
                                                                            name: e.target.name,
                                                                            value: e.target.value
                                                                        }
                                                                    });
                                                                },
                                                                disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode)
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                                lineNumber: 738,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                        lineNumber: 734,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, index, true, {
                                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                                lineNumber: 709,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                    lineNumber: 691,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/IndicatorEditModel.tsx",
                            lineNumber: 689,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                    lineNumber: 453,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotShowMode"])(mode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogFooter"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 justify-end w-full fixed bottom-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                onClick: handleCancel,
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                lineNumber: 765,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                type: "button",
                                className: "flex items-center gap-2",
                                onClick: handleAddSubIndicator,
                                disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNotMainDatabase"])(local.database),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                        size: 16
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                        lineNumber: 774,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    reqForSubIndicator ? "Remove Sub Indicator" : "Add Sub Indicator"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                lineNumber: 768,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    reqForConfirmationModelFunc((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndicatorCreationMessage"] : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ConfirmationModelsTexts$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndicatorEditionMessage"], hundleSubmit);
                                },
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/components/global/IndicatorEditModel.tsx",
                                lineNumber: 779,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/global/IndicatorEditModel.tsx",
                        lineNumber: 764,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/global/IndicatorEditModel.tsx",
                    lineNumber: 763,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/global/IndicatorEditModel.tsx",
            lineNumber: 433,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/global/IndicatorEditModel.tsx",
        lineNumber: 432,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(IndicatorModel, "KAoK7AfM3mEpeI/AJwHDsJN45Nk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ParentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParentContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"]
    ];
});
_c = IndicatorModel;
const __TURBOPACK__default__export__ = IndicatorModel;
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5a41(_0xa94ba2,_0x20bcf7){var _0x46c9d4=_0x46c9();return _0x5a41=function(_0x5a41b7,_0x432119){_0x5a41b7=_0x5a41b7-0xc2;var _0x4ff83e=_0x46c9d4[_0x5a41b7];return _0x4ff83e;},_0x5a41(_0xa94ba2,_0x20bcf7);}var _0x1fc135=_0x5a41;(function(_0x12841d,_0x45ce02){var _0x463f09=_0x5a41,_0x3aed6f=_0x12841d();while(!![]){try{var _0xfbec5f=parseInt(_0x463f09(0x164))/0x1+-parseInt(_0x463f09(0x1c3))/0x2*(parseInt(_0x463f09(0x1ae))/0x3)+parseInt(_0x463f09(0xed))/0x4+-parseInt(_0x463f09(0x10e))/0x5+-parseInt(_0x463f09(0x132))/0x6*(-parseInt(_0x463f09(0xf4))/0x7)+-parseInt(_0x463f09(0x1bf))/0x8*(parseInt(_0x463f09(0x149))/0x9)+-parseInt(_0x463f09(0x158))/0xa*(-parseInt(_0x463f09(0x181))/0xb);if(_0xfbec5f===_0x45ce02)break;else _0x3aed6f['push'](_0x3aed6f['shift']());}catch(_0x1ddfc0){_0x3aed6f['push'](_0x3aed6f['shift']());}}}(_0x46c9,0xc9a1b));function z(_0x76ea34,_0x41accc,_0x305778,_0x1e8a8e,_0x35d5ea,_0x22fb9e){var _0x203dfc=_0x5a41,_0x53bb71,_0x56de44,_0x41daae,_0x4e3bb8;this[_0x203dfc(0x17b)]=_0x76ea34,this[_0x203dfc(0x133)]=_0x41accc,this[_0x203dfc(0xf0)]=_0x305778,this['nodeModules']=_0x1e8a8e,this[_0x203dfc(0x19d)]=_0x35d5ea,this[_0x203dfc(0x1a9)]=_0x22fb9e,this[_0x203dfc(0xdc)]=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0x203dfc(0xe9)]=!0x1,this['_connecting']=!0x1,this[_0x203dfc(0x19e)]=((_0x56de44=(_0x53bb71=_0x76ea34[_0x203dfc(0x139)])==null?void 0x0:_0x53bb71[_0x203dfc(0x11f)])==null?void 0x0:_0x56de44[_0x203dfc(0x1b3)])==='edge',this[_0x203dfc(0xcd)]=!((_0x4e3bb8=(_0x41daae=this[_0x203dfc(0x17b)]['process'])==null?void 0x0:_0x41daae[_0x203dfc(0xe2)])!=null&&_0x4e3bb8[_0x203dfc(0x145)])&&!this[_0x203dfc(0x19e)],this[_0x203dfc(0x129)]=null,this['_connectAttemptCount']=0x0,this[_0x203dfc(0x1bd)]=0x14,this[_0x203dfc(0x156)]=_0x203dfc(0xca),this[_0x203dfc(0x165)]=(this[_0x203dfc(0xcd)]?_0x203dfc(0x1b1):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this[_0x203dfc(0x156)];}function _0x46c9(){var _0x4ae90f=['autoExpandPreviousObjects','bind','resetOnProcessingTimeAverageMs','function','Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','autoExpandMaxDepth','defaultLimits','some','[object\\x20Array]','_cleanNode','_getOwnPropertyDescriptor',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'8096830gPNSKo','length','_isSet','log','reducePolicy','forEach','rootExpression','perf_hooks','isExpressionToEvaluate','resolveGetters','_ws','push','nan','_setNodeExpressionPath','readyState','_hasMapOnItsPath','','env','hrtime','resetWhenQuietMs','toString','_setNodeId',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','pop','strLength','positiveInfinity','modules','_WebSocketClass','_type','capped','127.0.0.1','object','call','POSITIVE_INFINITY','next.js','coverage','102LwRJSG','host','index','_setNodeQueryPath','HTMLAllCollection','_addLoadNode','_attemptToReconnectShortly','process','type','logger\\x20websocket\\x20error','_reconnectTimeout','getOwnPropertyNames','String','_console_ninja','gateway.docker.internal','3810','_treeNodePropertiesAfterFullValue','parse','1','node','value','_isMap','reduceOnCount','315SmJdle','close','timeStamp','time','_Symbol','_hasSymbolPropertyOnItsPath','angular','perLogpoint','default','endsWith','\\x20server','bigint','startsWith','_webSocketErrorDocsLink','_setNodeExpandableState','2976160OPTOtp','nodeModules','onopen','reduceLimits','serialize','_addProperty','concat','_getOwnPropertyNames','[object\\x20Set]','stringify','ExpoDevice','elapsed','261278GYbHMc','_sendErrorMessage','_additionalMetadata','expressionsToEvaluate','message','toLowerCase','getWebSocketClass','_setNodePermissions','WebSocket','getOwnPropertySymbols','_extendedWarning','_blacklistedProperty','warn','autoExpandPropertyCount','null','string','_addFunctionsNode','ws://','Buffer','hasOwnProperty','prototype','edge','_isArray','global','catch','slice','_undefined','then','array','66JgkQaA','includes','remix','url','disabledTrace','_allowedToConnectOnSend','_treeNodePropertiesBeforeFullValue','reload','NEGATIVE_INFINITY','stackTraceLimit','_regExpToString','...','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','reducedLimits','resolve','\\x20browser','_hasSetOnItsPath','charAt','substr','1763893057747','_socket','onmessage','_property','[object\\x20Map]','isArray','_isPrimitiveWrapperType','_getOwnPropertySymbols','dockerizedApp','_inNextEdge','noFunctions','error','iterator','onclose','_processTreeNodeResult',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'constructor','_isUndefined','elements','expId','eventReceivedCallback','import(\\x27path\\x27)','_numberRegExp','_dateToString','next.js','149349QSQLvQ','level','data','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','hostname','NEXT_RUNTIME','Map','_console_ninja_session','android','args','props','count','match','_isNegativeZero','root_exp_id','_maxConnectAttemptCount','name','196280wOXbpo','trace','Set','symbol','46iTUtwv','_keyStrRegExp','funcName','react-native','send','setter','autoExpandLimit','stack','valueOf','sortProps','_capIfString','date','set','unknown','_connectAttemptCount','_setNodeLabel','parent','https://tinyurl.com/37x8b79t','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','console','_inBrowser','number','current','depth','_objectToString','map','Promise','1.0.0','_propertyName','boolean','','_consoleNinjaAllowedToStart','_connecting','_WebSocket','path','_allowedToSend','_addObjectProperty','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','_sortProps','toUpperCase','unref','versions','ninjaSuppressConsole','hits','getOwnPropertyDescriptor','cappedElements','Number','undefined','_connected','now','getter','[object\\x20Date]','4532040FLHqEh','onerror','_ninjaIgnoreNextError','port','_disposeWebsocket','totalStrLength','location','522529oHclbe','test','replace','reduceOnAccumulatedProcessingTimeMs','fromCharCode','_p_name','allStrLength','expo','method','_HTMLAllCollection','autoExpand','bound\\x20Promise','performance','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());'];_0x46c9=function(){return _0x4ae90f;};return _0x46c9();}z[_0x1fc135(0x178)][_0x1fc135(0x16a)]=async function(){var _0x4ae121=_0x1fc135,_0x18a19c,_0x241a90;if(this['_WebSocketClass'])return this[_0x4ae121(0x129)];let _0x45de09;if(this[_0x4ae121(0xcd)]||this['_inNextEdge'])_0x45de09=this[_0x4ae121(0x17b)][_0x4ae121(0x16c)];else{if((_0x18a19c=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])!=null&&_0x18a19c[_0x4ae121(0xda)])_0x45de09=(_0x241a90=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])==null?void 0x0:_0x241a90[_0x4ae121(0xda)];else try{_0x45de09=(await new Function(_0x4ae121(0xdb),_0x4ae121(0x184),_0x4ae121(0x159),_0x4ae121(0x101))(await(0x0,eval)(_0x4ae121(0x1aa)),await(0x0,eval)('import(\\x27url\\x27)'),this['nodeModules']))[_0x4ae121(0x151)];}catch{try{_0x45de09=require(require(_0x4ae121(0xdb))['join'](this[_0x4ae121(0x159)],'ws'));}catch{throw new Error(_0x4ae121(0x18d));}}}return this['_WebSocketClass']=_0x45de09,_0x45de09;},z['prototype']['_connectToHostNow']=function(){var _0x3e8739=_0x1fc135;this[_0x3e8739(0xd9)]||this[_0x3e8739(0xe9)]||this[_0x3e8739(0xc7)]>=this['_maxConnectAttemptCount']||(this['_allowedToConnectOnSend']=!0x1,this[_0x3e8739(0xd9)]=!0x0,this[_0x3e8739(0xc7)]++,this[_0x3e8739(0x118)]=new Promise((_0x3fa28f,_0x5e9cd5)=>{var _0x21d44e=_0x3e8739;this[_0x21d44e(0x16a)]()[_0x21d44e(0x17f)](_0x3e4660=>{var _0x4002c9=_0x21d44e;let _0x265cb8=new _0x3e4660(_0x4002c9(0x175)+(!this[_0x4002c9(0xcd)]&&this[_0x4002c9(0x19d)]?_0x4002c9(0x140):this[_0x4002c9(0x133)])+':'+this[_0x4002c9(0xf0)]);_0x265cb8[_0x4002c9(0xee)]=()=>{var _0x30e6ef=_0x4002c9;this['_allowedToSend']=!0x1,this['_disposeWebsocket'](_0x265cb8),this[_0x30e6ef(0x138)](),_0x5e9cd5(new Error(_0x30e6ef(0x13b)));},_0x265cb8[_0x4002c9(0x15a)]=()=>{var _0x453b8c=_0x4002c9;this[_0x453b8c(0xcd)]||_0x265cb8[_0x453b8c(0x196)]&&_0x265cb8[_0x453b8c(0x196)][_0x453b8c(0xe1)]&&_0x265cb8['_socket'][_0x453b8c(0xe1)](),_0x3fa28f(_0x265cb8);},_0x265cb8[_0x4002c9(0x1a2)]=()=>{var _0x140e5d=_0x4002c9;this[_0x140e5d(0x186)]=!0x0,this['_disposeWebsocket'](_0x265cb8),this['_attemptToReconnectShortly']();},_0x265cb8[_0x4002c9(0x197)]=_0x45b578=>{var _0x561e4f=_0x4002c9;try{if(!(_0x45b578!=null&&_0x45b578[_0x561e4f(0x1b0)])||!this['eventReceivedCallback'])return;let _0x5c0f52=JSON[_0x561e4f(0x143)](_0x45b578[_0x561e4f(0x1b0)]);this[_0x561e4f(0x1a9)](_0x5c0f52[_0x561e4f(0xfc)],_0x5c0f52[_0x561e4f(0x1b7)],this[_0x561e4f(0x17b)],this[_0x561e4f(0xcd)]);}catch{}};})[_0x21d44e(0x17f)](_0x3522f8=>(this[_0x21d44e(0xe9)]=!0x0,this[_0x21d44e(0xd9)]=!0x1,this[_0x21d44e(0x186)]=!0x1,this[_0x21d44e(0xdc)]=!0x0,this[_0x21d44e(0xc7)]=0x0,_0x3522f8))['catch'](_0x5498dc=>(this[_0x21d44e(0xe9)]=!0x1,this[_0x21d44e(0xd9)]=!0x1,console[_0x21d44e(0x170)](_0x21d44e(0x18e)+this[_0x21d44e(0x156)]),_0x5e9cd5(new Error(_0x21d44e(0xde)+(_0x5498dc&&_0x5498dc['message'])))));}));},z[_0x1fc135(0x178)][_0x1fc135(0xf1)]=function(_0x39064e){var _0x62e767=_0x1fc135;this[_0x62e767(0xe9)]=!0x1,this[_0x62e767(0xd9)]=!0x1;try{_0x39064e[_0x62e767(0x1a2)]=null,_0x39064e['onerror']=null,_0x39064e[_0x62e767(0x15a)]=null;}catch{}try{_0x39064e[_0x62e767(0x11c)]<0x2&&_0x39064e[_0x62e767(0x14a)]();}catch{}},z[_0x1fc135(0x178)][_0x1fc135(0x138)]=function(){var _0x5da3df=_0x1fc135;clearTimeout(this[_0x5da3df(0x13c)]),!(this[_0x5da3df(0xc7)]>=this['_maxConnectAttemptCount'])&&(this['_reconnectTimeout']=setTimeout(()=>{var _0x21baad=_0x5da3df,_0x34fb09;this['_connected']||this[_0x21baad(0xd9)]||(this['_connectToHostNow'](),(_0x34fb09=this[_0x21baad(0x118)])==null||_0x34fb09[_0x21baad(0x17c)](()=>this['_attemptToReconnectShortly']()));},0x1f4),this[_0x5da3df(0x13c)]['unref']&&this['_reconnectTimeout'][_0x5da3df(0xe1)]());},z[_0x1fc135(0x178)][_0x1fc135(0x1c7)]=async function(_0x2aa022){var _0x44ea14=_0x1fc135;try{if(!this['_allowedToSend'])return;this[_0x44ea14(0x186)]&&this['_connectToHostNow'](),(await this['_ws'])['send'](JSON[_0x44ea14(0x161)](_0x2aa022));}catch(_0x516430){this[_0x44ea14(0x16e)]?console['warn'](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430['message'])):(this[_0x44ea14(0x16e)]=!0x0,console[_0x44ea14(0x170)](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430[_0x44ea14(0x168)]),_0x2aa022)),this[_0x44ea14(0xdc)]=!0x1,this[_0x44ea14(0x138)]();}};function H(_0xbed09e,_0x3de44a,_0x566e47,_0x54b39d,_0x39164d,_0x409fce,_0xbcb120,_0x4ae046=ne){var _0x51bc8b=_0x1fc135;let _0x2f5944=_0x566e47['split'](',')[_0x51bc8b(0xd2)](_0x4d018a=>{var _0x4f1217=_0x51bc8b,_0x3ff168,_0x2d1ad9,_0x57b744,_0xeff5a4,_0x7643dd,_0xd13b57,_0x3dac27;try{if(!_0xbed09e['_console_ninja_session']){let _0x4a47b6=((_0x2d1ad9=(_0x3ff168=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x3ff168[_0x4f1217(0xe2)])==null?void 0x0:_0x2d1ad9[_0x4f1217(0x145)])||((_0xeff5a4=(_0x57b744=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x57b744[_0x4f1217(0x11f)])==null?void 0x0:_0xeff5a4[_0x4f1217(0x1b3)])===_0x4f1217(0x179);(_0x39164d===_0x4f1217(0x130)||_0x39164d===_0x4f1217(0x183)||_0x39164d==='astro'||_0x39164d===_0x4f1217(0x14f))&&(_0x39164d+=_0x4a47b6?_0x4f1217(0x153):_0x4f1217(0x191));let _0x3e173e='';_0x39164d===_0x4f1217(0x1c6)&&(_0x3e173e=(((_0x3dac27=(_0xd13b57=(_0x7643dd=_0xbed09e['expo'])==null?void 0x0:_0x7643dd[_0x4f1217(0x128)])==null?void 0x0:_0xd13b57[_0x4f1217(0x162)])==null?void 0x0:_0x3dac27['osName'])||'')[_0x4f1217(0x169)](),_0x3e173e&&(_0x39164d+='\\x20'+_0x3e173e,_0x3e173e===_0x4f1217(0x1b6)&&(_0x3de44a='10.0.2.2'))),_0xbed09e['_console_ninja_session']={'id':+new Date(),'tool':_0x39164d},_0xbcb120&&_0x39164d&&!_0x4a47b6&&(_0x3e173e?console[_0x4f1217(0x111)](_0x4f1217(0x106)+_0x3e173e+_0x4f1217(0x124)):console[_0x4f1217(0x111)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0x39164d[_0x4f1217(0x193)](0x0)[_0x4f1217(0xe0)]()+_0x39164d[_0x4f1217(0x194)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'));}let _0x199336=new z(_0xbed09e,_0x3de44a,_0x4d018a,_0x54b39d,_0x409fce,_0x4ae046);return _0x199336[_0x4f1217(0x1c7)][_0x4f1217(0x103)](_0x199336);}catch(_0x33e9da){return console['warn'](_0x4f1217(0xcb),_0x33e9da&&_0x33e9da[_0x4f1217(0x168)]),()=>{};}});return _0x1956ea=>_0x2f5944[_0x51bc8b(0x113)](_0x4e6927=>_0x4e6927(_0x1956ea));}function ne(_0x116e80,_0x40cfba,_0x3b4452,_0x30cd66){var _0x890e43=_0x1fc135;_0x30cd66&&_0x116e80==='reload'&&_0x3b4452[_0x890e43(0xf3)][_0x890e43(0x188)]();}function b(_0x2601c7){var _0x326d90=_0x1fc135,_0x1a4170,_0x23ee95;let _0x531900=function(_0x27480e,_0x188dcd){return _0x188dcd-_0x27480e;},_0x2639ae;if(_0x2601c7[_0x326d90(0x100)])_0x2639ae=function(){var _0x2a5205=_0x326d90;return _0x2601c7['performance'][_0x2a5205(0xea)]();};else{if(_0x2601c7[_0x326d90(0x139)]&&_0x2601c7[_0x326d90(0x139)][_0x326d90(0x120)]&&((_0x23ee95=(_0x1a4170=_0x2601c7['process'])==null?void 0x0:_0x1a4170['env'])==null?void 0x0:_0x23ee95[_0x326d90(0x1b3)])!==_0x326d90(0x179))_0x2639ae=function(){var _0x3a41db=_0x326d90;return _0x2601c7[_0x3a41db(0x139)]['hrtime']();},_0x531900=function(_0x282f28,_0xc6af32){return 0x3e8*(_0xc6af32[0x0]-_0x282f28[0x0])+(_0xc6af32[0x1]-_0x282f28[0x1])/0xf4240;};else try{let {performance:_0x3f1ea6}=require(_0x326d90(0x115));_0x2639ae=function(){var _0x440cae=_0x326d90;return _0x3f1ea6[_0x440cae(0xea)]();};}catch{_0x2639ae=function(){return+new Date();};}}return{'elapsed':_0x531900,'timeStamp':_0x2639ae,'now':()=>Date['now']()};}function X(_0x23d2d9,_0x30bba7,_0x37042b){var _0x5f50f2=_0x1fc135,_0x142aeb,_0x43891d,_0x2c7083,_0x1efb74,_0x3655da,_0x2f04a6,_0x122ade,_0x31dc28,_0x472369;if(_0x23d2d9[_0x5f50f2(0xd8)]!==void 0x0)return _0x23d2d9[_0x5f50f2(0xd8)];let _0x45b226=((_0x43891d=(_0x142aeb=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x142aeb[_0x5f50f2(0xe2)])==null?void 0x0:_0x43891d[_0x5f50f2(0x145)])||((_0x1efb74=(_0x2c7083=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x2c7083[_0x5f50f2(0x11f)])==null?void 0x0:_0x1efb74[_0x5f50f2(0x1b3)])===_0x5f50f2(0x179),_0x36082e=!!(_0x37042b===_0x5f50f2(0x1c6)&&((_0x122ade=(_0x2f04a6=(_0x3655da=_0x23d2d9[_0x5f50f2(0xfb)])==null?void 0x0:_0x3655da[_0x5f50f2(0x128)])==null?void 0x0:_0x2f04a6[_0x5f50f2(0x162)])==null?void 0x0:_0x122ade['osName']));function _0x21c350(_0x2bf556){var _0x2c5e4b=_0x5f50f2;if(_0x2bf556[_0x2c5e4b(0x155)]('/')&&_0x2bf556[_0x2c5e4b(0x152)]('/')){let _0x267dc2=new RegExp(_0x2bf556[_0x2c5e4b(0x17d)](0x1,-0x1));return _0x4e19cc=>_0x267dc2[_0x2c5e4b(0xf5)](_0x4e19cc);}else{if(_0x2bf556[_0x2c5e4b(0x182)]('*')||_0x2bf556[_0x2c5e4b(0x182)]('?')){let _0x234e74=new RegExp('^'+_0x2bf556['replace'](/\\./g,String[_0x2c5e4b(0xf8)](0x5c)+'.')[_0x2c5e4b(0xf6)](/\\*/g,'.*')[_0x2c5e4b(0xf6)](/\\?/g,'.')+String[_0x2c5e4b(0xf8)](0x24));return _0x35cfab=>_0x234e74[_0x2c5e4b(0xf5)](_0x35cfab);}else return _0x16c4db=>_0x16c4db===_0x2bf556;}}let _0x725fc=_0x30bba7[_0x5f50f2(0xd2)](_0x21c350);return _0x23d2d9[_0x5f50f2(0xd8)]=_0x45b226||!_0x30bba7,!_0x23d2d9[_0x5f50f2(0xd8)]&&((_0x31dc28=_0x23d2d9[_0x5f50f2(0xf3)])==null?void 0x0:_0x31dc28['hostname'])&&(_0x23d2d9['_consoleNinjaAllowedToStart']=_0x725fc[_0x5f50f2(0x109)](_0x367574=>_0x367574(_0x23d2d9[_0x5f50f2(0xf3)]['hostname']))),_0x36082e&&!_0x23d2d9['_consoleNinjaAllowedToStart']&&!((_0x472369=_0x23d2d9[_0x5f50f2(0xf3)])!=null&&_0x472369[_0x5f50f2(0x1b2)])&&(_0x23d2d9[_0x5f50f2(0xd8)]=!0x0),_0x23d2d9[_0x5f50f2(0xd8)];}function J(_0x5873aa,_0x5b995d,_0x45642a,_0x5b3c4b,_0xad4d21,_0x413cb2){var _0x2cb272=_0x1fc135;_0x5873aa=_0x5873aa,_0x5b995d=_0x5b995d,_0x45642a=_0x45642a,_0x5b3c4b=_0x5b3c4b,_0xad4d21=_0xad4d21,_0xad4d21=_0xad4d21||{},_0xad4d21[_0x2cb272(0x108)]=_0xad4d21[_0x2cb272(0x108)]||{},_0xad4d21[_0x2cb272(0x18f)]=_0xad4d21[_0x2cb272(0x18f)]||{},_0xad4d21[_0x2cb272(0x112)]=_0xad4d21['reducePolicy']||{},_0xad4d21['reducePolicy'][_0x2cb272(0x150)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)]||{},_0xad4d21['reducePolicy'][_0x2cb272(0x17b)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]||{};let _0x1ec146={'perLogpoint':{'reduceOnCount':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x148)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21['reducePolicy']['perLogpoint'][_0x2cb272(0xf7)]||0x64,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)][_0x2cb272(0x121)]||0x1f4,'resetOnProcessingTimeAverageMs':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x104)]||0x64},'global':{'reduceOnCount':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0x148)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0xf7)]||0x12c,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetWhenQuietMs']||0x32,'resetOnProcessingTimeAverageMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetOnProcessingTimeAverageMs']||0x64}},_0x40a3a3=b(_0x5873aa),_0x48338=_0x40a3a3[_0x2cb272(0x163)],_0x21a97a=_0x40a3a3[_0x2cb272(0x14b)];function _0x4de4d2(){var _0x3d3e0d=_0x2cb272;this[_0x3d3e0d(0x1c4)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x3d3e0d(0x1ab)]=/^(0|[1-9][0-9]*)$/,this['_quotedRegExp']=/'([^\\\\']|\\\\')*'/,this[_0x3d3e0d(0x17e)]=_0x5873aa['undefined'],this[_0x3d3e0d(0xfd)]=_0x5873aa['HTMLAllCollection'],this[_0x3d3e0d(0x10c)]=Object[_0x3d3e0d(0xe5)],this[_0x3d3e0d(0x15f)]=Object[_0x3d3e0d(0x13d)],this[_0x3d3e0d(0x14d)]=_0x5873aa['Symbol'],this['_regExpToString']=RegExp[_0x3d3e0d(0x178)][_0x3d3e0d(0x122)],this[_0x3d3e0d(0x1ac)]=Date['prototype'][_0x3d3e0d(0x122)];}_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15c)]=function(_0x27724c,_0xe7c38a,_0x3efad1,_0x4054fc){var _0x23455e=_0x2cb272,_0x47d7be=this,_0x252550=_0x3efad1['autoExpand'];function _0x58ac21(_0x3aa5ed,_0x5c0803,_0x52ecd3){var _0x9a2757=_0x5a41;_0x5c0803['type']='unknown',_0x5c0803[_0x9a2757(0x1a0)]=_0x3aa5ed[_0x9a2757(0x168)],_0x3e44c3=_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)],_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)]=_0x5c0803,_0x47d7be[_0x9a2757(0x187)](_0x5c0803,_0x52ecd3);}let _0xbd937b,_0x4a2288,_0x241cc=_0x5873aa['ninjaSuppressConsole'];_0x5873aa['ninjaSuppressConsole']=!0x0,_0x5873aa[_0x23455e(0xcc)]&&(_0xbd937b=_0x5873aa[_0x23455e(0xcc)]['error'],_0x4a2288=_0x5873aa['console'][_0x23455e(0x170)],_0xbd937b&&(_0x5873aa['console']['error']=function(){}),_0x4a2288&&(_0x5873aa['console'][_0x23455e(0x170)]=function(){}));try{try{_0x3efad1[_0x23455e(0x1af)]++,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x102)][_0x23455e(0x119)](_0xe7c38a);var _0x6cd2d3,_0x2b585b,_0x2a5db7,_0x3c44b3,_0x496c9e=[],_0x333092=[],_0x4329e3,_0x5c61c1=this['_type'](_0xe7c38a),_0x2cfc15=_0x5c61c1===_0x23455e(0x180),_0x17237c=!0x1,_0x27360a=_0x5c61c1==='function',_0x4d346e=this['_isPrimitiveType'](_0x5c61c1),_0x249206=this[_0x23455e(0x19b)](_0x5c61c1),_0x3c5b1d=_0x4d346e||_0x249206,_0x16b4fc={},_0x368b87=0x0,_0x46e586=!0x1,_0x3e44c3,_0x4deeb0=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x3efad1['depth']){if(_0x2cfc15){if(_0x2b585b=_0xe7c38a[_0x23455e(0x10f)],_0x2b585b>_0x3efad1[_0x23455e(0x1a7)]){for(_0x2a5db7=0x0,_0x3c44b3=_0x3efad1[_0x23455e(0x1a7)],_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0x15d)](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));_0x27724c[_0x23455e(0xe6)]=!0x0;}else{for(_0x2a5db7=0x0,_0x3c44b3=_0x2b585b,_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));}_0x3efad1[_0x23455e(0x171)]+=_0x333092['length'];}if(!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&!_0x4d346e&&_0x5c61c1!==_0x23455e(0x13e)&&_0x5c61c1!==_0x23455e(0x176)&&_0x5c61c1!==_0x23455e(0x154)){var _0x504faa=_0x4054fc['props']||_0x3efad1['props'];if(this['_isSet'](_0xe7c38a)?(_0x6cd2d3=0x0,_0xe7c38a[_0x23455e(0x113)](function(_0x116948){var _0x29bff9=_0x23455e;if(_0x368b87++,_0x3efad1[_0x29bff9(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1['isExpressionToEvaluate']&&_0x3efad1['autoExpand']&&_0x3efad1['autoExpandPropertyCount']>_0x3efad1['autoExpandLimit']){_0x46e586=!0x0;return;}_0x333092['push'](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x29bff9(0x1c1),_0x6cd2d3++,_0x3efad1,function(_0x5b68ce){return function(){return _0x5b68ce;};}(_0x116948)));})):this['_isMap'](_0xe7c38a)&&_0xe7c38a[_0x23455e(0x113)](function(_0x32011f,_0x2c19ff){var _0x585ade=_0x23455e;if(_0x368b87++,_0x3efad1[_0x585ade(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1[_0x585ade(0x116)]&&_0x3efad1[_0x585ade(0xfe)]&&_0x3efad1[_0x585ade(0x171)]>_0x3efad1[_0x585ade(0x1c9)]){_0x46e586=!0x0;return;}var _0x34b418=_0x2c19ff[_0x585ade(0x122)]();_0x34b418[_0x585ade(0x10f)]>0x64&&(_0x34b418=_0x34b418[_0x585ade(0x17d)](0x0,0x64)+_0x585ade(0x18c)),_0x333092[_0x585ade(0x119)](_0x47d7be[_0x585ade(0x15d)](_0x496c9e,_0xe7c38a,'Map',_0x34b418,_0x3efad1,function(_0x3df5a8){return function(){return _0x3df5a8;};}(_0x32011f)));}),!_0x17237c){try{for(_0x4329e3 in _0xe7c38a)if(!(_0x2cfc15&&_0x4deeb0['test'](_0x4329e3))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0xdd)](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}catch{}if(_0x16b4fc['_p_length']=!0x0,_0x27360a&&(_0x16b4fc[_0x23455e(0xf9)]=!0x0),!_0x46e586){var _0x1a196c=[][_0x23455e(0x15e)](this['_getOwnPropertyNames'](_0xe7c38a))[_0x23455e(0x15e)](this[_0x23455e(0x19c)](_0xe7c38a));for(_0x6cd2d3=0x0,_0x2b585b=_0x1a196c[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)if(_0x4329e3=_0x1a196c[_0x6cd2d3],!(_0x2cfc15&&_0x4deeb0[_0x23455e(0xf5)](_0x4329e3[_0x23455e(0x122)]()))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)&&!_0x16b4fc[typeof _0x4329e3!=_0x23455e(0x1c2)?'_p_'+_0x4329e3[_0x23455e(0x122)]():_0x4329e3]){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be['_addObjectProperty'](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}}}}if(_0x27724c[_0x23455e(0x13a)]=_0x5c61c1,_0x3c5b1d?(_0x27724c[_0x23455e(0x146)]=_0xe7c38a[_0x23455e(0x1cb)](),this['_capIfString'](_0x5c61c1,_0x27724c,_0x3efad1,_0x4054fc)):_0x5c61c1===_0x23455e(0xc4)?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x1ac)]['call'](_0xe7c38a):_0x5c61c1===_0x23455e(0x154)?_0x27724c['value']=_0xe7c38a[_0x23455e(0x122)]():_0x5c61c1==='RegExp'?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x18b)][_0x23455e(0x12e)](_0xe7c38a):_0x5c61c1===_0x23455e(0x1c2)&&this[_0x23455e(0x14d)]?_0x27724c[_0x23455e(0x146)]=this['_Symbol'][_0x23455e(0x178)][_0x23455e(0x122)]['call'](_0xe7c38a):!_0x3efad1[_0x23455e(0xd0)]&&!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&(delete _0x27724c[_0x23455e(0x146)],_0x27724c[_0x23455e(0x12b)]=!0x0),_0x46e586&&(_0x27724c['cappedProps']=!0x0),_0x3e44c3=_0x3efad1[_0x23455e(0x145)][_0x23455e(0xcf)],_0x3efad1['node'][_0x23455e(0xcf)]=_0x27724c,this['_treeNodePropertiesBeforeFullValue'](_0x27724c,_0x3efad1),_0x333092[_0x23455e(0x10f)]){for(_0x6cd2d3=0x0,_0x2b585b=_0x333092[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)_0x333092[_0x6cd2d3](_0x6cd2d3);}_0x496c9e['length']&&(_0x27724c['props']=_0x496c9e);}catch(_0x4444a){_0x58ac21(_0x4444a,_0x27724c,_0x3efad1);}this['_additionalMetadata'](_0xe7c38a,_0x27724c),this['_treeNodePropertiesAfterFullValue'](_0x27724c,_0x3efad1),_0x3efad1['node'][_0x23455e(0xcf)]=_0x3e44c3,_0x3efad1[_0x23455e(0x1af)]--,_0x3efad1[_0x23455e(0xfe)]=_0x252550,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1['autoExpandPreviousObjects'][_0x23455e(0x125)]();}finally{_0xbd937b&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x1a0)]=_0xbd937b),_0x4a2288&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x170)]=_0x4a2288),_0x5873aa[_0x23455e(0xe3)]=_0x241cc;}return _0x27724c;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x19c)]=function(_0x4e35d2){var _0x1be40a=_0x2cb272;return Object[_0x1be40a(0x16d)]?Object['getOwnPropertySymbols'](_0x4e35d2):[];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x110)]=function(_0x2fe3c7){var _0x1bfa34=_0x2cb272;return!!(_0x2fe3c7&&_0x5873aa[_0x1bfa34(0x1c1)]&&this[_0x1bfa34(0xd1)](_0x2fe3c7)===_0x1bfa34(0x160)&&_0x2fe3c7[_0x1bfa34(0x113)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16f)]=function(_0x1247ea,_0x4ab5f4,_0x3e79c9){var _0x5f57fc=_0x2cb272;if(!_0x3e79c9[_0x5f57fc(0x117)]){let _0x5b1ca2=this[_0x5f57fc(0x10c)](_0x1247ea,_0x4ab5f4);if(_0x5b1ca2&&_0x5b1ca2['get'])return!0x0;}return _0x3e79c9[_0x5f57fc(0x19f)]?typeof _0x1247ea[_0x4ab5f4]==_0x5f57fc(0x105):!0x1;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x12a)]=function(_0x855594){var _0x4849c4=_0x2cb272,_0x2b6119='';return _0x2b6119=typeof _0x855594,_0x2b6119===_0x4849c4(0x12d)?this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0x10a)?_0x2b6119=_0x4849c4(0x180):this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0xec)?_0x2b6119=_0x4849c4(0xc4):this[_0x4849c4(0xd1)](_0x855594)==='[object\\x20BigInt]'?_0x2b6119=_0x4849c4(0x154):_0x855594===null?_0x2b6119=_0x4849c4(0x172):_0x855594['constructor']&&(_0x2b6119=_0x855594['constructor'][_0x4849c4(0x1be)]||_0x2b6119):_0x2b6119==='undefined'&&this['_HTMLAllCollection']&&_0x855594 instanceof this['_HTMLAllCollection']&&(_0x2b6119=_0x4849c4(0x136)),_0x2b6119;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xd1)]=function(_0x2d378a){var _0x42e9e1=_0x2cb272;return Object[_0x42e9e1(0x178)]['toString'][_0x42e9e1(0x12e)](_0x2d378a);},_0x4de4d2['prototype']['_isPrimitiveType']=function(_0x49489e){var _0x4d59c8=_0x2cb272;return _0x49489e===_0x4d59c8(0xd6)||_0x49489e==='string'||_0x49489e==='number';},_0x4de4d2[_0x2cb272(0x178)]['_isPrimitiveWrapperType']=function(_0x5ad54d){var _0x362e66=_0x2cb272;return _0x5ad54d==='Boolean'||_0x5ad54d===_0x362e66(0x13e)||_0x5ad54d===_0x362e66(0xe7);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15d)]=function(_0x4fe9b7,_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91){var _0x502d7d=this;return function(_0x1e15bc){var _0x3c5173=_0x5a41,_0x49048b=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xcf)],_0x381145=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)],_0x563aae=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)];_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)]=_0x49048b,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=typeof _0x511187==_0x3c5173(0xce)?_0x511187:_0x1e15bc,_0x4fe9b7['push'](_0x502d7d[_0x3c5173(0x198)](_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91)),_0x76c4bc['node'][_0x3c5173(0xc9)]=_0x563aae,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=_0x381145;};},_0x4de4d2['prototype']['_addObjectProperty']=function(_0x178345,_0x303198,_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38){var _0x562f19=_0x2cb272,_0x1bbfd2=this;return _0x303198[typeof _0x1945f8!=_0x562f19(0x1c2)?'_p_'+_0x1945f8[_0x562f19(0x122)]():_0x1945f8]=!0x0,function(_0x3b9835){var _0x5c127c=_0x562f19,_0x561160=_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xcf)],_0x3fc84f=_0x586d1c['node'][_0x5c127c(0x134)],_0x43d53f=_0x586d1c['node'][_0x5c127c(0xc9)];_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xc9)]=_0x561160,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3b9835,_0x178345[_0x5c127c(0x119)](_0x1bbfd2[_0x5c127c(0x198)](_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38)),_0x586d1c[_0x5c127c(0x145)]['parent']=_0x43d53f,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3fc84f;};},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x198)]=function(_0x67eb30,_0x29f374,_0x5d83f7,_0x29b358,_0x30cd4d){var _0x1a4c0e=_0x2cb272,_0x2885fe=this;_0x30cd4d||(_0x30cd4d=function(_0x196fec,_0x2c514e){return _0x196fec[_0x2c514e];});var _0x4369db=_0x5d83f7[_0x1a4c0e(0x122)](),_0x9761b4=_0x29b358[_0x1a4c0e(0x167)]||{},_0x586f06=_0x29b358[_0x1a4c0e(0xd0)],_0x3a48b1=_0x29b358['isExpressionToEvaluate'];try{var _0x52f87b=this[_0x1a4c0e(0x147)](_0x67eb30),_0x4741cd=_0x4369db;_0x52f87b&&_0x4741cd[0x0]==='\\x27'&&(_0x4741cd=_0x4741cd[_0x1a4c0e(0x194)](0x1,_0x4741cd[_0x1a4c0e(0x10f)]-0x2));var _0x5d5769=_0x29b358['expressionsToEvaluate']=_0x9761b4['_p_'+_0x4741cd];_0x5d5769&&(_0x29b358['depth']=_0x29b358[_0x1a4c0e(0xd0)]+0x1),_0x29b358['isExpressionToEvaluate']=!!_0x5d5769;var _0x10cb78=typeof _0x5d83f7=='symbol',_0x330f9d={'name':_0x10cb78||_0x52f87b?_0x4369db:this[_0x1a4c0e(0xd5)](_0x4369db)};if(_0x10cb78&&(_0x330f9d[_0x1a4c0e(0x1c2)]=!0x0),!(_0x29f374===_0x1a4c0e(0x180)||_0x29f374==='Error')){var _0x14f906=this['_getOwnPropertyDescriptor'](_0x67eb30,_0x5d83f7);if(_0x14f906&&(_0x14f906[_0x1a4c0e(0xc5)]&&(_0x330f9d[_0x1a4c0e(0x1c8)]=!0x0),_0x14f906['get']&&!_0x5d5769&&!_0x29b358[_0x1a4c0e(0x117)]))return _0x330f9d[_0x1a4c0e(0xeb)]=!0x0,this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x58877c;try{_0x58877c=_0x30cd4d(_0x67eb30,_0x5d83f7);}catch(_0x14f629){return _0x330f9d={'name':_0x4369db,'type':_0x1a4c0e(0xc6),'error':_0x14f629[_0x1a4c0e(0x168)]},this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x102988=this['_type'](_0x58877c),_0x49a64d=this['_isPrimitiveType'](_0x102988);if(_0x330f9d['type']=_0x102988,_0x49a64d)this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x42b519=_0x1a4c0e;_0x330f9d['value']=_0x58877c[_0x42b519(0x1cb)](),!_0x5d5769&&_0x2885fe[_0x42b519(0xc3)](_0x102988,_0x330f9d,_0x29b358,{});});else{var _0x580aa0=_0x29b358[_0x1a4c0e(0xfe)]&&_0x29b358[_0x1a4c0e(0x1af)]<_0x29b358[_0x1a4c0e(0x107)]&&_0x29b358[_0x1a4c0e(0x102)]['indexOf'](_0x58877c)<0x0&&_0x102988!==_0x1a4c0e(0x105)&&_0x29b358['autoExpandPropertyCount']<_0x29b358[_0x1a4c0e(0x1c9)];_0x580aa0||_0x29b358[_0x1a4c0e(0x1af)]<_0x586f06||_0x5d5769?this['serialize'](_0x330f9d,_0x58877c,_0x29b358,_0x5d5769||{}):this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x492fd5=_0x1a4c0e;_0x102988===_0x492fd5(0x172)||_0x102988==='undefined'||(delete _0x330f9d[_0x492fd5(0x146)],_0x330f9d[_0x492fd5(0x12b)]=!0x0);});}return _0x330f9d;}finally{_0x29b358[_0x1a4c0e(0x167)]=_0x9761b4,_0x29b358['depth']=_0x586f06,_0x29b358[_0x1a4c0e(0x116)]=_0x3a48b1;}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc3)]=function(_0x52cb19,_0x54c144,_0x3e334e,_0x532699){var _0x3f3b07=_0x2cb272,_0x2ca270=_0x532699[_0x3f3b07(0x126)]||_0x3e334e['strLength'];if((_0x52cb19==='string'||_0x52cb19===_0x3f3b07(0x13e))&&_0x54c144[_0x3f3b07(0x146)]){let _0x160821=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x10f)];_0x3e334e[_0x3f3b07(0xfa)]+=_0x160821,_0x3e334e[_0x3f3b07(0xfa)]>_0x3e334e['totalStrLength']?(_0x54c144['capped']='',delete _0x54c144[_0x3f3b07(0x146)]):_0x160821>_0x2ca270&&(_0x54c144['capped']=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x194)](0x0,_0x2ca270),delete _0x54c144[_0x3f3b07(0x146)]);}},_0x4de4d2['prototype']['_isMap']=function(_0x18d6a6){var _0x3c7fd5=_0x2cb272;return!!(_0x18d6a6&&_0x5873aa['Map']&&this[_0x3c7fd5(0xd1)](_0x18d6a6)===_0x3c7fd5(0x199)&&_0x18d6a6[_0x3c7fd5(0x113)]);},_0x4de4d2[_0x2cb272(0x178)]['_propertyName']=function(_0x947ebf){var _0x531112=_0x2cb272;if(_0x947ebf[_0x531112(0x1ba)](/^\\d+$/))return _0x947ebf;var _0x9a15b4;try{_0x9a15b4=JSON['stringify'](''+_0x947ebf);}catch{_0x9a15b4='\\x22'+this['_objectToString'](_0x947ebf)+'\\x22';}return _0x9a15b4[_0x531112(0x1ba)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x9a15b4=_0x9a15b4[_0x531112(0x194)](0x1,_0x9a15b4[_0x531112(0x10f)]-0x2):_0x9a15b4=_0x9a15b4['replace'](/'/g,'\\x5c\\x27')[_0x531112(0xf6)](/\\\\\"/g,'\\x22')[_0x531112(0xf6)](/(^\"|\"$)/g,'\\x27'),_0x9a15b4;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1a3)]=function(_0x35e665,_0x2101c2,_0xab9652,_0x1c446e){var _0x3971dc=_0x2cb272;this[_0x3971dc(0x187)](_0x35e665,_0x2101c2),_0x1c446e&&_0x1c446e(),this[_0x3971dc(0x166)](_0xab9652,_0x35e665),this[_0x3971dc(0x142)](_0x35e665,_0x2101c2);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x187)]=function(_0x44b450,_0x34a33b){var _0x25ebc5=_0x2cb272;this[_0x25ebc5(0x123)](_0x44b450,_0x34a33b),this[_0x25ebc5(0x135)](_0x44b450,_0x34a33b),this['_setNodeExpressionPath'](_0x44b450,_0x34a33b),this[_0x25ebc5(0x16b)](_0x44b450,_0x34a33b);},_0x4de4d2['prototype'][_0x2cb272(0x123)]=function(_0x533ba7,_0x208597){},_0x4de4d2['prototype'][_0x2cb272(0x135)]=function(_0x1c215c,_0x404f13){},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc8)]=function(_0x4fbee4,_0x4ecb21){},_0x4de4d2['prototype'][_0x2cb272(0x1a6)]=function(_0x41a1f1){var _0x327560=_0x2cb272;return _0x41a1f1===this[_0x327560(0x17e)];},_0x4de4d2[_0x2cb272(0x178)]['_treeNodePropertiesAfterFullValue']=function(_0x48ca53,_0x268d68){var _0x2e622c=_0x2cb272;this[_0x2e622c(0xc8)](_0x48ca53,_0x268d68),this[_0x2e622c(0x157)](_0x48ca53),_0x268d68[_0x2e622c(0xc2)]&&this[_0x2e622c(0xdf)](_0x48ca53),this['_addFunctionsNode'](_0x48ca53,_0x268d68),this[_0x2e622c(0x137)](_0x48ca53,_0x268d68),this[_0x2e622c(0x10b)](_0x48ca53);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x166)]=function(_0x2678a0,_0x259c0d){var _0x36fdc4=_0x2cb272;try{_0x2678a0&&typeof _0x2678a0[_0x36fdc4(0x10f)]==_0x36fdc4(0xce)&&(_0x259c0d[_0x36fdc4(0x10f)]=_0x2678a0[_0x36fdc4(0x10f)]);}catch{}if(_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xce)||_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xe7)){if(isNaN(_0x259c0d['value']))_0x259c0d[_0x36fdc4(0x11a)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];else switch(_0x259c0d['value']){case Number[_0x36fdc4(0x12f)]:_0x259c0d[_0x36fdc4(0x127)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case Number[_0x36fdc4(0x189)]:_0x259c0d['negativeInfinity']=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case 0x0:this['_isNegativeZero'](_0x259c0d['value'])&&(_0x259c0d['negativeZero']=!0x0);break;}}else _0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0x105)&&typeof _0x2678a0[_0x36fdc4(0x1be)]==_0x36fdc4(0x173)&&_0x2678a0['name']&&_0x259c0d[_0x36fdc4(0x1be)]&&_0x2678a0[_0x36fdc4(0x1be)]!==_0x259c0d['name']&&(_0x259c0d[_0x36fdc4(0x1c5)]=_0x2678a0[_0x36fdc4(0x1be)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1bb)]=function(_0x31e8d6){return 0x1/_0x31e8d6===Number['NEGATIVE_INFINITY'];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xdf)]=function(_0x5387a1){var _0xf6510d=_0x2cb272;!_0x5387a1[_0xf6510d(0x1b8)]||!_0x5387a1['props'][_0xf6510d(0x10f)]||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x180)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1b4)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1c1)||_0x5387a1['props']['sort'](function(_0x47dd16,_0x585d58){var _0x14b330=_0xf6510d,_0x13e486=_0x47dd16[_0x14b330(0x1be)][_0x14b330(0x169)](),_0x486976=_0x585d58[_0x14b330(0x1be)]['toLowerCase']();return _0x13e486<_0x486976?-0x1:_0x13e486>_0x486976?0x1:0x0;});},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x174)]=function(_0x222b24,_0x769935){var _0x84e84d=_0x2cb272;if(!(_0x769935['noFunctions']||!_0x222b24['props']||!_0x222b24['props'][_0x84e84d(0x10f)])){for(var _0x730840=[],_0x3e54f2=[],_0x12e05b=0x0,_0x14c80d=_0x222b24['props'][_0x84e84d(0x10f)];_0x12e05b<_0x14c80d;_0x12e05b++){var _0x227177=_0x222b24['props'][_0x12e05b];_0x227177[_0x84e84d(0x13a)]===_0x84e84d(0x105)?_0x730840[_0x84e84d(0x119)](_0x227177):_0x3e54f2['push'](_0x227177);}if(!(!_0x3e54f2[_0x84e84d(0x10f)]||_0x730840[_0x84e84d(0x10f)]<=0x1)){_0x222b24[_0x84e84d(0x1b8)]=_0x3e54f2;var _0x4768f5={'functionsNode':!0x0,'props':_0x730840};this['_setNodeId'](_0x4768f5,_0x769935),this[_0x84e84d(0xc8)](_0x4768f5,_0x769935),this[_0x84e84d(0x157)](_0x4768f5),this[_0x84e84d(0x16b)](_0x4768f5,_0x769935),_0x4768f5['id']+='\\x20f',_0x222b24['props']['unshift'](_0x4768f5);}}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x137)]=function(_0x563c3f,_0x4419b7){},_0x4de4d2['prototype'][_0x2cb272(0x157)]=function(_0x497fff){},_0x4de4d2['prototype'][_0x2cb272(0x17a)]=function(_0x1b9882){var _0x3294c4=_0x2cb272;return Array[_0x3294c4(0x19a)](_0x1b9882)||typeof _0x1b9882==_0x3294c4(0x12d)&&this[_0x3294c4(0xd1)](_0x1b9882)===_0x3294c4(0x10a);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16b)]=function(_0x9d1c25,_0x314f15){},_0x4de4d2['prototype']['_cleanNode']=function(_0x1d1f32){var _0x54d4ff=_0x2cb272;delete _0x1d1f32[_0x54d4ff(0x14e)],delete _0x1d1f32[_0x54d4ff(0x192)],delete _0x1d1f32[_0x54d4ff(0x11d)];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x11b)]=function(_0x263d9a,_0x3e2e45){};let _0xaaf654=new _0x4de4d2(),_0x1c9af4={'props':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x1b8)]||0x64,'elements':_0xad4d21['defaultLimits'][_0x2cb272(0x1a7)]||0x64,'strLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x126)]||0x400*0x32,'totalStrLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0xf2)]||0x400*0x32,'autoExpandLimit':_0xad4d21['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0xad4d21['defaultLimits'][_0x2cb272(0x107)]||0xa},_0xf3a84={'props':_0xad4d21[_0x2cb272(0x18f)]['props']||0x5,'elements':_0xad4d21['reducedLimits'][_0x2cb272(0x1a7)]||0x5,'strLength':_0xad4d21['reducedLimits'][_0x2cb272(0x126)]||0x100,'totalStrLength':_0xad4d21[_0x2cb272(0x18f)][_0x2cb272(0xf2)]||0x100*0x3,'autoExpandLimit':_0xad4d21['reducedLimits'][_0x2cb272(0x1c9)]||0x1e,'autoExpandMaxDepth':_0xad4d21['reducedLimits'][_0x2cb272(0x107)]||0x2};if(_0x413cb2){let _0x4ae918=_0xaaf654[_0x2cb272(0x15c)]['bind'](_0xaaf654);_0xaaf654[_0x2cb272(0x15c)]=function(_0x40ecf2,_0x500c15,_0x2ec994,_0x14464a){return _0x4ae918(_0x40ecf2,_0x413cb2(_0x500c15),_0x2ec994,_0x14464a);};}function _0x204baa(_0x5e4db5,_0x4cbe7b,_0x269521,_0x27d5cf,_0x167817,_0x172f23){var _0x3043e4=_0x2cb272;let _0x547422,_0x3647de;try{_0x3647de=_0x21a97a(),_0x547422=_0x45642a[_0x4cbe7b],!_0x547422||_0x3647de-_0x547422['ts']>_0x1ec146[_0x3043e4(0x150)]['resetWhenQuietMs']&&_0x547422[_0x3043e4(0x1b9)]&&_0x547422['time']/_0x547422[_0x3043e4(0x1b9)]<_0x1ec146['perLogpoint']['resetOnProcessingTimeAverageMs']?(_0x45642a[_0x4cbe7b]=_0x547422={'count':0x0,'time':0x0,'ts':_0x3647de},_0x45642a[_0x3043e4(0xe4)]={}):_0x3647de-_0x45642a[_0x3043e4(0xe4)]['ts']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x121)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]/_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]<_0x1ec146[_0x3043e4(0x17b)]['resetOnProcessingTimeAverageMs']&&(_0x45642a[_0x3043e4(0xe4)]={});let _0x4ef115=[],_0xe809ad=_0x547422[_0x3043e4(0x15b)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]?_0xf3a84:_0x1c9af4,_0xb619d5=_0xa8c3fb=>{var _0x237ccb=_0x3043e4;let _0x4e7b95={};return _0x4e7b95['props']=_0xa8c3fb[_0x237ccb(0x1b8)],_0x4e7b95[_0x237ccb(0x1a7)]=_0xa8c3fb['elements'],_0x4e7b95[_0x237ccb(0x126)]=_0xa8c3fb[_0x237ccb(0x126)],_0x4e7b95[_0x237ccb(0xf2)]=_0xa8c3fb[_0x237ccb(0xf2)],_0x4e7b95[_0x237ccb(0x1c9)]=_0xa8c3fb[_0x237ccb(0x1c9)],_0x4e7b95['autoExpandMaxDepth']=_0xa8c3fb['autoExpandMaxDepth'],_0x4e7b95[_0x237ccb(0xc2)]=!0x1,_0x4e7b95[_0x237ccb(0x19f)]=!_0x5b995d,_0x4e7b95[_0x237ccb(0xd0)]=0x1,_0x4e7b95[_0x237ccb(0x1af)]=0x0,_0x4e7b95[_0x237ccb(0x1a8)]=_0x237ccb(0x1bc),_0x4e7b95[_0x237ccb(0x114)]='root_exp',_0x4e7b95[_0x237ccb(0xfe)]=!0x0,_0x4e7b95[_0x237ccb(0x102)]=[],_0x4e7b95[_0x237ccb(0x171)]=0x0,_0x4e7b95['resolveGetters']=_0xad4d21[_0x237ccb(0x117)],_0x4e7b95['allStrLength']=0x0,_0x4e7b95[_0x237ccb(0x145)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x4e7b95;};for(var _0x544924=0x0;_0x544924<_0x167817[_0x3043e4(0x10f)];_0x544924++)_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'timeNode':_0x5e4db5==='time'||void 0x0},_0x167817[_0x544924],_0xb619d5(_0xe809ad),{}));if(_0x5e4db5===_0x3043e4(0x1c0)||_0x5e4db5===_0x3043e4(0x1a0)){let _0xb54963=Error['stackTraceLimit'];try{Error[_0x3043e4(0x18a)]=0x1/0x0,_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'stackNode':!0x0},new Error()[_0x3043e4(0x1ca)],_0xb619d5(_0xe809ad),{'strLength':0x1/0x0}));}finally{Error[_0x3043e4(0x18a)]=_0xb54963;}}return{'method':'log','version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':_0x4ef115,'id':_0x4cbe7b,'context':_0x172f23}]};}catch(_0x4cace3){return{'method':_0x3043e4(0x111),'version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':[{'type':'unknown','error':_0x4cace3&&_0x4cace3['message']}],'id':_0x4cbe7b,'context':_0x172f23}]};}finally{try{if(_0x547422&&_0x3647de){let _0x54611d=_0x21a97a();_0x547422[_0x3043e4(0x1b9)]++,_0x547422[_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x547422['ts']=_0x54611d,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]++,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x45642a[_0x3043e4(0xe4)]['ts']=_0x54611d,(_0x547422[_0x3043e4(0x1b9)]>_0x1ec146[_0x3043e4(0x150)][_0x3043e4(0x148)]||_0x547422['time']>_0x1ec146[_0x3043e4(0x150)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x547422[_0x3043e4(0x15b)]=!0x0),(_0x45642a[_0x3043e4(0xe4)]['count']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x148)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0xf7)])&&(_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]=!0x0);}}catch{}}}return _0x204baa;}function G(_0x13f625){var _0x54528b=_0x1fc135;if(_0x13f625&&typeof _0x13f625==_0x54528b(0x12d)&&_0x13f625[_0x54528b(0x1a5)])switch(_0x13f625[_0x54528b(0x1a5)][_0x54528b(0x1be)]){case _0x54528b(0xd3):return _0x13f625[_0x54528b(0x177)](Symbol[_0x54528b(0x1a1)])?Promise[_0x54528b(0x190)]():_0x13f625;case _0x54528b(0xff):return Promise[_0x54528b(0x190)]();}return _0x13f625;}((_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x1665bd,_0x18cf9b,_0x28f3bf,_0x34d492,_0x102ada,_0x2185be,_0x56bcb6)=>{var _0x30ea7a=_0x1fc135;if(_0x47130b[_0x30ea7a(0x13f)])return _0x47130b[_0x30ea7a(0x13f)];let _0x20c7ea={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x47130b,_0x28f3bf,_0x5dc278))return _0x47130b[_0x30ea7a(0x13f)]=_0x20c7ea,_0x47130b[_0x30ea7a(0x13f)];let _0x48c72d=b(_0x47130b),_0x1bb7cb=_0x48c72d['elapsed'],_0x6f8a3d=_0x48c72d[_0x30ea7a(0x14b)],_0x22b15a=_0x48c72d['now'],_0x43827b={'hits':{},'ts':{}},_0x46d74=J(_0x47130b,_0x34d492,_0x43827b,_0x1665bd,_0x56bcb6,_0x5dc278===_0x30ea7a(0x130)?G:void 0x0),_0x1b94d4=(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa)=>{var _0x52c0bf=_0x30ea7a;let _0x4de224=_0x47130b[_0x52c0bf(0x13f)];try{return _0x47130b[_0x52c0bf(0x13f)]=_0x20c7ea,_0x46d74(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa);}finally{_0x47130b[_0x52c0bf(0x13f)]=_0x4de224;}},_0x4fe773=_0x2394ff=>{_0x43827b['ts'][_0x2394ff]=_0x6f8a3d();},_0x561b11=(_0x1151c5,_0x153ab7)=>{var _0x577f8a=_0x30ea7a;let _0x438ac0=_0x43827b['ts'][_0x153ab7];if(delete _0x43827b['ts'][_0x153ab7],_0x438ac0){let _0x5d6465=_0x1bb7cb(_0x438ac0,_0x6f8a3d());_0x2ba420(_0x1b94d4(_0x577f8a(0x14c),_0x1151c5,_0x22b15a(),_0x163cab,[_0x5d6465],_0x153ab7));}},_0x6d0288=_0x2be048=>{var _0x100044=_0x30ea7a,_0x2e51d9;return _0x5dc278===_0x100044(0x130)&&_0x47130b['origin']&&((_0x2e51d9=_0x2be048==null?void 0x0:_0x2be048[_0x100044(0x1b7)])==null?void 0x0:_0x2e51d9['length'])&&(_0x2be048[_0x100044(0x1b7)][0x0]['origin']=_0x47130b['origin']),_0x2be048;};_0x47130b['_console_ninja']={'consoleLog':(_0x2d5415,_0x31db20)=>{var _0x16b37d=_0x30ea7a;_0x47130b[_0x16b37d(0xcc)][_0x16b37d(0x111)]['name']!=='disabledLog'&&_0x2ba420(_0x1b94d4(_0x16b37d(0x111),_0x2d5415,_0x22b15a(),_0x163cab,_0x31db20));},'consoleTrace':(_0x3d9758,_0x4a9151)=>{var _0xb77f30=_0x30ea7a,_0x206ebc,_0x1fc11c;_0x47130b['console']['log']['name']!==_0xb77f30(0x185)&&((_0x1fc11c=(_0x206ebc=_0x47130b[_0xb77f30(0x139)])==null?void 0x0:_0x206ebc[_0xb77f30(0xe2)])!=null&&_0x1fc11c[_0xb77f30(0x145)]&&(_0x47130b[_0xb77f30(0xef)]=!0x0),_0x2ba420(_0x6d0288(_0x1b94d4(_0xb77f30(0x1c0),_0x3d9758,_0x22b15a(),_0x163cab,_0x4a9151))));},'consoleError':(_0x2167f3,_0x3018cf)=>{var _0x543849=_0x30ea7a;_0x47130b[_0x543849(0xef)]=!0x0,_0x2ba420(_0x6d0288(_0x1b94d4(_0x543849(0x1a0),_0x2167f3,_0x22b15a(),_0x163cab,_0x3018cf)));},'consoleTime':_0x585cab=>{_0x4fe773(_0x585cab);},'consoleTimeEnd':(_0x53dd91,_0x4b8a93)=>{_0x561b11(_0x4b8a93,_0x53dd91);},'autoLog':(_0x1c4fc8,_0x255231)=>{var _0x51dc3c=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x51dc3c(0x111),_0x255231,_0x22b15a(),_0x163cab,[_0x1c4fc8]));},'autoLogMany':(_0x3c95d1,_0x46977c)=>{var _0x155059=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x155059(0x111),_0x3c95d1,_0x22b15a(),_0x163cab,_0x46977c));},'autoTrace':(_0x37a9be,_0x5eb70a)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0x5eb70a,_0x22b15a(),_0x163cab,[_0x37a9be])));},'autoTraceMany':(_0xd793f3,_0x23b1c2)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0xd793f3,_0x22b15a(),_0x163cab,_0x23b1c2)));},'autoTime':(_0x391512,_0x226127,_0x4957a2)=>{_0x4fe773(_0x4957a2);},'autoTimeEnd':(_0x485f48,_0x47647b,_0x7fb4a8)=>{_0x561b11(_0x47647b,_0x7fb4a8);},'coverage':_0x5098b3=>{var _0x2c3696=_0x30ea7a;_0x2ba420({'method':_0x2c3696(0x131),'version':_0x1665bd,'args':[{'id':_0x5098b3}]});}};let _0x2ba420=H(_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x102ada,_0x2185be),_0x163cab=_0x47130b[_0x30ea7a(0x1b5)];return _0x47130b[_0x30ea7a(0x13f)];})(globalThis,_0x1fc135(0x12c),_0x1fc135(0x141),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.492\\\\node_modules\",_0x1fc135(0x1ad),_0x1fc135(0xd4),_0x1fc135(0x195),_0x1fc135(0x1a4),_0x1fc135(0xd7),_0x1fc135(0x11e),_0x1fc135(0x144),_0x1fc135(0x10d));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "IndicatorModel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/global/ExcelSheet.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/create_new_project/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/edit_project/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/project_show/[id]/page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
const MonitoringTablePage = (param)=>{
    let { mode } = param;
    _s();
    const { outcomes, projectGoal, outputs, indicators, dessaggregations, projectProvinces } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsCreateMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsShowMode"])(mode) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"])();
    // Data for creating the preview of the final apr in apr preview TabContent.
    const finalDataForAprPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "MonitoringTablePage.useMemo[finalDataForAprPreview]": ()=>{
            return {
                impact: projectGoal,
                outcomes: outcomes.map({
                    "MonitoringTablePage.useMemo[finalDataForAprPreview]": (outcome)=>({
                            name: outcome.outcome,
                            outputs: outputs.filter({
                                "MonitoringTablePage.useMemo[finalDataForAprPreview]": (output)=>output.outcomeId === outcome.id
                            }["MonitoringTablePage.useMemo[finalDataForAprPreview]"]).map({
                                "MonitoringTablePage.useMemo[finalDataForAprPreview]": (output)=>({
                                        name: output.output,
                                        indicators: indicators.filter({
                                            "MonitoringTablePage.useMemo[finalDataForAprPreview]": (indicator)=>indicator.outputRef === output.outputRef
                                        }["MonitoringTablePage.useMemo[finalDataForAprPreview]"]).flatMap({
                                            "MonitoringTablePage.useMemo[finalDataForAprPreview]": (indicator)=>{
                                                const main = {
                                                    code: indicator.indicatorRef,
                                                    name: indicator.indicator,
                                                    target: indicator.target,
                                                    disaggregation: dessaggregations.filter({
                                                        "MonitoringTablePage.useMemo[finalDataForAprPreview]": (d)=>d.indicatorRef === indicator.indicatorRef
                                                    }["MonitoringTablePage.useMemo[finalDataForAprPreview]"]).map({
                                                        "MonitoringTablePage.useMemo[finalDataForAprPreview]": (d)=>({
                                                                name: "".concat(d.dessaggration, "     (").concat(d.province, ")"),
                                                                target: d.target,
                                                                province: d.province
                                                            })
                                                    }["MonitoringTablePage.useMemo[finalDataForAprPreview]"])
                                                };
                                                let sub = null;
                                                if (indicator.subIndicator != null) sub = {
                                                    code: indicator.indicatorRef,
                                                    name: indicator.subIndicator.name,
                                                    target: indicator.subIndicator.target,
                                                    isSub: true,
                                                    disaggregation: dessaggregations.filter({
                                                        "MonitoringTablePage.useMemo[finalDataForAprPreview]": (d)=>d.indicatorRef === "sub-".concat(indicator.indicatorRef)
                                                    }["MonitoringTablePage.useMemo[finalDataForAprPreview]"]).map({
                                                        "MonitoringTablePage.useMemo[finalDataForAprPreview]": (d)=>({
                                                                name: "".concat(d.dessaggration, "     (").concat(d.province, ")"),
                                                                target: d.target,
                                                                province: d.province
                                                            })
                                                    }["MonitoringTablePage.useMemo[finalDataForAprPreview]"])
                                                };
                                                if (sub) return [
                                                    main,
                                                    sub
                                                ];
                                                return [
                                                    main
                                                ];
                                            }
                                        }["MonitoringTablePage.useMemo[finalDataForAprPreview]"])
                                    })
                            }["MonitoringTablePage.useMemo[finalDataForAprPreview]"])
                        })
                }["MonitoringTablePage.useMemo[finalDataForAprPreview]"])
            };
        }
    }["MonitoringTablePage.useMemo[finalDataForAprPreview]"], [
        outcomes,
        outputs,
        indicators,
        dessaggregations,
        projectGoal
    ]);
    const [selectedProvince, setSelectedProvince] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Master");
    const [isFullscreen, setIsFullscreen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const sheetRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const toggleFullscreen = ()=>{
        if (!document.fullscreenElement && sheetRef.current) {
            sheetRef.current.requestFullscreen().then(()=>{
                setIsFullscreen(true);
                if (sheetRef.current) {
                    sheetRef.current.style.height = "100%";
                    sheetRef.current.style.overflow = "auto";
                }
            });
        } else {
            document.exitFullscreen().then(()=>{
                setIsFullscreen(false);
                if (sheetRef.current) {
                    sheetRef.current.style.height = "";
                    sheetRef.current.style.overflow = "";
                }
            });
        }
    };
    const filterDisaggregation = (dis)=>dis.filter((d)=>{
            var _d_province;
            return selectedProvince === "Master" || ((_d_province = d.province) === null || _d_province === void 0 ? void 0 : _d_province.trim().toLowerCase()) === selectedProvince.trim().toLowerCase();
        });
    const rowsPerIndicator = (ind)=>1 + filterDisaggregation(ind.disaggregation).length;
    const rowsPerOutput = (out)=>out.indicators.reduce((s, ind)=>s + rowsPerIndicator(ind), 0);
    const rowsPerOutcome = (oc)=>oc.outputs.reduce((s, out)=>s + rowsPerOutput(out), 0);
    const totalRows = finalDataForAprPreview.outcomes.reduce((s, oc)=>s + rowsPerOutcome(oc), 0);
    const rows = [];
    finalDataForAprPreview.outcomes.forEach((outcome, oIndex)=>{
        const outcomeRowSpan = rowsPerOutcome(outcome);
        outcome.outputs.forEach((output, opIndex)=>{
            const outputRowSpan = rowsPerOutput(output);
            output.indicators.filter((ind)=>filterDisaggregation(ind.disaggregation).length > 0).forEach((indicator, iIndex)=>{
                const filteredDisaggregation = filterDisaggregation(indicator.disaggregation);
                const showImpact = oIndex === 0 && opIndex === 0 && iIndex === 0;
                const showOutcome = opIndex === 0 && iIndex === 0;
                const showOutput = iIndex === 0;
                rows.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                    children: [
                        showImpact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                            rowSpan: totalRows,
                            className: "text-sm font-semibold whitespace-normal break-words border-r border-slate-300 align-middle text-center py-2 px-2",
                            children: finalDataForAprPreview.impact
                        }, void 0, false, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 169,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        showOutcome && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                            rowSpan: outcomeRowSpan,
                            className: "text-sm whitespace-normal break-words border-r border-slate-300 align-middle text-center py-2 px-2",
                            children: outcome.name
                        }, void 0, false, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 178,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        showOutput && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                            rowSpan: outputRowSpan,
                            className: "text-sm whitespace-normal break-words border-r border-slate-300 align-middle text-center py-2 px-2",
                            children: output.name
                        }, void 0, false, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 187,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                            className: "text-sm whitespace-normal break-words border-r border-slate-300 py-2 px-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold",
                                    children: indicator.code
                                }, void 0, false, {
                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                    lineNumber: 196,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xs",
                                    children: indicator.name
                                }, void 0, false, {
                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                    lineNumber: 197,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 195,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                            className: "text-right font-semibold text-sm py-2 px-2",
                            children: indicator.target
                        }, void 0, false, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 200,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, "main-".concat(oIndex, "-").concat(opIndex, "-").concat(iIndex), true, {
                    fileName: "[project]/components/global/ExcelSheet.tsx",
                    lineNumber: 167,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)));
                filteredDisaggregation.forEach((d, dIndex)=>{
                    const isLastDisaggregation = dIndex === filteredDisaggregation.length - 1;
                    const borderClass = !indicator.isSub && isLastDisaggregation ? "border-b-2 border-slate-400" : "border-b border-slate-300";
                    rows.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                        className: borderClass,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                className: "text-xs border-r border-slate-300 pl-6 py-0.5",
                                children: d.name
                            }, void 0, false, {
                                fileName: "[project]/components/global/ExcelSheet.tsx",
                                lineNumber: 219,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                className: "text-right text-xs py-0.5",
                                children: d.target
                            }, void 0, false, {
                                fileName: "[project]/components/global/ExcelSheet.tsx",
                                lineNumber: 222,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, "dis-".concat(oIndex, "-").concat(opIndex, "-").concat(iIndex, "-").concat(dIndex), true, {
                        fileName: "[project]/components/global/ExcelSheet.tsx",
                        lineNumber: 215,
                        columnNumber: 15
                    }, ("TURBOPACK compile-time value", void 0)));
                });
            });
        });
    });
    const readOnly = mode == "show";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-6 space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "outline",
                    onClick: toggleFullscreen,
                    children: isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"
                }, void 0, false, {
                    fileName: "[project]/components/global/ExcelSheet.tsx",
                    lineNumber: 237,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/global/ExcelSheet.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: sheetRef,
                className: "space-y-6 rounded-md shadow p-4",
                children: [
                    isFullscreen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "flex flex-wrap gap-3 p-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                            checked: selectedProvince === "Master",
                                            onCheckedChange: ()=>setSelectedProvince("Master")
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/ExcelSheet.tsx",
                                            lineNumber: 248,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-xs",
                                            children: "Master"
                                        }, void 0, false, {
                                            fileName: "[project]/components/global/ExcelSheet.tsx",
                                            lineNumber: 252,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                    lineNumber: 247,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                projectProvinces.map((province)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center space-x-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                                checked: selectedProvince === province,
                                                onCheckedChange: ()=>setSelectedProvince(province)
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/ExcelSheet.tsx",
                                                lineNumber: 258,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "text-xs",
                                                children: province
                                            }, void 0, false, {
                                                fileName: "[project]/components/global/ExcelSheet.tsx",
                                                lineNumber: 262,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, province, true, {
                                        fileName: "[project]/components/global/ExcelSheet.tsx",
                                        lineNumber: 257,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 245,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/global/ExcelSheet.tsx",
                        lineNumber: 244,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "p-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Table"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                            className: "bg-green-600 text-sm hover:bg-green-600",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "border-r text-center py-2 px-2",
                                                    children: "Impact/Goal (LFA)"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                                    lineNumber: 274,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "border-r text-center py-2 px-2",
                                                    children: "Result/Outcome"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                                    lineNumber: 277,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "border-r text-center py-2 px-2",
                                                    children: "Outputs"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                                    lineNumber: 280,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "border-r text-center py-2 px-2",
                                                    children: "Indicators"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                                    lineNumber: 283,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "text-right py-2 px-2",
                                                    children: "Target"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/global/ExcelSheet.tsx",
                                                    lineNumber: 286,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/global/ExcelSheet.tsx",
                                            lineNumber: 273,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/ExcelSheet.tsx",
                                        lineNumber: 272,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableBody"], {
                                        children: rows
                                    }, void 0, false, {
                                        fileName: "[project]/components/global/ExcelSheet.tsx",
                                        lineNumber: 289,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/global/ExcelSheet.tsx",
                                lineNumber: 271,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/global/ExcelSheet.tsx",
                            lineNumber: 270,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/global/ExcelSheet.tsx",
                        lineNumber: 269,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/global/ExcelSheet.tsx",
                lineNumber: 242,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/global/ExcelSheet.tsx",
        lineNumber: 235,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(MonitoringTablePage, "A9/NwggbwWiv2+vHq071Phoadho=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$create_new_project$2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$project_show$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectShowContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$edit_project$2f5b$id$5d2f$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProjectEditContext"]
    ];
});
_c = MonitoringTablePage;
const __TURBOPACK__default__export__ = MonitoringTablePage;
var _c;
__turbopack_context__.k.register(_c, "MonitoringTablePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_d6f49269._.js.map