(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_63b3624d._.js",
  "static/chunks/node_modules_160e8129._.js"
],
    source: "dynamic"
});
