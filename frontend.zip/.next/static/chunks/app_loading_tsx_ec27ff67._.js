(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/loading.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const sampleImages = [
    "/preloader1.webp",
    "/preloader2.webp",
    "/preloader3.webp",
    "/preloader4.webp",
    "/preloader5.webp"
];
const Preloader = (param)=>{
    let { duration = 4000 } = param;
    _s();
    const [show, setShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [imagePositions, setImagePositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Preloader.useEffect": ()=>{
            const count = 100;
            const size = 120;
            const positions = Array(count).fill(0).map({
                "Preloader.useEffect.positions": (_, i)=>{
                    const rotate = Math.random() * 20 - 10;
                    const scale = 0.8 + Math.random() * 0.4;
                    return {
                        src: sampleImages[i % sampleImages.length],
                        left: Math.random() * (window.innerWidth - size),
                        top: Math.random() * (window.innerHeight - size),
                        rotate,
                        scale
                    };
                }
            }["Preloader.useEffect.positions"]);
            setImagePositions(positions);
            const fadeIn = setTimeout({
                "Preloader.useEffect.fadeIn": ()=>setVisible(true)
            }["Preloader.useEffect.fadeIn"], 50);
            // const fadeOut = setTimeout(() => setVisible(false), duration - 400);
            // const hide = setTimeout(() => setShow(false), duration);
            return ({
                "Preloader.useEffect": ()=>{
                //   clearTimeout(fadeIn);
                //   clearTimeout(fadeOut);
                //   clearTimeout(hide);
                }
            })["Preloader.useEffect"];
        }
    }["Preloader.useEffect"], []);
    if (!show) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black overflow-hidden transition-all duration-400 ".concat(visible ? "opacity-100 scale-100" : "opacity-0 scale-95"),
        children: [
            imagePositions.map((img, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: img.src,
                    alt: "bg-".concat(i),
                    className: "absolute rounded-lg shadow-lg object-cover transition-all duration-500",
                    style: {
                        width: 120,
                        height: 120,
                        left: img.left,
                        top: img.top,
                        transform: "rotate(".concat(img.rotate, "deg) scale(").concat(img.scale, ")")
                    }
                }, i, false, {
                    fileName: "[project]/app/loading.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-green-400 dark:bg-blue-500 opacity-80 mix-blend-screen transition-opacity duration-400"
            }, void 0, false, {
                fileName: "[project]/app/loading.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 transition-all duration-400",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/logo.jpg",
                    alt: "logo",
                    className: "w-36 h-36 brightness-125 rounded-full shadow-xl"
                }, void 0, false, {
                    fileName: "[project]/app/loading.tsx",
                    lineNumber: 87,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/loading.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/loading.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Preloader, "HaFT8ZvbOtD6oR9MxRX6YosK28E=");
_c = Preloader;
const __TURBOPACK__default__export__ = Preloader;
var _c;
__turbopack_context__.k.register(_c, "Preloader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_loading_tsx_ec27ff67._.js.map