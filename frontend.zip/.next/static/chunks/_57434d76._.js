(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/definitions/DataTableColumnsDefinitions.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "beneficiaryKitListColumns",
    ()=>beneficiaryKitListColumns,
    "beneficiarySessionsTableColumn",
    ()=>beneficiarySessionsTableColumn,
    "communityDialoguesSessionTableColumns",
    ()=>communityDialoguesSessionTableColumns,
    "communityDialoguesTableColumns",
    ()=>communityDialoguesTableColumns,
    "enactTableColumn",
    ()=>enactTableColumn,
    "mainDatabaseAndKitDatabaseBeneficiaryColumns",
    ()=>mainDatabaseAndKitDatabaseBeneficiaryColumns,
    "mainDatabaseAndKitDatabaseProgramColumns",
    ()=>mainDatabaseAndKitDatabaseProgramColumns,
    "permissionColumns",
    ()=>permissionColumns,
    "projectColumns",
    ()=>projectColumns,
    "psychoeducationTableListColumn",
    ()=>psychoeducationTableListColumn,
    "roleColumns",
    ()=>roleColumns,
    "submittedAndFirstApprovedDatabasesTableColumn",
    ()=>submittedAndFirstApprovedDatabasesTableColumn,
    "trainingDatabaseBeneificiaryListColumn",
    ()=>trainingDatabaseBeneificiaryListColumn,
    "trainingsListColumns",
    ()=>trainingsListColumns,
    "userColumns",
    ()=>userColumns
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-up-down.js [app-client] (ecmascript) <export default as ArrowUpDown>");
;
;
;
;
const userColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "name",
        header: "Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "capitalize max-w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "email",
        header: (param)=>{
            let { column } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                variant: "ghost",
                onClick: ()=>column.toggleSorting(column.getIsSorted() === "asc"),
                children: [
                    "Email",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$up$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowUpDown$3e$__["ArrowUpDown"], {}, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lowercase max-w-[100px] truncate",
                title: row.getValue("email"),
                children: row.getValue("email")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "title",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Title"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 74,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("title");
        }
    },
    {
        accessorKey: "status",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Status"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 79,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            switch(row.getValue("status")){
                case "active":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-green-500 text-white",
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 84,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
                case "deactive":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-amber-300 text-white",
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 90,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
                case "blocked":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-red-600 text-white",
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 96,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
            }
        }
    },
    {
        accessorKey: "updated_by",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Updated By"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 105,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            var _row_getValue;
            return (_row_getValue = row.getValue("updated_by")) !== null && _row_getValue !== void 0 ? _row_getValue : "Not updated yet !";
        }
    },
    {
        accessorKey: "created_date",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Created at"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 110,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("updated_date");
        }
    },
    {
        accessorKey: "updated_date",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Updated at"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 115,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("updated_date");
        }
    },
    {
        accessorKey: "created_by",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Created By"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 120,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("created_by");
        }
    }
];
const roleColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "name",
        header: "Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "capitalize w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "status",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Status"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 163,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            switch(row.getValue("status")){
                case "active":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-green-500 text-white truncate",
                        title: row.getValue("status"),
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 168,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
                case "deactive":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-amber-300 text-white truncate",
                        title: row.getValue("status"),
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 177,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
                case "blocked":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-[70px] text-center rounded-2xl bg-red-600 text-white truncate",
                        title: row.getValue("status"),
                        children: row.getValue("status")
                    }, void 0, false, {
                        fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                        lineNumber: 186,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0));
            }
        }
    },
    {
        accessorKey: "created_at",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Created at"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 198,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("created_at");
        }
    },
    {
        accessorKey: "updated_at",
        header: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-left",
                children: "Updated at"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 203,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
        cell: (param)=>{
            let { row } = param;
            return row.getValue("updated_at");
        }
    }
];
const permissionColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 212,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 223,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "name",
        header: "Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "capitalize max-w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "label",
        header: "Label",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "capitalize max-w-[100px] truncate",
                title: row.getValue("label"),
                children: row.getValue("label")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 248,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "group_name",
        header: "Group Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "capitalize max-w-[100px] truncate",
                title: row.getValue("group_name"),
                children: row.getValue("group_name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 260,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const projectColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 274,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 285,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "projectCode",
        header: "Project Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 298,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "projectTitle",
        header: "Project Title",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectTitle"),
                children: row.getValue("projectTitle")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 310,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "projectGoal",
        header: "Project Goal",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectGoal"),
                children: row.getValue("projectGoal")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 322,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "projectDonor",
        header: "Project Donor",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectDonor"),
                children: row.getValue("projectDonor")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 334,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "startDate",
        header: "Start Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("startDate"),
                children: row.getValue("startDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 346,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "endDate",
        header: "End Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("endDate"),
                children: row.getValue("endDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 355,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("status"),
                children: row.getValue("status")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 364,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "projectManager",
        header: "Project Manager",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectManager"),
                children: row.getValue("projectManager")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 373,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "reportingDate",
        header: "Reporting Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("reportingDate"),
                children: row.getValue("reportingDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 385,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "reportingPeriod",
        header: "Reporting Period",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("reportingPeriod"),
                children: row.getValue("reportingPeriod")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 397,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "description",
        header: "Description",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("description"),
                children: row.getValue("description")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 409,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const mainDatabaseAndKitDatabaseProgramColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 423,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "database",
        header: "Database Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("database"),
                children: row.getValue("database")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 447,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "projectCode",
        header: "Project Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 456,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "focalPoint",
        header: "Focal Point",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("focalPoint"),
                children: row.getValue("focalPoint")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 468,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "province",
        header: "Province Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("province"),
                children: row.getValue("province")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 480,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "district",
        header: "District",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("district"),
                children: row.getValue("district")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 489,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "village",
        header: "Village",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("village"),
                children: row.getValue("village")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 498,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "siteCode",
        header: "Site Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("siteCode"),
                children: row.getValue("siteCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 507,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "healthFacilityName",
        header: "Health Facility Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("healthFacilityName"),
                children: row.getValue("healthFacilityName")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 516,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "interventionModality",
        header: "Intervention Modality",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("interventionModality"),
                children: row.getValue("interventionModality")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 528,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const mainDatabaseAndKitDatabaseBeneficiaryColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 543,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 553,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "focalPoint",
        header: "Program",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("focalPoint"),
                children: row.getValue("focalPoint")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 566,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    // {
    //   accessorKey: "indicators",
    //   header: "Indicators",
    //   cell: ({ row }) => <div>{(row.getValue("indicators") as []).join(", ")}</div>,
    // },
    {
        accessorKey: "dateOfRegistration",
        header: "Date of Registration",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("dateOfRegistration"),
                children: row.getValue("dateOfRegistration")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 583,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "code",
        header: "Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("code"),
                children: row.getValue("code")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 595,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "name",
        header: "Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 604,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "fatherHusbandName",
        header: "Father/Husband Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("fatherHusbandName"),
                children: row.getValue("fatherHusbandName")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 613,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "gender",
        header: "Gender",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("gender"),
                children: row.getValue("gender")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 625,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "age",
        header: "Age",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("age"),
                children: row.getValue("age")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 634,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "maritalStatus",
        header: "Marital Status",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("maritalStatus"),
                children: row.getValue("maritalStatus")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 643,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "childCode",
        header: "Child Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("childCode"),
                children: row.getValue("childCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 655,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "childAge",
        header: "Age of Child",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("childAge"),
                children: row.getValue("childAge")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 667,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "phone",
        header: "Phone",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("phone"),
                children: row.getValue("phone")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 679,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "householdStatus",
        header: "Household Status",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("householdStatus"),
                children: row.getValue("householdStatus")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 688,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "literacyLevel",
        header: "Literacy Level",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("literacyLevel"),
                children: row.getValue("literacyLevel")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 700,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "disabilityType",
        header: "Disability Type",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("disabilityType"),
                children: row.getValue("disabilityType")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 712,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "referredForProtection",
        header: "Referred for Protection",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("referredForProtection"),
                children: row.getValue("referredForProtection") ? "Yes" : "No"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 724,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const beneficiaryKitListColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 738,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 748,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "kit",
        header: "Kit",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("kit"),
                children: row.getValue("kit")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 761,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "distributionDate",
        header: "Distribution Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("distributionDate"),
                children: row.getValue("distributionDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 770,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "isReceived",
        header: "Is Received",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("isReceived"),
                children: row.getValue("isReceived")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 782,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "remark",
        header: "Remark",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("remark"),
                children: row.getValue("remark")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 794,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const trainingsListColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                onClick: (e)=>e.stopPropagation(),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 805,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 816,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "projectCode",
        header: "Project Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 829,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "province",
        header: "Province",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("province"),
                children: row.getValue("province")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 841,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "district",
        header: "District",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("district"),
                children: row.getValue("district")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 850,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "indicator",
        header: "Indicator",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("indicator"),
                children: row.getValue("indicator")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 859,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "trainingLocation",
        header: "Location",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("trainingLocation"),
                children: row.getValue("trainingLocation")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 868,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "name",
        header: "Training Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 880,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "participantCatagory",
        header: "Participant Catagory",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("participantCatagory"),
                children: row.getValue("participantCatagory")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 889,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "aprIncluded",
        header: "APR Included",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("aprIncluded"),
                children: row.getValue("aprIncluded") ? "Yes" : "No"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 901,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "trainingModality",
        header: "Modality",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("trainingModality"),
                children: row.getValue("trainingModality")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 913,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "startDate",
        header: "Start Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("startDate"),
                children: row.getValue("startDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 925,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "endDate",
        header: "End Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("endDate"),
                children: row.getValue("endDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 934,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const trainingDatabaseBeneificiaryListColumn = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onClick: (e)=>e.stopPropagation(),
                onPointerDown: (e)=>e.stopPropagation(),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                    checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                    onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                    onClick: (e)=>e.stopPropagation(),
                    "aria-label": "Select all"
                }, void 0, false, {
                    fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                    lineNumber: 950,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 946,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 964,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "name",
        header: "Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("name"),
                children: row.getValue("name")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 977,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "fatherHusbandName",
        header: "Father / Husband Name",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("fatherHusbandName"),
                children: row.getValue("fatherHusbandName")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 986,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "gender",
        header: "Gender",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("gender"),
                children: row.getValue("gender")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 998,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "age",
        header: "Age",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("age"),
                children: row.getValue("age")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1007,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "phone",
        header: "Phone",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("phone"),
                children: row.getValue("phone")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1016,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "email",
        header: "Email",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("email"),
                children: row.getValue("email")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1025,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "participantOrganization",
        header: "Participant Org",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("participantOrganization"),
                children: row.getValue("participantOrganization")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1034,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "jobTitle",
        header: "Participant Job Title",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("jobTitle"),
                children: row.getValue("jobTitle")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1046,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const psychoeducationTableListColumn = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1060,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1070,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "program",
        header: "Program",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("program"),
                children: row.getValue("program")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1084,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "indicator",
        header: "Indicator",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("indicator"),
                children: row.getValue("indicator")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1093,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "awarenessTopic",
        header: "Awareness Topic",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("awarenessTopic"),
                children: row.getValue("awarenessTopic")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1102,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "awarenessDate",
        header: "Awareness Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("awarenessDate"),
                children: row.getValue("awarenessDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1114,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const beneficiarySessionsTableColumn = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1128,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1138,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "type",
        header: "Type",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("type"),
                children: row.getValue("type")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1152,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "topic",
        header: "Topic",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("topic"),
                children: row.getValue("topic")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1161,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "date",
        header: "Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("date"),
                children: row.getValue("date")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1170,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "isPresent",
        header: "Is Present",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: row.getValue("isPresent") ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "rounded border bg-green-500",
                    children: "Yes"
                }, void 0, false, {
                    fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                    lineNumber: 1181,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "rounded border bg-red-500",
                    children: "No"
                }, void 0, false, {
                    fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                    lineNumber: 1183,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1179,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const enactTableColumn = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1194,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1204,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "projectCode",
        header: "Project",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1217,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "province",
        header: "Province",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("province"),
                children: row.getValue("province")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1229,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "indicatorRef",
        header: "Indicator",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("indicatorRef"),
                children: row.getValue("indicatorRef")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1238,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "councilorName",
        header: "Councilor",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("councilorName"),
                children: row.getValue("councilorName")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1250,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "raterName",
        header: "Rater",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("raterName"),
                children: row.getValue("raterName")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1262,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "type",
        header: "Type",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("type"),
                children: row.getValue("type")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1271,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "date",
        header: "Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("date"),
                children: row.getValue("date")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1280,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "aprIncluded",
        header: "APR Included",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                children: row.getValue("aprIncluded") ? "Yes" : "No"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1289,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const submittedAndFirstApprovedDatabasesTableColumn = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1300,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1310,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "projectCode",
        header: "Project Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1323,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "database",
        header: "Database",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("database"),
                children: row.getValue("database")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1335,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "province",
        header: "Province",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("province"),
                children: row.getValue("province")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1344,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("status"),
                children: row.getValue("status")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1353,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "fromDate",
        header: "From Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("fromDate"),
                children: row.getValue("fromDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1362,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "toDate",
        header: "To Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("toDate"),
                children: row.getValue("toDate")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1371,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const communityDialoguesSessionTableColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1382,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1392,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "type",
        header: "Type",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("type"),
                children: row.getValue("type")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1405,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "topic",
        header: "Topic",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("topic"),
                children: row.getValue("topic")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1414,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "date",
        header: "Date",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("date"),
                children: row.getValue("date")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1423,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
const communityDialoguesTableColumns = [
    {
        id: "select",
        header: (param)=>{
            let { table } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: table.getIsAllPageRowsSelected() || table.getIsSomePageRowsSelected() && "indeterminate",
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1434,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1444,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        },
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "projectCode",
        header: "Project Code",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("projectCode"),
                children: row.getValue("projectCode")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1457,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "focalPoint",
        header: "Focal Point",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("focalPoint"),
                children: row.getValue("focalPoint")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1469,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "province",
        header: "Province",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("province"),
                children: row.getValue("province")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1481,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "district",
        header: "District",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("district"),
                children: row.getValue("district")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1490,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "village",
        header: "Village",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("village"),
                children: row.getValue("village")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1499,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "numOfSessions",
        header: "Number Of Sessions",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("numOfSessions"),
                children: row.getValue("numOfSessions")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1508,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "numOfGroups",
        header: "Number Of Groups",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("numOfGroups"),
                children: row.getValue("numOfGroups")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1520,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    },
    {
        accessorKey: "indicator",
        header: "Indicator",
        cell: (param)=>{
            let { row } = param;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[100px] truncate",
                title: row.getValue("indicator"),
                children: row.getValue("indicator")
            }, void 0, false, {
                fileName: "[project]/definitions/DataTableColumnsDefinitions.tsx",
                lineNumber: 1532,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/withPermission.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "withPermission",
    ()=>withPermission
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/PermissionContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
function withPermission(WrappedComponent, requiredPermission) {
    var _s = __turbopack_context__.k.signature();
    const ComponentWithPermission = (props)=>{
        _s();
        const { permissions, loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePermissions"])();
        const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
            "withPermission.ComponentWithPermission.useEffect": ()=>{
                if (!loading && permissions && !permissions.includes(requiredPermission)) {
                    router.replace("/403");
                }
            }
        }["withPermission.ComponentWithPermission.useEffect"], [
            permissions,
            loading,
            router
        ]);
        if (loading) return null;
        if (!permissions.includes(requiredPermission)) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WrappedComponent, {
            ...props
        }, void 0, false, {
            fileName: "[project]/lib/withPermission.tsx",
            lineNumber: 24,
            columnNumber: 12
        }, this);
    };
    _s(ComponentWithPermission, "i8FvwgzeMJPSNA+Hj5CCs+ZxZ3U=", false, function() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$PermissionContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePermissions"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
        ];
    });
    return ComponentWithPermission;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/FormsDefaultValues.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AssessmentDefault",
    ()=>AssessmentDefault,
    "BeneficiaryEvaluationDefault",
    ()=>BeneficiaryEvaluationDefault,
    "ChapterDefault",
    ()=>ChapterDefault,
    "CommunityDialogueBeneficiaryDefault",
    ()=>CommunityDialogueBeneficiaryDefault,
    "CommunityDialogueFormDefault",
    ()=>CommunityDialogueFormDefault,
    "CommunityDialogueSessionDefault",
    ()=>CommunityDialogueSessionDefault,
    "IndicatorDefault",
    ()=>IndicatorDefault,
    "Isp3Default",
    ()=>Isp3Default,
    "KitDatabaseBeneficiaryDefault",
    ()=>KitDatabaseBeneficiaryDefault,
    "KitDatabaseBeneficiaryUpdateDefault",
    ()=>KitDatabaseBeneficiaryUpdateDefault,
    "KitDatabaseProgramDefault",
    ()=>KitDatabaseProgramDefault,
    "KitDefault",
    ()=>KitDefault,
    "MainDatabaseBeneficiaryUpdateDefault",
    ()=>MainDatabaseBeneficiaryUpdateDefault,
    "MainDatabaseProgramDefault",
    ()=>MainDatabaseProgramDefault,
    "MainDbBeneficiaryDefault",
    ()=>MainDbBeneficiaryDefault,
    "MealToolDefault",
    ()=>MealToolDefault,
    "OutcomeDefault",
    ()=>OutcomeDefault,
    "OutputDefault",
    ()=>OutputDefault,
    "PreAndPostTestsDefault",
    ()=>PreAndPostTestsDefault,
    "ProjectDefault",
    ()=>ProjectDefault,
    "PsychoeducationDefault",
    ()=>PsychoeducationDefault,
    "ReasoneOfReferralDefault",
    ()=>ReasoneOfReferralDefault,
    "ReferralFormPersonalInfoDefault",
    ()=>ReferralFormPersonalInfoDefault,
    "ReferredByAndReferredToDefault",
    ()=>ReferredByAndReferredToDefault,
    "TrainingBeneficiaryDefault",
    ()=>TrainingBeneficiaryDefault,
    "TrainingDefault",
    ()=>TrainingDefault,
    "UserDefault",
    ()=>UserDefault
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/utils/OptionLists.tsx [app-client] (ecmascript)");
;
const ProjectDefault = ()=>({
        id: null,
        projectCode: "",
        projectTitle: "",
        projectGoal: "",
        projectDonor: "",
        startDate: "",
        endDate: "",
        status: "planed",
        projectManager: "",
        provinces: [
            "kabul"
        ],
        thematicSector: [
            "mhpss"
        ],
        reportingPeriod: "",
        reportingDate: "",
        aprStatus: "NotCreatedYet",
        description: ""
    });
_c = ProjectDefault;
const OutcomeDefault = ()=>({
        id: null,
        outcome: "",
        outcomeRef: ""
    });
_c1 = OutcomeDefault;
const OutputDefault = ()=>({
        id: null,
        outcomeId: "",
        output: "",
        outputRef: ""
    });
_c2 = OutputDefault;
const IndicatorDefault = ()=>({
        id: null,
        outputId: null,
        outputRef: "",
        indicator: "",
        indicatorRef: "",
        target: 0,
        status: "notStarted",
        provinces: [],
        dessaggregationType: "indevidual",
        description: "",
        database: "",
        type: null,
        subIndicator: null
    });
_c3 = IndicatorDefault;
const Isp3Default = ()=>[
        ...__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isp3s"].map((i)=>({
                name: i,
                indicators: []
            }))
    ];
_c4 = Isp3Default;
const MainDbBeneficiaryDefault = ()=>({
        id: null,
        program: "",
        beneficiaryCode: "",
        name: "",
        fatherHusbandName: "",
        gender: "male",
        age: 0,
        code: "",
        childCode: "",
        childAge: 0,
        phone: "",
        householdStatus: "idp_drought",
        literacyLevel: "",
        maritalStatus: "single",
        disabilityType: "person_without_disability",
        referredForProtection: false,
        dateOfRegistration: ""
    });
_c5 = MainDbBeneficiaryDefault;
const MainDatabaseProgramDefault = ()=>({
        projectCode: "",
        focalPoint: "",
        province: "kabul",
        district: "District 1",
        village: "",
        siteCode: "",
        healthFacilityName: "",
        interventionModality: ""
    });
_c6 = MainDatabaseProgramDefault;
const KitDatabaseProgramDefault = ()=>({
        project_id: "",
        focalPoint: "",
        province_id: "1",
        district_id: "1",
        village: "",
        siteCode: "",
        healthFacilityName: "",
        interventionModality: ""
    });
_c7 = KitDatabaseProgramDefault;
const PreAndPostTestsDefault = ()=>({
        preTestScore: 0,
        postTestScore: 0,
        remark: ""
    });
_c8 = PreAndPostTestsDefault;
const CommunityDialogueBeneficiaryDefault = ()=>({
        name: "",
        fatherHusbandName: "",
        age: 0,
        maritalStatus: "",
        gender: "",
        phone: "",
        nationalId: "",
        jobTitle: "",
        incentiveReceived: false,
        incentiveAmount: "",
        dateOfRegistration: ""
    });
_c9 = CommunityDialogueBeneficiaryDefault;
const CommunityDialogueSessionDefault = (id)=>({
        community_dialogue_id: id,
        topic: "",
        date: ""
    });
_c10 = CommunityDialogueSessionDefault;
const AssessmentDefault = ()=>({
        project_id: "",
        indicator_id: "",
        province_id: "",
        councilorName: "",
        raterName: "",
        type: "",
        date: "",
        aprIncluded: true
    });
_c11 = AssessmentDefault;
const TrainingBeneficiaryDefault = ()=>({
        name: "",
        fatherHusbandName: "",
        gender: "male",
        age: 0,
        phone: "",
        email: "",
        participantOrganization: "",
        jobTitle: "",
        dateOfRegistration: ""
    });
_c12 = TrainingBeneficiaryDefault;
const ChapterDefault = ()=>({
        topic: "",
        facilitatorName: "",
        facilitatorJobTitle: "",
        startDate: "",
        endDate: ""
    });
_c13 = ChapterDefault;
const TrainingDefault = ()=>({
        project_id: "",
        province_id: "",
        district_id: "",
        trainingLocation: "",
        name: "",
        participantCatagory: "",
        aprIncluded: true,
        trainingModality: "",
        startDate: "",
        endDate: "",
        indicator_id: ""
    });
_c14 = TrainingDefault;
const PsychoeducationDefault = ()=>({
        programInformation: {
            indicator_id: "",
            project_id: "",
            focalPoint: "",
            province_id: "",
            district_id: "",
            village: "",
            siteCode: "",
            healthFacilityName: "",
            interventionModality: ""
        },
        psychoeducationInformation: {
            awarenessTopic: "",
            awarenessDate: "",
            // men
            ofMenHostCommunity: "",
            ofMenIdp: "",
            ofMenRefugee: "",
            ofMenReturnee: "",
            ofMenDisabilityType: "",
            // women
            ofWomenHostCommunity: "",
            ofWomenIdp: "",
            ofWomenRefugee: "",
            ofWomenReturnee: "",
            ofWomenDisabilityType: "",
            // boy
            ofBoyHostCommunity: "",
            ofBoyIdp: "",
            ofBoyRefugee: "",
            ofBoyReturnee: "",
            ofBoyDisabilityType: "",
            // girl
            ofGirlHostCommunity: "",
            ofGirlIdp: "",
            ofGirlRefugee: "",
            ofGirlReturnee: "",
            ofGirlDisabilityType: "",
            remark: ""
        }
    });
_c15 = PsychoeducationDefault;
const KitDatabaseBeneficiaryDefault = ()=>({
        program: "",
        indicators: [],
        dateOfRegistration: "",
        code: "",
        name: "",
        fatherHusbandName: "",
        gender: "",
        age: 0,
        maritalStatus: "",
        childCode: "",
        childAge: 0,
        phone: "",
        householdStatus: "",
        literacyLevel: "",
        disabilityType: "",
        referredForProtection: false
    });
_c16 = KitDatabaseBeneficiaryDefault;
const KitDatabaseBeneficiaryUpdateDefault = ()=>({
        id: "",
        program: "",
        indicators: [],
        dateOfRegistration: "",
        code: "",
        name: "",
        fatherHusbandName: "",
        gender: "",
        age: 0,
        maritalStatus: "",
        childCode: "",
        childAge: 0,
        phone: "",
        householdStatus: "",
        literacyLevel: "",
        disabilityType: "",
        referredForProtection: false
    });
_c17 = KitDatabaseBeneficiaryUpdateDefault;
const KitDefault = ()=>({
        kits: [],
        distributionDate: "",
        remark: "",
        isReceived: false
    });
_c18 = KitDefault;
const MainDatabaseBeneficiaryUpdateDefault = ()=>({
        id: "",
        program: "",
        dateOfRegistration: "",
        code: "",
        name: "",
        fatherHusbandName: "",
        gender: "",
        age: 0,
        maritalStatus: "",
        childCode: "",
        ageOfChild: 0,
        phone: "",
        householdStatus: "",
        literacyLevel: "",
        disabilityType: "",
        referredForProtection: false
    });
_c19 = MainDatabaseBeneficiaryUpdateDefault;
const MealToolDefault = (id)=>({
        beneficiary_id: id,
        type: "",
        baselineDate: "",
        endlineDate: "",
        baselineTotalScore: "",
        endlineTotalScore: "",
        improvementPercentage: "",
        isBaselineActive: false,
        isEndlineActive: false,
        evaluation: ""
    });
_c20 = MealToolDefault;
const ReferredByAndReferredToDefault = ()=>({
        name: "",
        agency: "",
        phone: "",
        email: "",
        address: ""
    });
_c21 = ReferredByAndReferredToDefault;
const ReasoneOfReferralDefault = ()=>({
        mentalHealthAlert: "",
        selfHarm: "",
        suicideIdeation: "",
        undiagnosedPsychosis: ""
    });
_c22 = ReasoneOfReferralDefault;
const ReferralFormPersonalInfoDefault = ()=>({
        nationalId: "",
        currentAddress: "",
        spokenLanguage: []
    });
_c23 = ReferralFormPersonalInfoDefault;
const UserDefault = ()=>({
        name: "",
        title: "",
        email: "",
        password: "",
        email_verified_at: "",
        photo_path: "",
        department: "",
        status: "active",
        role: ""
    });
_c24 = UserDefault;
const BeneficiaryEvaluationDefault = ()=>({
        date: "",
        clientSessionEvaluation: [],
        otherClientSessionEvaluation: "",
        clientSatisfaction: "neutral",
        satisfactionDate: "",
        dischargeReason: [],
        otherDischargeReasone: "",
        dischargeReasonDate: ""
    });
_c25 = BeneficiaryEvaluationDefault;
const CommunityDialogueFormDefault = ()=>({
        project_id: "",
        focalPoint: "",
        province_id: "",
        district_id: "",
        village: "",
        indicator_id: ""
    });
_c26 = CommunityDialogueFormDefault;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26;
__turbopack_context__.k.register(_c, "ProjectDefault");
__turbopack_context__.k.register(_c1, "OutcomeDefault");
__turbopack_context__.k.register(_c2, "OutputDefault");
__turbopack_context__.k.register(_c3, "IndicatorDefault");
__turbopack_context__.k.register(_c4, "Isp3Default");
__turbopack_context__.k.register(_c5, "MainDbBeneficiaryDefault");
__turbopack_context__.k.register(_c6, "MainDatabaseProgramDefault");
__turbopack_context__.k.register(_c7, "KitDatabaseProgramDefault");
__turbopack_context__.k.register(_c8, "PreAndPostTestsDefault");
__turbopack_context__.k.register(_c9, "CommunityDialogueBeneficiaryDefault");
__turbopack_context__.k.register(_c10, "CommunityDialogueSessionDefault");
__turbopack_context__.k.register(_c11, "AssessmentDefault");
__turbopack_context__.k.register(_c12, "TrainingBeneficiaryDefault");
__turbopack_context__.k.register(_c13, "ChapterDefault");
__turbopack_context__.k.register(_c14, "TrainingDefault");
__turbopack_context__.k.register(_c15, "PsychoeducationDefault");
__turbopack_context__.k.register(_c16, "KitDatabaseBeneficiaryDefault");
__turbopack_context__.k.register(_c17, "KitDatabaseBeneficiaryUpdateDefault");
__turbopack_context__.k.register(_c18, "KitDefault");
__turbopack_context__.k.register(_c19, "MainDatabaseBeneficiaryUpdateDefault");
__turbopack_context__.k.register(_c20, "MealToolDefault");
__turbopack_context__.k.register(_c21, "ReferredByAndReferredToDefault");
__turbopack_context__.k.register(_c22, "ReasoneOfReferralDefault");
__turbopack_context__.k.register(_c23, "ReferralFormPersonalInfoDefault");
__turbopack_context__.k.register(_c24, "UserDefault");
__turbopack_context__.k.register(_c25, "BeneficiaryEvaluationDefault");
__turbopack_context__.k.register(_c26, "CommunityDialogueFormDefault");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/IndicatorProvincesTargetCalculator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateEachSubIndicatorProvinceTargetAccordingTONumberOFCouncilorCount",
    ()=>calculateEachSubIndicatorProvinceTargetAccordingTONumberOFCouncilorCount,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
;
const calculateEachIndicatorProvinceTargetAccordingTONumberOFCouncilorCount = (indicator, indicatorStataSetter)=>{
    if (indicator == null || indicator.provinces.length == 0) return;
    const totalIndicatorTarget = indicator.target;
    const totalNumberOfIndicatorCouncilorCount = indicator.provinces.reduce((acc, current)=>acc + Number(current.councilorCount || 0), 0);
    const provinceWithMostNumberOfCouncilorCount = indicator.provinces.reduce((maxObj, item)=>item.councilorCount > maxObj.councilorCount ? item : maxObj).province;
    const baseTargetForEachCouncilor = totalIndicatorTarget / totalNumberOfIndicatorCouncilorCount;
    const needForSomeManipulation = totalIndicatorTarget % totalNumberOfIndicatorCouncilorCount == 0 ? false : true;
    if (needForSomeManipulation) {
        const manipulatedBaseTargetForEachCouncilor = Math.floor(baseTargetForEachCouncilor);
        const eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount = manipulatedBaseTargetForEachCouncilor;
        const councilorTargetOfProvinceWithMostNumberOfCouncilorCount = totalIndicatorTarget - (totalNumberOfIndicatorCouncilorCount - 1) * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount;
        indicatorStataSetter((prev)=>({
                ...prev,
                provinces: prev.provinces.map((province)=>({
                        ...province,
                        target: province.province == provinceWithMostNumberOfCouncilorCount ? (province.councilorCount - 1) * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount + councilorTargetOfProvinceWithMostNumberOfCouncilorCount : province.councilorCount * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount
                    }))
            }));
    } else {
        indicatorStataSetter((prev)=>({
                ...prev,
                provinces: prev.provinces.map((province)=>({
                        ...province,
                        target: province.councilorCount * baseTargetForEachCouncilor
                    }))
            }));
    }
};
const calculateEachSubIndicatorProvinceTargetAccordingTONumberOFCouncilorCount = (indicator, indicatorStataSetter)=>{
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotASubIndicator"])(indicator.subIndicator) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NoProvinceSelectedForSubIndicator"])(indicator.subIndicator)) return;
    const totalIndicatorTarget = indicator.subIndicator.target;
    const totalNumberOfIndicatorCouncilorCount = indicator.subIndicator.provinces.reduce((acc, current)=>acc + Number(current.councilorCount || 0), 0);
    const provinceWithMostNumberOfCouncilorCount = indicator.subIndicator.provinces.reduce((maxObj, item)=>item.councilorCount > maxObj.councilorCount ? item : maxObj).province;
    const baseTargetForEachCouncilor = totalIndicatorTarget / totalNumberOfIndicatorCouncilorCount;
    const needForSomeManipulation = totalIndicatorTarget % totalNumberOfIndicatorCouncilorCount == 0 ? false : true;
    if (needForSomeManipulation) {
        const manipulatedBaseTargetForEachCouncilor = Math.floor(baseTargetForEachCouncilor);
        const eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount = manipulatedBaseTargetForEachCouncilor;
        const councilorTargetOfProvinceWithMostNumberOfCouncilorCount = totalIndicatorTarget - (totalNumberOfIndicatorCouncilorCount - 1) * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount;
        indicatorStataSetter((prev)=>({
                ...prev,
                subIndicator: {
                    ...prev.subIndicator,
                    provinces: prev.subIndicator.provinces.map((province)=>({
                            ...province,
                            target: province.province == provinceWithMostNumberOfCouncilorCount ? (province.councilorCount - 1) * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount + councilorTargetOfProvinceWithMostNumberOfCouncilorCount : province.councilorCount * eachCouncilorTargetExceptTheProvinceWhichHasTheMostCouncilorCount
                        }))
                }
            }));
    } else {
        indicatorStataSetter((prev)=>({
                ...prev,
                subIndicator: {
                    ...prev.subIndicator,
                    provinces: prev.subIndicator.provinces.map((province)=>({
                            ...province,
                            target: province.councilorCount * baseTargetForEachCouncilor
                        }))
                }
            }));
    }
};
;
const __TURBOPACK__default__export__ = calculateEachIndicatorProvinceTargetAccordingTONumberOFCouncilorCount;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/helpers/StringToCapital.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringToCapital",
    ()=>stringToCapital
]);
const stringToCapital = (str)=>{
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/helpers/DessaggregationFormHelpers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getReliableDessaggregationOptionsAccordingToDessagregationType",
    ()=>getReliableDessaggregationOptionsAccordingToDessagregationType,
    "getReliableDessaggregationOptionsForSubIndicatorAccordingToDessagregationType",
    ()=>getReliableDessaggregationOptionsForSubIndicatorAccordingToDessagregationType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(main)/projects/utils/OptionLists.tsx [app-client] (ecmascript)");
;
const getReliableDessaggregationOptionsAccordingToDessagregationType = (dessaggregationType)=>{
    if (dessaggregationType == "session") return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sessionDessaggregationOptions"];
    else if (dessaggregationType == "indevidual") return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indevidualDessaggregationOptions"];
    else return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enactDessaggregationOptions"];
};
const getReliableDessaggregationOptionsForSubIndicatorAccordingToDessagregationType = (dessaggregationType)=>{
    if (dessaggregationType == "session") return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sessionDessaggregationOptions"];
    else return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$main$292f$projects$2f$utils$2f$OptionLists$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indevidualDessaggregationOptions"];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/helpers/IndicatorFormHelpers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStructuredProvinces",
    ()=>getStructuredProvinces
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/StringToCapital.tsx [app-client] (ecmascript)");
;
const getStructuredProvinces = (provinces)=>{
    return provinces.map((province)=>({
            label: (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$StringToCapital$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringToCapital"])(province),
            value: province
        }));
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/helpers/GlobalHelpers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemoveIdFielsFromObj",
    ()=>RemoveIdFielsFromObj
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/Constants.tsx [app-client] (ecmascript)");
;
const RemoveIdFielsFromObj = (obj)=>{
    const objCopy = {
        ...obj
    };
    const objKeys = Object.keys(objCopy);
    for (const key of objKeys){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsNonePrimitiveTypeAndNotNullOrUndefined"])(objCopy[key])) RemoveIdFielsFromObj(objCopy[key]);
        else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$Constants$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsIdFeild"])(key)) {
            console.log(...oo_oo("1014606590_11_30_11_46_4", key));
            delete objCopy[key];
        }
        ;
    }
    return objCopy;
};
_c = RemoveIdFielsFromObj;
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';function _0x5a41(_0xa94ba2,_0x20bcf7){var _0x46c9d4=_0x46c9();return _0x5a41=function(_0x5a41b7,_0x432119){_0x5a41b7=_0x5a41b7-0xc2;var _0x4ff83e=_0x46c9d4[_0x5a41b7];return _0x4ff83e;},_0x5a41(_0xa94ba2,_0x20bcf7);}var _0x1fc135=_0x5a41;(function(_0x12841d,_0x45ce02){var _0x463f09=_0x5a41,_0x3aed6f=_0x12841d();while(!![]){try{var _0xfbec5f=parseInt(_0x463f09(0x164))/0x1+-parseInt(_0x463f09(0x1c3))/0x2*(parseInt(_0x463f09(0x1ae))/0x3)+parseInt(_0x463f09(0xed))/0x4+-parseInt(_0x463f09(0x10e))/0x5+-parseInt(_0x463f09(0x132))/0x6*(-parseInt(_0x463f09(0xf4))/0x7)+-parseInt(_0x463f09(0x1bf))/0x8*(parseInt(_0x463f09(0x149))/0x9)+-parseInt(_0x463f09(0x158))/0xa*(-parseInt(_0x463f09(0x181))/0xb);if(_0xfbec5f===_0x45ce02)break;else _0x3aed6f['push'](_0x3aed6f['shift']());}catch(_0x1ddfc0){_0x3aed6f['push'](_0x3aed6f['shift']());}}}(_0x46c9,0xc9a1b));function z(_0x76ea34,_0x41accc,_0x305778,_0x1e8a8e,_0x35d5ea,_0x22fb9e){var _0x203dfc=_0x5a41,_0x53bb71,_0x56de44,_0x41daae,_0x4e3bb8;this[_0x203dfc(0x17b)]=_0x76ea34,this[_0x203dfc(0x133)]=_0x41accc,this[_0x203dfc(0xf0)]=_0x305778,this['nodeModules']=_0x1e8a8e,this[_0x203dfc(0x19d)]=_0x35d5ea,this[_0x203dfc(0x1a9)]=_0x22fb9e,this[_0x203dfc(0xdc)]=!0x0,this['_allowedToConnectOnSend']=!0x0,this[_0x203dfc(0xe9)]=!0x1,this['_connecting']=!0x1,this[_0x203dfc(0x19e)]=((_0x56de44=(_0x53bb71=_0x76ea34[_0x203dfc(0x139)])==null?void 0x0:_0x53bb71[_0x203dfc(0x11f)])==null?void 0x0:_0x56de44[_0x203dfc(0x1b3)])==='edge',this[_0x203dfc(0xcd)]=!((_0x4e3bb8=(_0x41daae=this[_0x203dfc(0x17b)]['process'])==null?void 0x0:_0x41daae[_0x203dfc(0xe2)])!=null&&_0x4e3bb8[_0x203dfc(0x145)])&&!this[_0x203dfc(0x19e)],this[_0x203dfc(0x129)]=null,this['_connectAttemptCount']=0x0,this[_0x203dfc(0x1bd)]=0x14,this[_0x203dfc(0x156)]=_0x203dfc(0xca),this[_0x203dfc(0x165)]=(this[_0x203dfc(0xcd)]?_0x203dfc(0x1b1):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this[_0x203dfc(0x156)];}function _0x46c9(){var _0x4ae90f=['autoExpandPreviousObjects','bind','resetOnProcessingTimeAverageMs','function','Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','autoExpandMaxDepth','defaultLimits','some','[object\\x20Array]','_cleanNode','_getOwnPropertyDescriptor',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'8096830gPNSKo','length','_isSet','log','reducePolicy','forEach','rootExpression','perf_hooks','isExpressionToEvaluate','resolveGetters','_ws','push','nan','_setNodeExpressionPath','readyState','_hasMapOnItsPath','','env','hrtime','resetWhenQuietMs','toString','_setNodeId',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','pop','strLength','positiveInfinity','modules','_WebSocketClass','_type','capped','127.0.0.1','object','call','POSITIVE_INFINITY','next.js','coverage','102LwRJSG','host','index','_setNodeQueryPath','HTMLAllCollection','_addLoadNode','_attemptToReconnectShortly','process','type','logger\\x20websocket\\x20error','_reconnectTimeout','getOwnPropertyNames','String','_console_ninja','gateway.docker.internal','3810','_treeNodePropertiesAfterFullValue','parse','1','node','value','_isMap','reduceOnCount','315SmJdle','close','timeStamp','time','_Symbol','_hasSymbolPropertyOnItsPath','angular','perLogpoint','default','endsWith','\\x20server','bigint','startsWith','_webSocketErrorDocsLink','_setNodeExpandableState','2976160OPTOtp','nodeModules','onopen','reduceLimits','serialize','_addProperty','concat','_getOwnPropertyNames','[object\\x20Set]','stringify','ExpoDevice','elapsed','261278GYbHMc','_sendErrorMessage','_additionalMetadata','expressionsToEvaluate','message','toLowerCase','getWebSocketClass','_setNodePermissions','WebSocket','getOwnPropertySymbols','_extendedWarning','_blacklistedProperty','warn','autoExpandPropertyCount','null','string','_addFunctionsNode','ws://','Buffer','hasOwnProperty','prototype','edge','_isArray','global','catch','slice','_undefined','then','array','66JgkQaA','includes','remix','url','disabledTrace','_allowedToConnectOnSend','_treeNodePropertiesBeforeFullValue','reload','NEGATIVE_INFINITY','stackTraceLimit','_regExpToString','...','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','reducedLimits','resolve','\\x20browser','_hasSetOnItsPath','charAt','substr','1763893057747','_socket','onmessage','_property','[object\\x20Map]','isArray','_isPrimitiveWrapperType','_getOwnPropertySymbols','dockerizedApp','_inNextEdge','noFunctions','error','iterator','onclose','_processTreeNodeResult',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"sediqj42\"],'constructor','_isUndefined','elements','expId','eventReceivedCallback','import(\\x27path\\x27)','_numberRegExp','_dateToString','next.js','149349QSQLvQ','level','data','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','hostname','NEXT_RUNTIME','Map','_console_ninja_session','android','args','props','count','match','_isNegativeZero','root_exp_id','_maxConnectAttemptCount','name','196280wOXbpo','trace','Set','symbol','46iTUtwv','_keyStrRegExp','funcName','react-native','send','setter','autoExpandLimit','stack','valueOf','sortProps','_capIfString','date','set','unknown','_connectAttemptCount','_setNodeLabel','parent','https://tinyurl.com/37x8b79t','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','console','_inBrowser','number','current','depth','_objectToString','map','Promise','1.0.0','_propertyName','boolean','','_consoleNinjaAllowedToStart','_connecting','_WebSocket','path','_allowedToSend','_addObjectProperty','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','_sortProps','toUpperCase','unref','versions','ninjaSuppressConsole','hits','getOwnPropertyDescriptor','cappedElements','Number','undefined','_connected','now','getter','[object\\x20Date]','4532040FLHqEh','onerror','_ninjaIgnoreNextError','port','_disposeWebsocket','totalStrLength','location','522529oHclbe','test','replace','reduceOnAccumulatedProcessingTimeMs','fromCharCode','_p_name','allStrLength','expo','method','_HTMLAllCollection','autoExpand','bound\\x20Promise','performance','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());'];_0x46c9=function(){return _0x4ae90f;};return _0x46c9();}z[_0x1fc135(0x178)][_0x1fc135(0x16a)]=async function(){var _0x4ae121=_0x1fc135,_0x18a19c,_0x241a90;if(this['_WebSocketClass'])return this[_0x4ae121(0x129)];let _0x45de09;if(this[_0x4ae121(0xcd)]||this['_inNextEdge'])_0x45de09=this[_0x4ae121(0x17b)][_0x4ae121(0x16c)];else{if((_0x18a19c=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])!=null&&_0x18a19c[_0x4ae121(0xda)])_0x45de09=(_0x241a90=this[_0x4ae121(0x17b)][_0x4ae121(0x139)])==null?void 0x0:_0x241a90[_0x4ae121(0xda)];else try{_0x45de09=(await new Function(_0x4ae121(0xdb),_0x4ae121(0x184),_0x4ae121(0x159),_0x4ae121(0x101))(await(0x0,eval)(_0x4ae121(0x1aa)),await(0x0,eval)('import(\\x27url\\x27)'),this['nodeModules']))[_0x4ae121(0x151)];}catch{try{_0x45de09=require(require(_0x4ae121(0xdb))['join'](this[_0x4ae121(0x159)],'ws'));}catch{throw new Error(_0x4ae121(0x18d));}}}return this['_WebSocketClass']=_0x45de09,_0x45de09;},z['prototype']['_connectToHostNow']=function(){var _0x3e8739=_0x1fc135;this[_0x3e8739(0xd9)]||this[_0x3e8739(0xe9)]||this[_0x3e8739(0xc7)]>=this['_maxConnectAttemptCount']||(this['_allowedToConnectOnSend']=!0x1,this[_0x3e8739(0xd9)]=!0x0,this[_0x3e8739(0xc7)]++,this[_0x3e8739(0x118)]=new Promise((_0x3fa28f,_0x5e9cd5)=>{var _0x21d44e=_0x3e8739;this[_0x21d44e(0x16a)]()[_0x21d44e(0x17f)](_0x3e4660=>{var _0x4002c9=_0x21d44e;let _0x265cb8=new _0x3e4660(_0x4002c9(0x175)+(!this[_0x4002c9(0xcd)]&&this[_0x4002c9(0x19d)]?_0x4002c9(0x140):this[_0x4002c9(0x133)])+':'+this[_0x4002c9(0xf0)]);_0x265cb8[_0x4002c9(0xee)]=()=>{var _0x30e6ef=_0x4002c9;this['_allowedToSend']=!0x1,this['_disposeWebsocket'](_0x265cb8),this[_0x30e6ef(0x138)](),_0x5e9cd5(new Error(_0x30e6ef(0x13b)));},_0x265cb8[_0x4002c9(0x15a)]=()=>{var _0x453b8c=_0x4002c9;this[_0x453b8c(0xcd)]||_0x265cb8[_0x453b8c(0x196)]&&_0x265cb8[_0x453b8c(0x196)][_0x453b8c(0xe1)]&&_0x265cb8['_socket'][_0x453b8c(0xe1)](),_0x3fa28f(_0x265cb8);},_0x265cb8[_0x4002c9(0x1a2)]=()=>{var _0x140e5d=_0x4002c9;this[_0x140e5d(0x186)]=!0x0,this['_disposeWebsocket'](_0x265cb8),this['_attemptToReconnectShortly']();},_0x265cb8[_0x4002c9(0x197)]=_0x45b578=>{var _0x561e4f=_0x4002c9;try{if(!(_0x45b578!=null&&_0x45b578[_0x561e4f(0x1b0)])||!this['eventReceivedCallback'])return;let _0x5c0f52=JSON[_0x561e4f(0x143)](_0x45b578[_0x561e4f(0x1b0)]);this[_0x561e4f(0x1a9)](_0x5c0f52[_0x561e4f(0xfc)],_0x5c0f52[_0x561e4f(0x1b7)],this[_0x561e4f(0x17b)],this[_0x561e4f(0xcd)]);}catch{}};})[_0x21d44e(0x17f)](_0x3522f8=>(this[_0x21d44e(0xe9)]=!0x0,this[_0x21d44e(0xd9)]=!0x1,this[_0x21d44e(0x186)]=!0x1,this[_0x21d44e(0xdc)]=!0x0,this[_0x21d44e(0xc7)]=0x0,_0x3522f8))['catch'](_0x5498dc=>(this[_0x21d44e(0xe9)]=!0x1,this[_0x21d44e(0xd9)]=!0x1,console[_0x21d44e(0x170)](_0x21d44e(0x18e)+this[_0x21d44e(0x156)]),_0x5e9cd5(new Error(_0x21d44e(0xde)+(_0x5498dc&&_0x5498dc['message'])))));}));},z[_0x1fc135(0x178)][_0x1fc135(0xf1)]=function(_0x39064e){var _0x62e767=_0x1fc135;this[_0x62e767(0xe9)]=!0x1,this[_0x62e767(0xd9)]=!0x1;try{_0x39064e[_0x62e767(0x1a2)]=null,_0x39064e['onerror']=null,_0x39064e[_0x62e767(0x15a)]=null;}catch{}try{_0x39064e[_0x62e767(0x11c)]<0x2&&_0x39064e[_0x62e767(0x14a)]();}catch{}},z[_0x1fc135(0x178)][_0x1fc135(0x138)]=function(){var _0x5da3df=_0x1fc135;clearTimeout(this[_0x5da3df(0x13c)]),!(this[_0x5da3df(0xc7)]>=this['_maxConnectAttemptCount'])&&(this['_reconnectTimeout']=setTimeout(()=>{var _0x21baad=_0x5da3df,_0x34fb09;this['_connected']||this[_0x21baad(0xd9)]||(this['_connectToHostNow'](),(_0x34fb09=this[_0x21baad(0x118)])==null||_0x34fb09[_0x21baad(0x17c)](()=>this['_attemptToReconnectShortly']()));},0x1f4),this[_0x5da3df(0x13c)]['unref']&&this['_reconnectTimeout'][_0x5da3df(0xe1)]());},z[_0x1fc135(0x178)][_0x1fc135(0x1c7)]=async function(_0x2aa022){var _0x44ea14=_0x1fc135;try{if(!this['_allowedToSend'])return;this[_0x44ea14(0x186)]&&this['_connectToHostNow'](),(await this['_ws'])['send'](JSON[_0x44ea14(0x161)](_0x2aa022));}catch(_0x516430){this[_0x44ea14(0x16e)]?console['warn'](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430['message'])):(this[_0x44ea14(0x16e)]=!0x0,console[_0x44ea14(0x170)](this[_0x44ea14(0x165)]+':\\x20'+(_0x516430&&_0x516430[_0x44ea14(0x168)]),_0x2aa022)),this[_0x44ea14(0xdc)]=!0x1,this[_0x44ea14(0x138)]();}};function H(_0xbed09e,_0x3de44a,_0x566e47,_0x54b39d,_0x39164d,_0x409fce,_0xbcb120,_0x4ae046=ne){var _0x51bc8b=_0x1fc135;let _0x2f5944=_0x566e47['split'](',')[_0x51bc8b(0xd2)](_0x4d018a=>{var _0x4f1217=_0x51bc8b,_0x3ff168,_0x2d1ad9,_0x57b744,_0xeff5a4,_0x7643dd,_0xd13b57,_0x3dac27;try{if(!_0xbed09e['_console_ninja_session']){let _0x4a47b6=((_0x2d1ad9=(_0x3ff168=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x3ff168[_0x4f1217(0xe2)])==null?void 0x0:_0x2d1ad9[_0x4f1217(0x145)])||((_0xeff5a4=(_0x57b744=_0xbed09e[_0x4f1217(0x139)])==null?void 0x0:_0x57b744[_0x4f1217(0x11f)])==null?void 0x0:_0xeff5a4[_0x4f1217(0x1b3)])===_0x4f1217(0x179);(_0x39164d===_0x4f1217(0x130)||_0x39164d===_0x4f1217(0x183)||_0x39164d==='astro'||_0x39164d===_0x4f1217(0x14f))&&(_0x39164d+=_0x4a47b6?_0x4f1217(0x153):_0x4f1217(0x191));let _0x3e173e='';_0x39164d===_0x4f1217(0x1c6)&&(_0x3e173e=(((_0x3dac27=(_0xd13b57=(_0x7643dd=_0xbed09e['expo'])==null?void 0x0:_0x7643dd[_0x4f1217(0x128)])==null?void 0x0:_0xd13b57[_0x4f1217(0x162)])==null?void 0x0:_0x3dac27['osName'])||'')[_0x4f1217(0x169)](),_0x3e173e&&(_0x39164d+='\\x20'+_0x3e173e,_0x3e173e===_0x4f1217(0x1b6)&&(_0x3de44a='10.0.2.2'))),_0xbed09e['_console_ninja_session']={'id':+new Date(),'tool':_0x39164d},_0xbcb120&&_0x39164d&&!_0x4a47b6&&(_0x3e173e?console[_0x4f1217(0x111)](_0x4f1217(0x106)+_0x3e173e+_0x4f1217(0x124)):console[_0x4f1217(0x111)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0x39164d[_0x4f1217(0x193)](0x0)[_0x4f1217(0xe0)]()+_0x39164d[_0x4f1217(0x194)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'));}let _0x199336=new z(_0xbed09e,_0x3de44a,_0x4d018a,_0x54b39d,_0x409fce,_0x4ae046);return _0x199336[_0x4f1217(0x1c7)][_0x4f1217(0x103)](_0x199336);}catch(_0x33e9da){return console['warn'](_0x4f1217(0xcb),_0x33e9da&&_0x33e9da[_0x4f1217(0x168)]),()=>{};}});return _0x1956ea=>_0x2f5944[_0x51bc8b(0x113)](_0x4e6927=>_0x4e6927(_0x1956ea));}function ne(_0x116e80,_0x40cfba,_0x3b4452,_0x30cd66){var _0x890e43=_0x1fc135;_0x30cd66&&_0x116e80==='reload'&&_0x3b4452[_0x890e43(0xf3)][_0x890e43(0x188)]();}function b(_0x2601c7){var _0x326d90=_0x1fc135,_0x1a4170,_0x23ee95;let _0x531900=function(_0x27480e,_0x188dcd){return _0x188dcd-_0x27480e;},_0x2639ae;if(_0x2601c7[_0x326d90(0x100)])_0x2639ae=function(){var _0x2a5205=_0x326d90;return _0x2601c7['performance'][_0x2a5205(0xea)]();};else{if(_0x2601c7[_0x326d90(0x139)]&&_0x2601c7[_0x326d90(0x139)][_0x326d90(0x120)]&&((_0x23ee95=(_0x1a4170=_0x2601c7['process'])==null?void 0x0:_0x1a4170['env'])==null?void 0x0:_0x23ee95[_0x326d90(0x1b3)])!==_0x326d90(0x179))_0x2639ae=function(){var _0x3a41db=_0x326d90;return _0x2601c7[_0x3a41db(0x139)]['hrtime']();},_0x531900=function(_0x282f28,_0xc6af32){return 0x3e8*(_0xc6af32[0x0]-_0x282f28[0x0])+(_0xc6af32[0x1]-_0x282f28[0x1])/0xf4240;};else try{let {performance:_0x3f1ea6}=require(_0x326d90(0x115));_0x2639ae=function(){var _0x440cae=_0x326d90;return _0x3f1ea6[_0x440cae(0xea)]();};}catch{_0x2639ae=function(){return+new Date();};}}return{'elapsed':_0x531900,'timeStamp':_0x2639ae,'now':()=>Date['now']()};}function X(_0x23d2d9,_0x30bba7,_0x37042b){var _0x5f50f2=_0x1fc135,_0x142aeb,_0x43891d,_0x2c7083,_0x1efb74,_0x3655da,_0x2f04a6,_0x122ade,_0x31dc28,_0x472369;if(_0x23d2d9[_0x5f50f2(0xd8)]!==void 0x0)return _0x23d2d9[_0x5f50f2(0xd8)];let _0x45b226=((_0x43891d=(_0x142aeb=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x142aeb[_0x5f50f2(0xe2)])==null?void 0x0:_0x43891d[_0x5f50f2(0x145)])||((_0x1efb74=(_0x2c7083=_0x23d2d9[_0x5f50f2(0x139)])==null?void 0x0:_0x2c7083[_0x5f50f2(0x11f)])==null?void 0x0:_0x1efb74[_0x5f50f2(0x1b3)])===_0x5f50f2(0x179),_0x36082e=!!(_0x37042b===_0x5f50f2(0x1c6)&&((_0x122ade=(_0x2f04a6=(_0x3655da=_0x23d2d9[_0x5f50f2(0xfb)])==null?void 0x0:_0x3655da[_0x5f50f2(0x128)])==null?void 0x0:_0x2f04a6[_0x5f50f2(0x162)])==null?void 0x0:_0x122ade['osName']));function _0x21c350(_0x2bf556){var _0x2c5e4b=_0x5f50f2;if(_0x2bf556[_0x2c5e4b(0x155)]('/')&&_0x2bf556[_0x2c5e4b(0x152)]('/')){let _0x267dc2=new RegExp(_0x2bf556[_0x2c5e4b(0x17d)](0x1,-0x1));return _0x4e19cc=>_0x267dc2[_0x2c5e4b(0xf5)](_0x4e19cc);}else{if(_0x2bf556[_0x2c5e4b(0x182)]('*')||_0x2bf556[_0x2c5e4b(0x182)]('?')){let _0x234e74=new RegExp('^'+_0x2bf556['replace'](/\\./g,String[_0x2c5e4b(0xf8)](0x5c)+'.')[_0x2c5e4b(0xf6)](/\\*/g,'.*')[_0x2c5e4b(0xf6)](/\\?/g,'.')+String[_0x2c5e4b(0xf8)](0x24));return _0x35cfab=>_0x234e74[_0x2c5e4b(0xf5)](_0x35cfab);}else return _0x16c4db=>_0x16c4db===_0x2bf556;}}let _0x725fc=_0x30bba7[_0x5f50f2(0xd2)](_0x21c350);return _0x23d2d9[_0x5f50f2(0xd8)]=_0x45b226||!_0x30bba7,!_0x23d2d9[_0x5f50f2(0xd8)]&&((_0x31dc28=_0x23d2d9[_0x5f50f2(0xf3)])==null?void 0x0:_0x31dc28['hostname'])&&(_0x23d2d9['_consoleNinjaAllowedToStart']=_0x725fc[_0x5f50f2(0x109)](_0x367574=>_0x367574(_0x23d2d9[_0x5f50f2(0xf3)]['hostname']))),_0x36082e&&!_0x23d2d9['_consoleNinjaAllowedToStart']&&!((_0x472369=_0x23d2d9[_0x5f50f2(0xf3)])!=null&&_0x472369[_0x5f50f2(0x1b2)])&&(_0x23d2d9[_0x5f50f2(0xd8)]=!0x0),_0x23d2d9[_0x5f50f2(0xd8)];}function J(_0x5873aa,_0x5b995d,_0x45642a,_0x5b3c4b,_0xad4d21,_0x413cb2){var _0x2cb272=_0x1fc135;_0x5873aa=_0x5873aa,_0x5b995d=_0x5b995d,_0x45642a=_0x45642a,_0x5b3c4b=_0x5b3c4b,_0xad4d21=_0xad4d21,_0xad4d21=_0xad4d21||{},_0xad4d21[_0x2cb272(0x108)]=_0xad4d21[_0x2cb272(0x108)]||{},_0xad4d21[_0x2cb272(0x18f)]=_0xad4d21[_0x2cb272(0x18f)]||{},_0xad4d21[_0x2cb272(0x112)]=_0xad4d21['reducePolicy']||{},_0xad4d21['reducePolicy'][_0x2cb272(0x150)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)]||{},_0xad4d21['reducePolicy'][_0x2cb272(0x17b)]=_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]||{};let _0x1ec146={'perLogpoint':{'reduceOnCount':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x148)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21['reducePolicy']['perLogpoint'][_0x2cb272(0xf7)]||0x64,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x150)][_0x2cb272(0x121)]||0x1f4,'resetOnProcessingTimeAverageMs':_0xad4d21['reducePolicy'][_0x2cb272(0x150)][_0x2cb272(0x104)]||0x64},'global':{'reduceOnCount':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0x148)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0xad4d21[_0x2cb272(0x112)]['global'][_0x2cb272(0xf7)]||0x12c,'resetWhenQuietMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetWhenQuietMs']||0x32,'resetOnProcessingTimeAverageMs':_0xad4d21[_0x2cb272(0x112)][_0x2cb272(0x17b)]['resetOnProcessingTimeAverageMs']||0x64}},_0x40a3a3=b(_0x5873aa),_0x48338=_0x40a3a3[_0x2cb272(0x163)],_0x21a97a=_0x40a3a3[_0x2cb272(0x14b)];function _0x4de4d2(){var _0x3d3e0d=_0x2cb272;this[_0x3d3e0d(0x1c4)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x3d3e0d(0x1ab)]=/^(0|[1-9][0-9]*)$/,this['_quotedRegExp']=/'([^\\\\']|\\\\')*'/,this[_0x3d3e0d(0x17e)]=_0x5873aa['undefined'],this[_0x3d3e0d(0xfd)]=_0x5873aa['HTMLAllCollection'],this[_0x3d3e0d(0x10c)]=Object[_0x3d3e0d(0xe5)],this[_0x3d3e0d(0x15f)]=Object[_0x3d3e0d(0x13d)],this[_0x3d3e0d(0x14d)]=_0x5873aa['Symbol'],this['_regExpToString']=RegExp[_0x3d3e0d(0x178)][_0x3d3e0d(0x122)],this[_0x3d3e0d(0x1ac)]=Date['prototype'][_0x3d3e0d(0x122)];}_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15c)]=function(_0x27724c,_0xe7c38a,_0x3efad1,_0x4054fc){var _0x23455e=_0x2cb272,_0x47d7be=this,_0x252550=_0x3efad1['autoExpand'];function _0x58ac21(_0x3aa5ed,_0x5c0803,_0x52ecd3){var _0x9a2757=_0x5a41;_0x5c0803['type']='unknown',_0x5c0803[_0x9a2757(0x1a0)]=_0x3aa5ed[_0x9a2757(0x168)],_0x3e44c3=_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)],_0x52ecd3[_0x9a2757(0x145)][_0x9a2757(0xcf)]=_0x5c0803,_0x47d7be[_0x9a2757(0x187)](_0x5c0803,_0x52ecd3);}let _0xbd937b,_0x4a2288,_0x241cc=_0x5873aa['ninjaSuppressConsole'];_0x5873aa['ninjaSuppressConsole']=!0x0,_0x5873aa[_0x23455e(0xcc)]&&(_0xbd937b=_0x5873aa[_0x23455e(0xcc)]['error'],_0x4a2288=_0x5873aa['console'][_0x23455e(0x170)],_0xbd937b&&(_0x5873aa['console']['error']=function(){}),_0x4a2288&&(_0x5873aa['console'][_0x23455e(0x170)]=function(){}));try{try{_0x3efad1[_0x23455e(0x1af)]++,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x102)][_0x23455e(0x119)](_0xe7c38a);var _0x6cd2d3,_0x2b585b,_0x2a5db7,_0x3c44b3,_0x496c9e=[],_0x333092=[],_0x4329e3,_0x5c61c1=this['_type'](_0xe7c38a),_0x2cfc15=_0x5c61c1===_0x23455e(0x180),_0x17237c=!0x1,_0x27360a=_0x5c61c1==='function',_0x4d346e=this['_isPrimitiveType'](_0x5c61c1),_0x249206=this[_0x23455e(0x19b)](_0x5c61c1),_0x3c5b1d=_0x4d346e||_0x249206,_0x16b4fc={},_0x368b87=0x0,_0x46e586=!0x1,_0x3e44c3,_0x4deeb0=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x3efad1['depth']){if(_0x2cfc15){if(_0x2b585b=_0xe7c38a[_0x23455e(0x10f)],_0x2b585b>_0x3efad1[_0x23455e(0x1a7)]){for(_0x2a5db7=0x0,_0x3c44b3=_0x3efad1[_0x23455e(0x1a7)],_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0x15d)](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));_0x27724c[_0x23455e(0xe6)]=!0x0;}else{for(_0x2a5db7=0x0,_0x3c44b3=_0x2b585b,_0x6cd2d3=_0x2a5db7;_0x6cd2d3<_0x3c44b3;_0x6cd2d3++)_0x333092[_0x23455e(0x119)](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x5c61c1,_0x6cd2d3,_0x3efad1));}_0x3efad1[_0x23455e(0x171)]+=_0x333092['length'];}if(!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&!_0x4d346e&&_0x5c61c1!==_0x23455e(0x13e)&&_0x5c61c1!==_0x23455e(0x176)&&_0x5c61c1!==_0x23455e(0x154)){var _0x504faa=_0x4054fc['props']||_0x3efad1['props'];if(this['_isSet'](_0xe7c38a)?(_0x6cd2d3=0x0,_0xe7c38a[_0x23455e(0x113)](function(_0x116948){var _0x29bff9=_0x23455e;if(_0x368b87++,_0x3efad1[_0x29bff9(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1['isExpressionToEvaluate']&&_0x3efad1['autoExpand']&&_0x3efad1['autoExpandPropertyCount']>_0x3efad1['autoExpandLimit']){_0x46e586=!0x0;return;}_0x333092['push'](_0x47d7be['_addProperty'](_0x496c9e,_0xe7c38a,_0x29bff9(0x1c1),_0x6cd2d3++,_0x3efad1,function(_0x5b68ce){return function(){return _0x5b68ce;};}(_0x116948)));})):this['_isMap'](_0xe7c38a)&&_0xe7c38a[_0x23455e(0x113)](function(_0x32011f,_0x2c19ff){var _0x585ade=_0x23455e;if(_0x368b87++,_0x3efad1[_0x585ade(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;return;}if(!_0x3efad1[_0x585ade(0x116)]&&_0x3efad1[_0x585ade(0xfe)]&&_0x3efad1[_0x585ade(0x171)]>_0x3efad1[_0x585ade(0x1c9)]){_0x46e586=!0x0;return;}var _0x34b418=_0x2c19ff[_0x585ade(0x122)]();_0x34b418[_0x585ade(0x10f)]>0x64&&(_0x34b418=_0x34b418[_0x585ade(0x17d)](0x0,0x64)+_0x585ade(0x18c)),_0x333092[_0x585ade(0x119)](_0x47d7be[_0x585ade(0x15d)](_0x496c9e,_0xe7c38a,'Map',_0x34b418,_0x3efad1,function(_0x3df5a8){return function(){return _0x3df5a8;};}(_0x32011f)));}),!_0x17237c){try{for(_0x4329e3 in _0xe7c38a)if(!(_0x2cfc15&&_0x4deeb0['test'](_0x4329e3))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be[_0x23455e(0xdd)](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}catch{}if(_0x16b4fc['_p_length']=!0x0,_0x27360a&&(_0x16b4fc[_0x23455e(0xf9)]=!0x0),!_0x46e586){var _0x1a196c=[][_0x23455e(0x15e)](this['_getOwnPropertyNames'](_0xe7c38a))[_0x23455e(0x15e)](this[_0x23455e(0x19c)](_0xe7c38a));for(_0x6cd2d3=0x0,_0x2b585b=_0x1a196c[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)if(_0x4329e3=_0x1a196c[_0x6cd2d3],!(_0x2cfc15&&_0x4deeb0[_0x23455e(0xf5)](_0x4329e3[_0x23455e(0x122)]()))&&!this[_0x23455e(0x16f)](_0xe7c38a,_0x4329e3,_0x3efad1)&&!_0x16b4fc[typeof _0x4329e3!=_0x23455e(0x1c2)?'_p_'+_0x4329e3[_0x23455e(0x122)]():_0x4329e3]){if(_0x368b87++,_0x3efad1[_0x23455e(0x171)]++,_0x368b87>_0x504faa){_0x46e586=!0x0;break;}if(!_0x3efad1[_0x23455e(0x116)]&&_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1[_0x23455e(0x171)]>_0x3efad1[_0x23455e(0x1c9)]){_0x46e586=!0x0;break;}_0x333092[_0x23455e(0x119)](_0x47d7be['_addObjectProperty'](_0x496c9e,_0x16b4fc,_0xe7c38a,_0x5c61c1,_0x4329e3,_0x3efad1));}}}}}if(_0x27724c[_0x23455e(0x13a)]=_0x5c61c1,_0x3c5b1d?(_0x27724c[_0x23455e(0x146)]=_0xe7c38a[_0x23455e(0x1cb)](),this['_capIfString'](_0x5c61c1,_0x27724c,_0x3efad1,_0x4054fc)):_0x5c61c1===_0x23455e(0xc4)?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x1ac)]['call'](_0xe7c38a):_0x5c61c1===_0x23455e(0x154)?_0x27724c['value']=_0xe7c38a[_0x23455e(0x122)]():_0x5c61c1==='RegExp'?_0x27724c[_0x23455e(0x146)]=this[_0x23455e(0x18b)][_0x23455e(0x12e)](_0xe7c38a):_0x5c61c1===_0x23455e(0x1c2)&&this[_0x23455e(0x14d)]?_0x27724c[_0x23455e(0x146)]=this['_Symbol'][_0x23455e(0x178)][_0x23455e(0x122)]['call'](_0xe7c38a):!_0x3efad1[_0x23455e(0xd0)]&&!(_0x5c61c1===_0x23455e(0x172)||_0x5c61c1===_0x23455e(0xe8))&&(delete _0x27724c[_0x23455e(0x146)],_0x27724c[_0x23455e(0x12b)]=!0x0),_0x46e586&&(_0x27724c['cappedProps']=!0x0),_0x3e44c3=_0x3efad1[_0x23455e(0x145)][_0x23455e(0xcf)],_0x3efad1['node'][_0x23455e(0xcf)]=_0x27724c,this['_treeNodePropertiesBeforeFullValue'](_0x27724c,_0x3efad1),_0x333092[_0x23455e(0x10f)]){for(_0x6cd2d3=0x0,_0x2b585b=_0x333092[_0x23455e(0x10f)];_0x6cd2d3<_0x2b585b;_0x6cd2d3++)_0x333092[_0x6cd2d3](_0x6cd2d3);}_0x496c9e['length']&&(_0x27724c['props']=_0x496c9e);}catch(_0x4444a){_0x58ac21(_0x4444a,_0x27724c,_0x3efad1);}this['_additionalMetadata'](_0xe7c38a,_0x27724c),this['_treeNodePropertiesAfterFullValue'](_0x27724c,_0x3efad1),_0x3efad1['node'][_0x23455e(0xcf)]=_0x3e44c3,_0x3efad1[_0x23455e(0x1af)]--,_0x3efad1[_0x23455e(0xfe)]=_0x252550,_0x3efad1[_0x23455e(0xfe)]&&_0x3efad1['autoExpandPreviousObjects'][_0x23455e(0x125)]();}finally{_0xbd937b&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x1a0)]=_0xbd937b),_0x4a2288&&(_0x5873aa[_0x23455e(0xcc)][_0x23455e(0x170)]=_0x4a2288),_0x5873aa[_0x23455e(0xe3)]=_0x241cc;}return _0x27724c;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x19c)]=function(_0x4e35d2){var _0x1be40a=_0x2cb272;return Object[_0x1be40a(0x16d)]?Object['getOwnPropertySymbols'](_0x4e35d2):[];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x110)]=function(_0x2fe3c7){var _0x1bfa34=_0x2cb272;return!!(_0x2fe3c7&&_0x5873aa[_0x1bfa34(0x1c1)]&&this[_0x1bfa34(0xd1)](_0x2fe3c7)===_0x1bfa34(0x160)&&_0x2fe3c7[_0x1bfa34(0x113)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16f)]=function(_0x1247ea,_0x4ab5f4,_0x3e79c9){var _0x5f57fc=_0x2cb272;if(!_0x3e79c9[_0x5f57fc(0x117)]){let _0x5b1ca2=this[_0x5f57fc(0x10c)](_0x1247ea,_0x4ab5f4);if(_0x5b1ca2&&_0x5b1ca2['get'])return!0x0;}return _0x3e79c9[_0x5f57fc(0x19f)]?typeof _0x1247ea[_0x4ab5f4]==_0x5f57fc(0x105):!0x1;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x12a)]=function(_0x855594){var _0x4849c4=_0x2cb272,_0x2b6119='';return _0x2b6119=typeof _0x855594,_0x2b6119===_0x4849c4(0x12d)?this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0x10a)?_0x2b6119=_0x4849c4(0x180):this[_0x4849c4(0xd1)](_0x855594)===_0x4849c4(0xec)?_0x2b6119=_0x4849c4(0xc4):this[_0x4849c4(0xd1)](_0x855594)==='[object\\x20BigInt]'?_0x2b6119=_0x4849c4(0x154):_0x855594===null?_0x2b6119=_0x4849c4(0x172):_0x855594['constructor']&&(_0x2b6119=_0x855594['constructor'][_0x4849c4(0x1be)]||_0x2b6119):_0x2b6119==='undefined'&&this['_HTMLAllCollection']&&_0x855594 instanceof this['_HTMLAllCollection']&&(_0x2b6119=_0x4849c4(0x136)),_0x2b6119;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xd1)]=function(_0x2d378a){var _0x42e9e1=_0x2cb272;return Object[_0x42e9e1(0x178)]['toString'][_0x42e9e1(0x12e)](_0x2d378a);},_0x4de4d2['prototype']['_isPrimitiveType']=function(_0x49489e){var _0x4d59c8=_0x2cb272;return _0x49489e===_0x4d59c8(0xd6)||_0x49489e==='string'||_0x49489e==='number';},_0x4de4d2[_0x2cb272(0x178)]['_isPrimitiveWrapperType']=function(_0x5ad54d){var _0x362e66=_0x2cb272;return _0x5ad54d==='Boolean'||_0x5ad54d===_0x362e66(0x13e)||_0x5ad54d===_0x362e66(0xe7);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x15d)]=function(_0x4fe9b7,_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91){var _0x502d7d=this;return function(_0x1e15bc){var _0x3c5173=_0x5a41,_0x49048b=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xcf)],_0x381145=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)],_0x563aae=_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)];_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0xc9)]=_0x49048b,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=typeof _0x511187==_0x3c5173(0xce)?_0x511187:_0x1e15bc,_0x4fe9b7['push'](_0x502d7d[_0x3c5173(0x198)](_0x1b5498,_0x268731,_0x511187,_0x76c4bc,_0x5c3d91)),_0x76c4bc['node'][_0x3c5173(0xc9)]=_0x563aae,_0x76c4bc[_0x3c5173(0x145)][_0x3c5173(0x134)]=_0x381145;};},_0x4de4d2['prototype']['_addObjectProperty']=function(_0x178345,_0x303198,_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38){var _0x562f19=_0x2cb272,_0x1bbfd2=this;return _0x303198[typeof _0x1945f8!=_0x562f19(0x1c2)?'_p_'+_0x1945f8[_0x562f19(0x122)]():_0x1945f8]=!0x0,function(_0x3b9835){var _0x5c127c=_0x562f19,_0x561160=_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xcf)],_0x3fc84f=_0x586d1c['node'][_0x5c127c(0x134)],_0x43d53f=_0x586d1c['node'][_0x5c127c(0xc9)];_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0xc9)]=_0x561160,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3b9835,_0x178345[_0x5c127c(0x119)](_0x1bbfd2[_0x5c127c(0x198)](_0x28d756,_0x49a632,_0x1945f8,_0x586d1c,_0xd09c38)),_0x586d1c[_0x5c127c(0x145)]['parent']=_0x43d53f,_0x586d1c[_0x5c127c(0x145)][_0x5c127c(0x134)]=_0x3fc84f;};},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x198)]=function(_0x67eb30,_0x29f374,_0x5d83f7,_0x29b358,_0x30cd4d){var _0x1a4c0e=_0x2cb272,_0x2885fe=this;_0x30cd4d||(_0x30cd4d=function(_0x196fec,_0x2c514e){return _0x196fec[_0x2c514e];});var _0x4369db=_0x5d83f7[_0x1a4c0e(0x122)](),_0x9761b4=_0x29b358[_0x1a4c0e(0x167)]||{},_0x586f06=_0x29b358[_0x1a4c0e(0xd0)],_0x3a48b1=_0x29b358['isExpressionToEvaluate'];try{var _0x52f87b=this[_0x1a4c0e(0x147)](_0x67eb30),_0x4741cd=_0x4369db;_0x52f87b&&_0x4741cd[0x0]==='\\x27'&&(_0x4741cd=_0x4741cd[_0x1a4c0e(0x194)](0x1,_0x4741cd[_0x1a4c0e(0x10f)]-0x2));var _0x5d5769=_0x29b358['expressionsToEvaluate']=_0x9761b4['_p_'+_0x4741cd];_0x5d5769&&(_0x29b358['depth']=_0x29b358[_0x1a4c0e(0xd0)]+0x1),_0x29b358['isExpressionToEvaluate']=!!_0x5d5769;var _0x10cb78=typeof _0x5d83f7=='symbol',_0x330f9d={'name':_0x10cb78||_0x52f87b?_0x4369db:this[_0x1a4c0e(0xd5)](_0x4369db)};if(_0x10cb78&&(_0x330f9d[_0x1a4c0e(0x1c2)]=!0x0),!(_0x29f374===_0x1a4c0e(0x180)||_0x29f374==='Error')){var _0x14f906=this['_getOwnPropertyDescriptor'](_0x67eb30,_0x5d83f7);if(_0x14f906&&(_0x14f906[_0x1a4c0e(0xc5)]&&(_0x330f9d[_0x1a4c0e(0x1c8)]=!0x0),_0x14f906['get']&&!_0x5d5769&&!_0x29b358[_0x1a4c0e(0x117)]))return _0x330f9d[_0x1a4c0e(0xeb)]=!0x0,this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x58877c;try{_0x58877c=_0x30cd4d(_0x67eb30,_0x5d83f7);}catch(_0x14f629){return _0x330f9d={'name':_0x4369db,'type':_0x1a4c0e(0xc6),'error':_0x14f629[_0x1a4c0e(0x168)]},this['_processTreeNodeResult'](_0x330f9d,_0x29b358),_0x330f9d;}var _0x102988=this['_type'](_0x58877c),_0x49a64d=this['_isPrimitiveType'](_0x102988);if(_0x330f9d['type']=_0x102988,_0x49a64d)this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x42b519=_0x1a4c0e;_0x330f9d['value']=_0x58877c[_0x42b519(0x1cb)](),!_0x5d5769&&_0x2885fe[_0x42b519(0xc3)](_0x102988,_0x330f9d,_0x29b358,{});});else{var _0x580aa0=_0x29b358[_0x1a4c0e(0xfe)]&&_0x29b358[_0x1a4c0e(0x1af)]<_0x29b358[_0x1a4c0e(0x107)]&&_0x29b358[_0x1a4c0e(0x102)]['indexOf'](_0x58877c)<0x0&&_0x102988!==_0x1a4c0e(0x105)&&_0x29b358['autoExpandPropertyCount']<_0x29b358[_0x1a4c0e(0x1c9)];_0x580aa0||_0x29b358[_0x1a4c0e(0x1af)]<_0x586f06||_0x5d5769?this['serialize'](_0x330f9d,_0x58877c,_0x29b358,_0x5d5769||{}):this[_0x1a4c0e(0x1a3)](_0x330f9d,_0x29b358,_0x58877c,function(){var _0x492fd5=_0x1a4c0e;_0x102988===_0x492fd5(0x172)||_0x102988==='undefined'||(delete _0x330f9d[_0x492fd5(0x146)],_0x330f9d[_0x492fd5(0x12b)]=!0x0);});}return _0x330f9d;}finally{_0x29b358[_0x1a4c0e(0x167)]=_0x9761b4,_0x29b358['depth']=_0x586f06,_0x29b358[_0x1a4c0e(0x116)]=_0x3a48b1;}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc3)]=function(_0x52cb19,_0x54c144,_0x3e334e,_0x532699){var _0x3f3b07=_0x2cb272,_0x2ca270=_0x532699[_0x3f3b07(0x126)]||_0x3e334e['strLength'];if((_0x52cb19==='string'||_0x52cb19===_0x3f3b07(0x13e))&&_0x54c144[_0x3f3b07(0x146)]){let _0x160821=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x10f)];_0x3e334e[_0x3f3b07(0xfa)]+=_0x160821,_0x3e334e[_0x3f3b07(0xfa)]>_0x3e334e['totalStrLength']?(_0x54c144['capped']='',delete _0x54c144[_0x3f3b07(0x146)]):_0x160821>_0x2ca270&&(_0x54c144['capped']=_0x54c144[_0x3f3b07(0x146)][_0x3f3b07(0x194)](0x0,_0x2ca270),delete _0x54c144[_0x3f3b07(0x146)]);}},_0x4de4d2['prototype']['_isMap']=function(_0x18d6a6){var _0x3c7fd5=_0x2cb272;return!!(_0x18d6a6&&_0x5873aa['Map']&&this[_0x3c7fd5(0xd1)](_0x18d6a6)===_0x3c7fd5(0x199)&&_0x18d6a6[_0x3c7fd5(0x113)]);},_0x4de4d2[_0x2cb272(0x178)]['_propertyName']=function(_0x947ebf){var _0x531112=_0x2cb272;if(_0x947ebf[_0x531112(0x1ba)](/^\\d+$/))return _0x947ebf;var _0x9a15b4;try{_0x9a15b4=JSON['stringify'](''+_0x947ebf);}catch{_0x9a15b4='\\x22'+this['_objectToString'](_0x947ebf)+'\\x22';}return _0x9a15b4[_0x531112(0x1ba)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x9a15b4=_0x9a15b4[_0x531112(0x194)](0x1,_0x9a15b4[_0x531112(0x10f)]-0x2):_0x9a15b4=_0x9a15b4['replace'](/'/g,'\\x5c\\x27')[_0x531112(0xf6)](/\\\\\"/g,'\\x22')[_0x531112(0xf6)](/(^\"|\"$)/g,'\\x27'),_0x9a15b4;},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1a3)]=function(_0x35e665,_0x2101c2,_0xab9652,_0x1c446e){var _0x3971dc=_0x2cb272;this[_0x3971dc(0x187)](_0x35e665,_0x2101c2),_0x1c446e&&_0x1c446e(),this[_0x3971dc(0x166)](_0xab9652,_0x35e665),this[_0x3971dc(0x142)](_0x35e665,_0x2101c2);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x187)]=function(_0x44b450,_0x34a33b){var _0x25ebc5=_0x2cb272;this[_0x25ebc5(0x123)](_0x44b450,_0x34a33b),this[_0x25ebc5(0x135)](_0x44b450,_0x34a33b),this['_setNodeExpressionPath'](_0x44b450,_0x34a33b),this[_0x25ebc5(0x16b)](_0x44b450,_0x34a33b);},_0x4de4d2['prototype'][_0x2cb272(0x123)]=function(_0x533ba7,_0x208597){},_0x4de4d2['prototype'][_0x2cb272(0x135)]=function(_0x1c215c,_0x404f13){},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xc8)]=function(_0x4fbee4,_0x4ecb21){},_0x4de4d2['prototype'][_0x2cb272(0x1a6)]=function(_0x41a1f1){var _0x327560=_0x2cb272;return _0x41a1f1===this[_0x327560(0x17e)];},_0x4de4d2[_0x2cb272(0x178)]['_treeNodePropertiesAfterFullValue']=function(_0x48ca53,_0x268d68){var _0x2e622c=_0x2cb272;this[_0x2e622c(0xc8)](_0x48ca53,_0x268d68),this[_0x2e622c(0x157)](_0x48ca53),_0x268d68[_0x2e622c(0xc2)]&&this[_0x2e622c(0xdf)](_0x48ca53),this['_addFunctionsNode'](_0x48ca53,_0x268d68),this[_0x2e622c(0x137)](_0x48ca53,_0x268d68),this[_0x2e622c(0x10b)](_0x48ca53);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x166)]=function(_0x2678a0,_0x259c0d){var _0x36fdc4=_0x2cb272;try{_0x2678a0&&typeof _0x2678a0[_0x36fdc4(0x10f)]==_0x36fdc4(0xce)&&(_0x259c0d[_0x36fdc4(0x10f)]=_0x2678a0[_0x36fdc4(0x10f)]);}catch{}if(_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xce)||_0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0xe7)){if(isNaN(_0x259c0d['value']))_0x259c0d[_0x36fdc4(0x11a)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];else switch(_0x259c0d['value']){case Number[_0x36fdc4(0x12f)]:_0x259c0d[_0x36fdc4(0x127)]=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case Number[_0x36fdc4(0x189)]:_0x259c0d['negativeInfinity']=!0x0,delete _0x259c0d[_0x36fdc4(0x146)];break;case 0x0:this['_isNegativeZero'](_0x259c0d['value'])&&(_0x259c0d['negativeZero']=!0x0);break;}}else _0x259c0d[_0x36fdc4(0x13a)]===_0x36fdc4(0x105)&&typeof _0x2678a0[_0x36fdc4(0x1be)]==_0x36fdc4(0x173)&&_0x2678a0['name']&&_0x259c0d[_0x36fdc4(0x1be)]&&_0x2678a0[_0x36fdc4(0x1be)]!==_0x259c0d['name']&&(_0x259c0d[_0x36fdc4(0x1c5)]=_0x2678a0[_0x36fdc4(0x1be)]);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x1bb)]=function(_0x31e8d6){return 0x1/_0x31e8d6===Number['NEGATIVE_INFINITY'];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0xdf)]=function(_0x5387a1){var _0xf6510d=_0x2cb272;!_0x5387a1[_0xf6510d(0x1b8)]||!_0x5387a1['props'][_0xf6510d(0x10f)]||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x180)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1b4)||_0x5387a1[_0xf6510d(0x13a)]===_0xf6510d(0x1c1)||_0x5387a1['props']['sort'](function(_0x47dd16,_0x585d58){var _0x14b330=_0xf6510d,_0x13e486=_0x47dd16[_0x14b330(0x1be)][_0x14b330(0x169)](),_0x486976=_0x585d58[_0x14b330(0x1be)]['toLowerCase']();return _0x13e486<_0x486976?-0x1:_0x13e486>_0x486976?0x1:0x0;});},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x174)]=function(_0x222b24,_0x769935){var _0x84e84d=_0x2cb272;if(!(_0x769935['noFunctions']||!_0x222b24['props']||!_0x222b24['props'][_0x84e84d(0x10f)])){for(var _0x730840=[],_0x3e54f2=[],_0x12e05b=0x0,_0x14c80d=_0x222b24['props'][_0x84e84d(0x10f)];_0x12e05b<_0x14c80d;_0x12e05b++){var _0x227177=_0x222b24['props'][_0x12e05b];_0x227177[_0x84e84d(0x13a)]===_0x84e84d(0x105)?_0x730840[_0x84e84d(0x119)](_0x227177):_0x3e54f2['push'](_0x227177);}if(!(!_0x3e54f2[_0x84e84d(0x10f)]||_0x730840[_0x84e84d(0x10f)]<=0x1)){_0x222b24[_0x84e84d(0x1b8)]=_0x3e54f2;var _0x4768f5={'functionsNode':!0x0,'props':_0x730840};this['_setNodeId'](_0x4768f5,_0x769935),this[_0x84e84d(0xc8)](_0x4768f5,_0x769935),this[_0x84e84d(0x157)](_0x4768f5),this[_0x84e84d(0x16b)](_0x4768f5,_0x769935),_0x4768f5['id']+='\\x20f',_0x222b24['props']['unshift'](_0x4768f5);}}},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x137)]=function(_0x563c3f,_0x4419b7){},_0x4de4d2['prototype'][_0x2cb272(0x157)]=function(_0x497fff){},_0x4de4d2['prototype'][_0x2cb272(0x17a)]=function(_0x1b9882){var _0x3294c4=_0x2cb272;return Array[_0x3294c4(0x19a)](_0x1b9882)||typeof _0x1b9882==_0x3294c4(0x12d)&&this[_0x3294c4(0xd1)](_0x1b9882)===_0x3294c4(0x10a);},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x16b)]=function(_0x9d1c25,_0x314f15){},_0x4de4d2['prototype']['_cleanNode']=function(_0x1d1f32){var _0x54d4ff=_0x2cb272;delete _0x1d1f32[_0x54d4ff(0x14e)],delete _0x1d1f32[_0x54d4ff(0x192)],delete _0x1d1f32[_0x54d4ff(0x11d)];},_0x4de4d2[_0x2cb272(0x178)][_0x2cb272(0x11b)]=function(_0x263d9a,_0x3e2e45){};let _0xaaf654=new _0x4de4d2(),_0x1c9af4={'props':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x1b8)]||0x64,'elements':_0xad4d21['defaultLimits'][_0x2cb272(0x1a7)]||0x64,'strLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0x126)]||0x400*0x32,'totalStrLength':_0xad4d21[_0x2cb272(0x108)][_0x2cb272(0xf2)]||0x400*0x32,'autoExpandLimit':_0xad4d21['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0xad4d21['defaultLimits'][_0x2cb272(0x107)]||0xa},_0xf3a84={'props':_0xad4d21[_0x2cb272(0x18f)]['props']||0x5,'elements':_0xad4d21['reducedLimits'][_0x2cb272(0x1a7)]||0x5,'strLength':_0xad4d21['reducedLimits'][_0x2cb272(0x126)]||0x100,'totalStrLength':_0xad4d21[_0x2cb272(0x18f)][_0x2cb272(0xf2)]||0x100*0x3,'autoExpandLimit':_0xad4d21['reducedLimits'][_0x2cb272(0x1c9)]||0x1e,'autoExpandMaxDepth':_0xad4d21['reducedLimits'][_0x2cb272(0x107)]||0x2};if(_0x413cb2){let _0x4ae918=_0xaaf654[_0x2cb272(0x15c)]['bind'](_0xaaf654);_0xaaf654[_0x2cb272(0x15c)]=function(_0x40ecf2,_0x500c15,_0x2ec994,_0x14464a){return _0x4ae918(_0x40ecf2,_0x413cb2(_0x500c15),_0x2ec994,_0x14464a);};}function _0x204baa(_0x5e4db5,_0x4cbe7b,_0x269521,_0x27d5cf,_0x167817,_0x172f23){var _0x3043e4=_0x2cb272;let _0x547422,_0x3647de;try{_0x3647de=_0x21a97a(),_0x547422=_0x45642a[_0x4cbe7b],!_0x547422||_0x3647de-_0x547422['ts']>_0x1ec146[_0x3043e4(0x150)]['resetWhenQuietMs']&&_0x547422[_0x3043e4(0x1b9)]&&_0x547422['time']/_0x547422[_0x3043e4(0x1b9)]<_0x1ec146['perLogpoint']['resetOnProcessingTimeAverageMs']?(_0x45642a[_0x4cbe7b]=_0x547422={'count':0x0,'time':0x0,'ts':_0x3647de},_0x45642a[_0x3043e4(0xe4)]={}):_0x3647de-_0x45642a[_0x3043e4(0xe4)]['ts']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x121)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]&&_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]/_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]<_0x1ec146[_0x3043e4(0x17b)]['resetOnProcessingTimeAverageMs']&&(_0x45642a[_0x3043e4(0xe4)]={});let _0x4ef115=[],_0xe809ad=_0x547422[_0x3043e4(0x15b)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]?_0xf3a84:_0x1c9af4,_0xb619d5=_0xa8c3fb=>{var _0x237ccb=_0x3043e4;let _0x4e7b95={};return _0x4e7b95['props']=_0xa8c3fb[_0x237ccb(0x1b8)],_0x4e7b95[_0x237ccb(0x1a7)]=_0xa8c3fb['elements'],_0x4e7b95[_0x237ccb(0x126)]=_0xa8c3fb[_0x237ccb(0x126)],_0x4e7b95[_0x237ccb(0xf2)]=_0xa8c3fb[_0x237ccb(0xf2)],_0x4e7b95[_0x237ccb(0x1c9)]=_0xa8c3fb[_0x237ccb(0x1c9)],_0x4e7b95['autoExpandMaxDepth']=_0xa8c3fb['autoExpandMaxDepth'],_0x4e7b95[_0x237ccb(0xc2)]=!0x1,_0x4e7b95[_0x237ccb(0x19f)]=!_0x5b995d,_0x4e7b95[_0x237ccb(0xd0)]=0x1,_0x4e7b95[_0x237ccb(0x1af)]=0x0,_0x4e7b95[_0x237ccb(0x1a8)]=_0x237ccb(0x1bc),_0x4e7b95[_0x237ccb(0x114)]='root_exp',_0x4e7b95[_0x237ccb(0xfe)]=!0x0,_0x4e7b95[_0x237ccb(0x102)]=[],_0x4e7b95[_0x237ccb(0x171)]=0x0,_0x4e7b95['resolveGetters']=_0xad4d21[_0x237ccb(0x117)],_0x4e7b95['allStrLength']=0x0,_0x4e7b95[_0x237ccb(0x145)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x4e7b95;};for(var _0x544924=0x0;_0x544924<_0x167817[_0x3043e4(0x10f)];_0x544924++)_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'timeNode':_0x5e4db5==='time'||void 0x0},_0x167817[_0x544924],_0xb619d5(_0xe809ad),{}));if(_0x5e4db5===_0x3043e4(0x1c0)||_0x5e4db5===_0x3043e4(0x1a0)){let _0xb54963=Error['stackTraceLimit'];try{Error[_0x3043e4(0x18a)]=0x1/0x0,_0x4ef115[_0x3043e4(0x119)](_0xaaf654[_0x3043e4(0x15c)]({'stackNode':!0x0},new Error()[_0x3043e4(0x1ca)],_0xb619d5(_0xe809ad),{'strLength':0x1/0x0}));}finally{Error[_0x3043e4(0x18a)]=_0xb54963;}}return{'method':'log','version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':_0x4ef115,'id':_0x4cbe7b,'context':_0x172f23}]};}catch(_0x4cace3){return{'method':_0x3043e4(0x111),'version':_0x5b3c4b,'args':[{'ts':_0x269521,'session':_0x27d5cf,'args':[{'type':'unknown','error':_0x4cace3&&_0x4cace3['message']}],'id':_0x4cbe7b,'context':_0x172f23}]};}finally{try{if(_0x547422&&_0x3647de){let _0x54611d=_0x21a97a();_0x547422[_0x3043e4(0x1b9)]++,_0x547422[_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x547422['ts']=_0x54611d,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x1b9)]++,_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]+=_0x48338(_0x3647de,_0x54611d),_0x45642a[_0x3043e4(0xe4)]['ts']=_0x54611d,(_0x547422[_0x3043e4(0x1b9)]>_0x1ec146[_0x3043e4(0x150)][_0x3043e4(0x148)]||_0x547422['time']>_0x1ec146[_0x3043e4(0x150)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x547422[_0x3043e4(0x15b)]=!0x0),(_0x45642a[_0x3043e4(0xe4)]['count']>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0x148)]||_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x14c)]>_0x1ec146[_0x3043e4(0x17b)][_0x3043e4(0xf7)])&&(_0x45642a[_0x3043e4(0xe4)][_0x3043e4(0x15b)]=!0x0);}}catch{}}}return _0x204baa;}function G(_0x13f625){var _0x54528b=_0x1fc135;if(_0x13f625&&typeof _0x13f625==_0x54528b(0x12d)&&_0x13f625[_0x54528b(0x1a5)])switch(_0x13f625[_0x54528b(0x1a5)][_0x54528b(0x1be)]){case _0x54528b(0xd3):return _0x13f625[_0x54528b(0x177)](Symbol[_0x54528b(0x1a1)])?Promise[_0x54528b(0x190)]():_0x13f625;case _0x54528b(0xff):return Promise[_0x54528b(0x190)]();}return _0x13f625;}((_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x1665bd,_0x18cf9b,_0x28f3bf,_0x34d492,_0x102ada,_0x2185be,_0x56bcb6)=>{var _0x30ea7a=_0x1fc135;if(_0x47130b[_0x30ea7a(0x13f)])return _0x47130b[_0x30ea7a(0x13f)];let _0x20c7ea={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x47130b,_0x28f3bf,_0x5dc278))return _0x47130b[_0x30ea7a(0x13f)]=_0x20c7ea,_0x47130b[_0x30ea7a(0x13f)];let _0x48c72d=b(_0x47130b),_0x1bb7cb=_0x48c72d['elapsed'],_0x6f8a3d=_0x48c72d[_0x30ea7a(0x14b)],_0x22b15a=_0x48c72d['now'],_0x43827b={'hits':{},'ts':{}},_0x46d74=J(_0x47130b,_0x34d492,_0x43827b,_0x1665bd,_0x56bcb6,_0x5dc278===_0x30ea7a(0x130)?G:void 0x0),_0x1b94d4=(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa)=>{var _0x52c0bf=_0x30ea7a;let _0x4de224=_0x47130b[_0x52c0bf(0x13f)];try{return _0x47130b[_0x52c0bf(0x13f)]=_0x20c7ea,_0x46d74(_0x320bd1,_0x73cddf,_0x190f24,_0x12ba96,_0x296271,_0x83f0aa);}finally{_0x47130b[_0x52c0bf(0x13f)]=_0x4de224;}},_0x4fe773=_0x2394ff=>{_0x43827b['ts'][_0x2394ff]=_0x6f8a3d();},_0x561b11=(_0x1151c5,_0x153ab7)=>{var _0x577f8a=_0x30ea7a;let _0x438ac0=_0x43827b['ts'][_0x153ab7];if(delete _0x43827b['ts'][_0x153ab7],_0x438ac0){let _0x5d6465=_0x1bb7cb(_0x438ac0,_0x6f8a3d());_0x2ba420(_0x1b94d4(_0x577f8a(0x14c),_0x1151c5,_0x22b15a(),_0x163cab,[_0x5d6465],_0x153ab7));}},_0x6d0288=_0x2be048=>{var _0x100044=_0x30ea7a,_0x2e51d9;return _0x5dc278===_0x100044(0x130)&&_0x47130b['origin']&&((_0x2e51d9=_0x2be048==null?void 0x0:_0x2be048[_0x100044(0x1b7)])==null?void 0x0:_0x2e51d9['length'])&&(_0x2be048[_0x100044(0x1b7)][0x0]['origin']=_0x47130b['origin']),_0x2be048;};_0x47130b['_console_ninja']={'consoleLog':(_0x2d5415,_0x31db20)=>{var _0x16b37d=_0x30ea7a;_0x47130b[_0x16b37d(0xcc)][_0x16b37d(0x111)]['name']!=='disabledLog'&&_0x2ba420(_0x1b94d4(_0x16b37d(0x111),_0x2d5415,_0x22b15a(),_0x163cab,_0x31db20));},'consoleTrace':(_0x3d9758,_0x4a9151)=>{var _0xb77f30=_0x30ea7a,_0x206ebc,_0x1fc11c;_0x47130b['console']['log']['name']!==_0xb77f30(0x185)&&((_0x1fc11c=(_0x206ebc=_0x47130b[_0xb77f30(0x139)])==null?void 0x0:_0x206ebc[_0xb77f30(0xe2)])!=null&&_0x1fc11c[_0xb77f30(0x145)]&&(_0x47130b[_0xb77f30(0xef)]=!0x0),_0x2ba420(_0x6d0288(_0x1b94d4(_0xb77f30(0x1c0),_0x3d9758,_0x22b15a(),_0x163cab,_0x4a9151))));},'consoleError':(_0x2167f3,_0x3018cf)=>{var _0x543849=_0x30ea7a;_0x47130b[_0x543849(0xef)]=!0x0,_0x2ba420(_0x6d0288(_0x1b94d4(_0x543849(0x1a0),_0x2167f3,_0x22b15a(),_0x163cab,_0x3018cf)));},'consoleTime':_0x585cab=>{_0x4fe773(_0x585cab);},'consoleTimeEnd':(_0x53dd91,_0x4b8a93)=>{_0x561b11(_0x4b8a93,_0x53dd91);},'autoLog':(_0x1c4fc8,_0x255231)=>{var _0x51dc3c=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x51dc3c(0x111),_0x255231,_0x22b15a(),_0x163cab,[_0x1c4fc8]));},'autoLogMany':(_0x3c95d1,_0x46977c)=>{var _0x155059=_0x30ea7a;_0x2ba420(_0x1b94d4(_0x155059(0x111),_0x3c95d1,_0x22b15a(),_0x163cab,_0x46977c));},'autoTrace':(_0x37a9be,_0x5eb70a)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0x5eb70a,_0x22b15a(),_0x163cab,[_0x37a9be])));},'autoTraceMany':(_0xd793f3,_0x23b1c2)=>{_0x2ba420(_0x6d0288(_0x1b94d4('trace',_0xd793f3,_0x22b15a(),_0x163cab,_0x23b1c2)));},'autoTime':(_0x391512,_0x226127,_0x4957a2)=>{_0x4fe773(_0x4957a2);},'autoTimeEnd':(_0x485f48,_0x47647b,_0x7fb4a8)=>{_0x561b11(_0x47647b,_0x7fb4a8);},'coverage':_0x5098b3=>{var _0x2c3696=_0x30ea7a;_0x2ba420({'method':_0x2c3696(0x131),'version':_0x1665bd,'args':[{'id':_0x5098b3}]});}};let _0x2ba420=H(_0x47130b,_0x381eb1,_0x126a9d,_0x116a0e,_0x5dc278,_0x102ada,_0x2185be),_0x163cab=_0x47130b[_0x30ea7a(0x1b5)];return _0x47130b[_0x30ea7a(0x13f)];})(globalThis,_0x1fc135(0x12c),_0x1fc135(0x141),\"c:\\\\Users\\\\A M C\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.492\\\\node_modules\",_0x1fc135(0x1ad),_0x1fc135(0xd4),_0x1fc135(0x195),_0x1fc135(0x1a4),_0x1fc135(0xd7),_0x1fc135(0x11e),_0x1fc135(0x144),_0x1fc135(0x10d));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i) {
    for(var _len = arguments.length, v = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        v[_key - 1] = arguments[_key];
    }
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "RemoveIdFielsFromObj");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_57434d76._.js.map