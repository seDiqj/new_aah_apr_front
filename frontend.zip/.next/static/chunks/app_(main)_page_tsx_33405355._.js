(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2a9219d0._.js",
  "static/chunks/node_modules_recharts_es6_a3b98459._.js",
  "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_b0999871._.js",
  "static/chunks/node_modules_pusher-js_dist_web_pusher_6ae92419.js",
  "static/chunks/node_modules_e481fe19._.js"
],
    source: "dynamic"
});
