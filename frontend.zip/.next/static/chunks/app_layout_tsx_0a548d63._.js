(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/_81ce70ae._.js",
  "static/chunks/node_modules_next_0c94753d._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_zod_v4_c91902d9._.js",
  "static/chunks/node_modules_d257a8d8._.js"
],
    source: "dynamic"
});
