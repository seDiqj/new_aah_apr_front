(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f276e23e._.js",
  "static/chunks/node_modules_02e6f31b._.js"
],
    source: "dynamic"
});
