"use client";

import BreadcrumbWithCustomSeparator from "@/components/global/BreadCrumb";
import SubHeader from "@/components/global/SubHeader";
import { Button } from "@/components/ui/button";
import { Navbar14 } from "@/components/ui/shadcn-io/navbar-14";
import { useEffect, useRef, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AssessmentFormType } from "@/types/Types";
import { useParentContext } from "@/contexts/ParentContext";
import { InfoItem } from "../../../referral_database/beneficiary_profile/[id]/page";
import { useParams } from "next/navigation";
import AssessmentScoreForm from "@/components/global/AssessmentScoreForm";
import { IsIdFeild } from "@/lib/Constants";

const MainDatabasePage = () => {
  const { reqForToastAndSetMessage, axiosInstance, reloadFlag } =
    useParentContext();

  const { id } = useParams<{
    id: string;
  }>();

  const [reqForAddNewAssessment, setReqForAddNewAssessment] =
    useState<boolean>(false);

  const [assessmentInfo, setAssessmentInfo] =
    useState<AssessmentFormType | null>(null);

  const [assessmentsData, setAssessmentsData] = useState<
    {
      id: string;
      description: string;
    }[]
  >();

  useEffect(() => {
    axiosInstance
      .get(`/enact_database/show_for_profile/${id}`)
      .then((response: any) => {
        const { assessments, ...assessmentData } = response.data.data;
        setAssessmentInfo(assessmentData);
        setAssessmentsData(assessments);
      })
      .catch((error: any) => {
        reqForToastAndSetMessage(error.response.data.message);
      });
  }, [reloadFlag]);

  return (
    <>
      <div className="max-w-full w-full h-full p-2">
        <Navbar14 />
        <div className="flex flex-row items-center justify-start my-2">
          <BreadcrumbWithCustomSeparator></BreadcrumbWithCustomSeparator>
        </div>
        <SubHeader pageTitle={"Benficiaries"}>
          <div className="flex flex-row items-center justify-around gap-2">
            <Button
              onClick={() => setReqForAddNewAssessment(!reqForAddNewAssessment)}
            >
              Add Assessment
            </Button>
          </div>
        </SubHeader>

        <div className="w-full ">
          <Tabs
            defaultValue="assessmentDetails"
            className="h-full max-w-full w-full overflow-auto"
          >
            {/* List of tabs */}
            <TabsList className="max-w-full overflow-auto">
              <TabsTrigger value="assessmentDetails">
                Assessment Details
              </TabsTrigger>
              <TabsTrigger value="assessments">Assessments</TabsTrigger>
            </TabsList>

            <TabsContent value="assessmentDetails" className="h-full">
              <Card className="min-h-[400px] shadow-sm border border-border w-full">
                <CardHeader>
                  <CardTitle className="text-xl font-semibold">
                    Assessment Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div>
                    {assessmentInfo ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(assessmentInfo).map(
                          ([key, value], index) => {
                            if (IsIdFeild(key)) return;
                            return (
                              <div
                                key={index}
                                className="flex flex-col rounded-xl border p-3 transition-all hover:shadow-sm"
                              >
                                <span className="text-xs font-medium uppercase opacity-70 tracking-wide">
                                  {key.replace(/([A-Z])/g, " $1")}
                                </span>
                                <span className="text-sm font-semibold truncate">
                                  {value?.toString() || "-"}
                                </span>
                              </div>
                            );
                          }
                        )}
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Array.from({ length: 10 }).map((_, i) => (
                          <div
                            key={i}
                            className="h-[56px] w-full rounded-xl animate-pulse bg-muted/30"
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent
              className="flex flex-col items-start justify-around overflow-auto"
              value={"assessments"}
            >
              <Card className="min-h-[400px] shadow-sm border border-border max-h-full w-full overflow-y-auto">
                <CardContent>
                  {assessmentsData?.length == 0
                    ? Message()
                    : assessmentsData?.map((assessment, i) => {
                        return (
                          <Card
                            key={i}
                            className="flex flex-row items-center justify-between w-full px-2 mb-2"
                          >
                            <div>
                              <span>{`Assessment ${i + 1}`}</span>
                            </div>
                            <CardContent>
                              <Button onClick={() => {}}>Assess</Button>
                            </CardContent>
                          </Card>
                        );
                      })}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {reqForAddNewAssessment && (
            <AssessmentScoreForm
              open={reqForAddNewAssessment}
              onOpenChange={setReqForAddNewAssessment}
              mode={"create"}
            ></AssessmentScoreForm>
          )}
        </div>
      </div>
    </>
  );
};

const Message = () => {
  return (
    <>
      <div className="flex flex-row items-center justify-center text-center">
        No assessments was found !
      </div>
    </>
  );
};

export default MainDatabasePage;
