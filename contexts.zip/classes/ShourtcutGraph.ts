import ShourtcutNode from "./ShourtcutNode";

class ShourtcutGraph {
  private graphsArray: ShourtcutNode[][] = [];

  //   ['(', 'a', ')', '->', '(', 'b', '|', 'x', ')']
  public generateShourtcutGraph(shourtcut: string[]): void {}
}

export default ShourtcutGraph;
