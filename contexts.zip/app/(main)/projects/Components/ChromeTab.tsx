"use client";

import React, { useState, useEffect, useRef } from "react";

interface Tab {
  id: number;
  value: string;
  title: string | React.ReactNode;
  stateSetter: (value: string) => void;
  icon?: React.ReactNode;
}

interface InputTab {
  value: string;
  title: string | React.ReactNode;
  stateSetter: (value: string) => void;
  icon?: React.ReactNode;
}

interface ChromeTabsProps {
  initialTabs: InputTab[];
}

const ChromeTabs: React.FC<ChromeTabsProps> = ({ initialTabs }) => {
  const [tabs, setTabs] = useState<Tab[]>(
    initialTabs.map((tab, index) => ({ id: index, ...tab }))
  );

  const [activeTabId, setActiveTabId] = useState<number>(
    initialTabs.map((tab, index) => ({ id: index, ...tab }))[0].id
  );

  useEffect(() => {
    setTabs(initialTabs.map((tab, index) => ({ id: index, ...tab })));
  }, [initialTabs]);

  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div className="relative flex flex-col w-full min-h-[40px] bg-background rounded-lg pt-1 overflow-hidden">
      {/* Tabs */}
      <div
        ref={containerRef}
        className="flex w-full overflow-x-auto whitespace-nowrap z-1"
      >
        {tabs.map((tab, index) => {
          const isActive = activeTabId === tab.id;
          const isPrevActive = activeTabId - 1 === tab.id;
          const isNextActive = activeTabId + 1 === tab.id;
          const isLastActive = isActive && tab.id === tabs.length - 1;

          return (
            <div
              key={tab.id}
              className={`relative w-full cursor-pointer ${
                isActive ? "z-10" : ""
              }`}
            >
              <div
                onClick={() => {
                  setActiveTabId(tab.id);
                  tab.stateSetter(tab.value);
                }}
                className={`
                  flex items-center gap-1 px-4 py-1 text-center transition-all
                  ${
                    isActive
                      ? "bg-primary text-white rounded-t-lg"
                      : "bg-gray-400 hover:bg-gray-300 text-black"
                  }
                  ${isLastActive ? "rounded-r-lg" : ""}
                  ${isPrevActive ? "rounded-r-lg" : ""}
                  ${isNextActive ? "rounded-l-lg" : ""}
                `}
              >
                {tab.icon && <span className="text-gray-700">{tab.icon}</span>}

                <span className="mx-auto w-full text-md">{tab.title}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Bar */}
      <div className="absolute top-7 w-full h-3 bg-primary z-0" />
    </div>
  );
};

export default ChromeTabs;
