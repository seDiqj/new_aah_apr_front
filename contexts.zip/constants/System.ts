export const SUBMIT_BUTTON_PROVIDER_ID = "submitBtnProvider";

export const DELETE_BUTTON_PROVIDER_ID = "deleteBtnProvider";

export const SELECT_ALL_BUTTON_PROVIDER = "selectAllBtnProvider";

export const ARROW_DOWN_BUTTON_PROVIDER = "arrowDownBtnProvider";

export const ARROW_UP_BUTTON_PROVIDER = "arrowUpBtnProvider";

export const ARROW_LEFT_BUTTON_PROVIDER = "arrowLeftBtnProvider";

export const ARROW_RIGHT_BUTTON_PROVIDER = "arrowRightBtnProvider";

export const NEXT_INPUT_BUTTON_PROVIDER = "nextInputBtnProvider";

export const PREVIOUS_INPUT_BUTTON_PROVIDER = "previousInputBtnProvider";

export const GLOBAL_SEARCH_BUTTON_PROVIDER = "globalSearchBtnProvider";

export const SIDEBAR_OPEN_TOGGLER_PROVIDER = "sideBarOpenTogglerProvider";